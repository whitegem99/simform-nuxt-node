module.exports = ({ env }) => {
  return {
    ckeditor: true,
    upload: {
      config: {
        provider: "aws-s3",
        providerOptions: {
          accessKeyId: env("AWS_ACCESS_KEY_ID"),
          secretAccessKey: env("AWS_ACCESS_SECRET"),
          region: env("AWS_REGION"),
          params: {
            Bucket: env("AWS_BUCKET"),
          },
        },
        actionOptions: {
          upload: {},
          uploadStream: {},
          delete: {},
        },
      },
    },
    ezforms: {
      config: {
        enableFormName: true,
        captchaProvider: {
          name: "recaptcha",
          config: {
            secretKey: "6LdBEY8kAAAAAHbnAy_dvsLB8t2k-l_BbtVTwDik",
            minimumScore: 0.5,
          },
        },
        notificationProviders: [],
      },
    },
  };
};
