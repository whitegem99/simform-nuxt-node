module.exports = {
  routes: [
    {
      method: "GET",
      path: "/articles/find-by-slug/:slug",
      handler: "article.findBySlug",
    },
    {
      method: "GET",
      path: "/articles/find-by-category/:category",
      handler: "article.findByCategory",
    },
    {
      method: "GET",
      path: "/articles/find-recent/:category",
      handler: "article.findRecent",
    },
  ],
};
