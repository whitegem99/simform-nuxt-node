"use strict";

/**
 * article controller
 */

const { createCoreController } = require("@strapi/strapi").factories;

module.exports = createCoreController("api::article.article", ({ strapi }) => ({
  async findBySlug(ctx) {
    const { slug } = ctx.params;
    try {
      const post = await strapi.db.query("api::article.article").findOne({
        where: { slug },
        populate: [
          "content",
          "content.image",
          "content.checkMarkItems",
          "category",
          "creator",
          "featuredImage",
          "creator.avatar",
          "content.quickLinkItems",
          "content.listItems",
          "content.compareTableRowItems",
        ],
      });
      return post;
    } catch (error) {
      return error;
    }
  },
  async findByCategory(ctx) {
    const { category } = ctx.params;
    try {
      const posts = await strapi.db.query("api::article.article").findMany({
        where: {
          category: {
            slug: {
              $eq: category,
            },
          },
        },
        populate: [
          "content",
          "content.image",
          "content.checkMarkItems",
          "category",
          "creator",
          "featuredImage",
          "creator.avatar",
          "content.quickLinkItems",
          "content.listItems",
          "content.compareTableRowItems",
        ],
      });
      return posts;
    } catch (error) {
      return error;
    }
  },
  async findRecent(ctx) {
    const { category } = ctx.params;
    const { postId } = ctx.request.query
    console.log(typeof postId)

    try {
      const posts = await strapi.db.query("api::article.article").findMany({
        where: {
          category: {
            slug: {
              $eq: category,
            },
          },
        },
        sort: { publishedAt: 'desc' },
        limit: 4,
        populate: [
          "content",
          "content.image",
          "content.checkMarkItems",
          "category",
          "creator",
          "featuredImage",
          "creator.avatar",
          "content.quickLinkItems",
          "content.listItems",
          "content.compareTableRowItems",
        ],
      });

      console.log(posts.map(post => typeof post.id))

      const filteredPosts = posts.filter(post => post.id != postId)
      const postsToReturn = filteredPosts.slice(0, 3)

      return postsToReturn;
    } catch (error) {
      return error;
    }
  },
}));
