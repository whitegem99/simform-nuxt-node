'use strict';

/**
 * areas-we-serve controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::areas-we-serve.areas-we-serve');
