'use strict';

/**
 * areas-we-serve service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::areas-we-serve.areas-we-serve');
