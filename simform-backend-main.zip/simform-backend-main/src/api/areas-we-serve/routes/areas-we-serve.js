'use strict';

/**
 * areas-we-serve router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::areas-we-serve.areas-we-serve');
