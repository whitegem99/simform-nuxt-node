'use strict';

/**
 * award controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::award.award');
