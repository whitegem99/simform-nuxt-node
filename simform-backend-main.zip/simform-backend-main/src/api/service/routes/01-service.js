module.exports = {
  routes: [
    {
      method: "GET",
      path: "/services/find-by-slug/:slug",
      handler: "service.findBySlug",
    },
  ],
};
