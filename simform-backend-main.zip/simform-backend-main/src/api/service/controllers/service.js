"use strict";

/**
 * service controller
 */

const { createCoreController } = require("@strapi/strapi").factories;

module.exports = createCoreController("api::service.service", ({ strapi }) => ({
  async findBySlug(ctx) {
    const { slug } = ctx.params;
    try {
      const hiring = await strapi.db.query("api::service.service").findOne({
        where: { slug },
        populate: ["deep"]
      });
      return hiring;
    } catch (error) {
      return error;
    }
  },
}));
