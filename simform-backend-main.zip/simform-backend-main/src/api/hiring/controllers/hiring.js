"use strict";

/**
 * hiring controller
 */

const { createCoreController } = require("@strapi/strapi").factories;

module.exports = createCoreController("api::hiring.hiring", ({ strapi }) => ({
  async findBySlug(ctx) {
    const { slug } = ctx.params;
    try {
      const hiring = await strapi.db.query("api::hiring.hiring").findOne({
        where: { slug },
        populate: [
            "content",
            "content.image",
            "content.colorBoxItems",
            "content.colorBoxItems.image",
            "content.clientLogos",
            "content.clientLogos.colorImage",
            "content.clientLogos.grayImage",
            "content.barTitleCheckMarkItems",
            "content.testimonialVideoItems",
            "content.imageParagraphItems",
            "content.imageParagraphItems.image",
            "content.logos.img",
            "content.img",
            "content.checkMarkItems",
            "content.linkedUser.avatar",
            "content.listItems"
        ],
      });
      return hiring;
    } catch (error) {
      return error;
    }
  },
}));
