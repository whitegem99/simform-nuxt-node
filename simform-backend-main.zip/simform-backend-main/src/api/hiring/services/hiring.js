'use strict';

/**
 * hiring service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::hiring.hiring');
