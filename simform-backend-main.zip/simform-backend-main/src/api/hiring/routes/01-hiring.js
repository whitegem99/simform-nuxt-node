module.exports = {
  routes: [
    {
      method: "GET",
      path: "/hirings/find-by-slug/:slug",
      handler: "hiring.findBySlug",
    },
  ],
};
