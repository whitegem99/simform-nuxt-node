'use strict';

/**
 * hiring router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::hiring.hiring');
