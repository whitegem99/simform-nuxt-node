'use strict';

/**
 * trusted-clients router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::trusted-clients.trusted-clients');
