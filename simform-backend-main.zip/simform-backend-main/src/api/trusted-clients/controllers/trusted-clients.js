'use strict';

/**
 * trusted-clients controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::trusted-clients.trusted-clients');
