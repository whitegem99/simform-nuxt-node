'use strict';

/**
 * trusted-clients service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::trusted-clients.trusted-clients');
