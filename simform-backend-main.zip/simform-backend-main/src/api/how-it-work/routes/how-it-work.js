'use strict';

/**
 * how-it-work router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::how-it-work.how-it-work');
