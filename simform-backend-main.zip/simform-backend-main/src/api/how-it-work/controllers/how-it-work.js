'use strict';

/**
 * how-it-work controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::how-it-work.how-it-work');
