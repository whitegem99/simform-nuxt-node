'use strict';

/**
 * how-it-work service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::how-it-work.how-it-work');
