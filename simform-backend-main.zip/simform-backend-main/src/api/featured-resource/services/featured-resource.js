'use strict';

/**
 * featured-resource service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::featured-resource.featured-resource');
