'use strict';

/**
 * featured-resource controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::featured-resource.featured-resource');
