module.exports = {
  routes: [
    {
      method: "POST",
      path: "/contact-forms/subscribe",
      handler: "contact-form.subscribe",
    },
  ],
};
