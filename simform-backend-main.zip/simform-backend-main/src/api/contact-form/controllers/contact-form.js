"use strict";

/**
 * contact-form controller
 */

const { createCoreController } = require("@strapi/strapi").factories;

module.exports = createCoreController(
  "api::contact-form.contact-form",
  ({ strapi }) => ({
    async subscribe(ctx) {
      console.log(ctx);
      return { dd: "💩" };
    },
  })
);
