"use strict";

/**
 * contact-form service
 */

const { createCoreService } = require("@strapi/strapi").factories;

module.exports = createCoreService(
  "api::contact-form.contact-form",
  ({ strapi }) => ({
    async create(ctx) {
      const { data, files } = ctx;

      let captcha = await strapi
        .plugin("ezforms")
        .service("recaptcha")
        .validate(data.token);

      console.log(data.services);

      if (!!captcha.valid) {
        await super.create(ctx);
        return {
          success: "Saved!",
        };
      }

      return {
        error: "Invalid captcha",
      };
    },
  })
);
