'use strict';

/**
 * case-study controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::case-study.case-study', ({ strapi }) => ({
    async findBySlug(ctx) {
      const { slug } = ctx.params;
      try {
        const caseStudy = await strapi.db.query("api::case-study.case-study").findOne({
          where: { slug },
          populate: ["deep"]
        });
        return caseStudy;
      } catch (error) {
        return error;
      }
    },
  }));
