module.exports = {
    routes: [
      {
        method: "GET",
        path: "/case-studies/find-by-slug/:slug",
        handler: "case-study.findBySlug",
      },
    ],
  };
  