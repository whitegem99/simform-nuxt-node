<template>
  <layout>
    <section>
      <h1
        class="text-5xl text-secondary-900 font-semibold text-center mx-auto leading-tight py-12"
      >
        <span class="text-gray-900"
          >Recent case studies on how <br /><span
            class="bg-clip-text text-transparent bg-gradient-to-r from-secondary-900 to-primary-500"
            >we have helped companies</span
          ></span
        >
      </h1>
      <div class="max-w-6xl mx-auto">
        <div class="py-8" v-for="item in caseStudiesList" :key="item.id">
          <div class="relative">
            <case-study
              :description="item.description"
              :title="item.title"
              :color="item.color"
              :image="item.image"
              :slug="item.slug"
            />
          </div>
        </div>
        <custom-pagination :page="page" :page-count="pageCount" />
      </div>
    </section>
  </layout>
</template>
<script>
import Layout from "../../components/primary/layout/layout.vue";
import CaseStudy from "../../components/feature-components/case-study/case-study.vue";
import { getImage } from "../../helpers/imageHelper";
import CustomPagination from "../../components/primary/pagination/custom-pagination.vue";

export default {
  components: { Layout, CaseStudy, CustomPagination },
  computed: {
    caseStudiesList() {
      return this.caseStudies.map((item) => {
        return {
          title: item.attributes.title,
          description: item.attributes.description,
          color: item.attributes.color,
          image: getImage(item.attributes.image),
          slug: `/case-studies/${item.attributes.slug}`,
        };
      });
    },
  },
  async asyncData({ $strapi }) {
    try {
      const { data: caseStudies, meta: { pagination } } = await $strapi.find("case-studies", {
        populate: "image",
        sort: "publishedAt:DESC",
        "pagination[pageSize]": 1,
        "pagination[page]": 1,
      });

      const { page, pageCount } = pagination;

      return {
        caseStudies,
        page,
        pageCount
      };
    } catch (error) {
      console.log("error", error);
      return {
        caseStudies: [],
      };
    }
  },
  watch: {
    '$route.query': '$fetch'
  },
  async fetch() {
    try {
      const { data: caseStudies, meta: { pagination } } = await this.$strapi.find("case-studies", {
        populate: "image",
        sort: "publishedAt:DESC",
        "pagination[pageSize]": 1,
        "pagination[page]": this.$route.query.page || 1,
      });

      const { page } = pagination;

      this.caseStudies = caseStudies;
      this.page = page;
    } catch (error) {
      console.log("error", error);
    }
  },
  head() {
    const title = `Case Study | ${process.env.APP}`;
    return {
      title,
    };
  },
};
</script>
