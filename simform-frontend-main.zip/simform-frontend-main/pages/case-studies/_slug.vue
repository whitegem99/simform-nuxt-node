<template>
  <layout>
    <div v-for="item in content" :key="`case-studies-${item['__component']}${item.id}`">
      <case-study-hero
        :content="item"
        v-if="item['__component'] === 'case-study.case-study-hero'"
      />
      <case-study-intro
        :content="item"
        v-if="item['__component'] === 'case-study.intro'" />
      <case-study-partner-profile :content="item" v-if="item['__component'] === 'case-study.partner-profile'" />  
      <case-study-image-paragraph-section :content="item" v-if="item['__component'] === 'case-study.image-paragraph'" />
      <case-study-customer-feedback :content="item" v-if="item['__component'] === 'common.customer-feedback-item'" />
      <case-study-paragraph v-else-if="item['__component'] === 'common.paragraph'" :data="item" />
      <video-section v-else-if="item['__component'] === 'common.video'" :data="item" :autoplay="true" />
      <case-study-title v-else-if="item['__component'] === 'common.title'" :data="item" />
      <side-info-paragraph-section v-else-if="item['__component'] === 'case-study.side-info-paragraph'" :data="item" />
      <image-section v-else-if="item['__component'] === 'common.image'" :data="item" />
      <hire-developers-section v-else-if="item['__component'] === 'common.action-banner'" :data="item" withTweak />
      <case-study-bar-paragraph-section v-else-if="item['__component'] === 'case-study.bar-paragraph-section'" :data="item" />
      <case-study-two-column-section v-else-if="item['__component'] === 'case-study.two-column-paragraph-section'" :data="item" />
      <case-study-bar-title-paragraph-list-section v-else-if="item['__component'] === 'case-study.bar-title-paragraph-list'" :data="item" />
      <case-study-recent-section v-else-if="item['__component'] === 'case-study.related-case-studies'" :data="item" />
      <case-study-color-box-items-image-section v-else-if="item['__component'] === 'case-study.case-study-color-box-image-section'" :data="item" />
      <subtitle v-else-if="item['__component'] === 'common.sub-title'" :data="item" />
      <case-study-image-grid v-else-if="item['__component'] === 'case-study.case-study-image-grid'" :data="item" />
      <case-study-color-icon-items-section v-else-if="item['__component'] === 'case-study.case-study-color-icon-items-section'" :data="item" />
      <purple-feature-box-section v-else-if="item['__component'] === 'case-study.purple-feature-section'" :data="item" />
      <case-study-info-section v-else-if="item['__component'] === 'case-study.case-study-info'" :data="item" />
      <info-item-gradient-bg-section v-else-if="item['__component'] === 'case-study.info-item-gradient-bg-section'" :data="item" />
      <case-study-full-width-section v-else-if="item['__component'] === 'case-study.case-study-full-width-section'" :data="item" />
    </div>
  </layout>
</template>
<script>

import Layout from "../../components/primary/layout/layout";
import CaseStudyCustomerFeedback from "../../components/sections/case-study/case-study-customer-feedback.vue";
import CaseStudyHero from "../../components/sections/case-study/case-study-hero.vue";
import CaseStudyImageParagraphSection from "../../components/sections/case-study/case-study-image-paragraph-section.vue";
import CaseStudyIntro from "../../components/sections/case-study/case-study-intro.vue";
import CaseStudyPartnerProfile from "../../components/sections/case-study/case-study-partner-profile.vue";
import TextParagraph from "../../components/primary/paragraph/text-paragraph.vue";
import VideoSection from "../../components/sections/common/video-section.vue";
import CaseStudyTitle from "../../components/sections/case-study/case-study-title.vue";
import SideInfoParagraphSection from "../../components/sections/case-study/side-info-paragraph-section.vue";
import ImageParagraphSection from "../../components/sections/common/image-paragraph-section.vue";
import CaseStudyParagraph from "../../components/sections/case-study/case-study-paragraph.vue";
import ImageSection from "../../components/sections/common/image-section.vue";
import HireDevelopersSection from "../../components/sections/home/hire-developers-section.vue";
import CaseStudyBarParagraphSection from "../../components/sections/case-study/case-study-bar-paragraph-section.vue";
import CaseStudyTwoColumnSection from "../../components/sections/case-study/case-study-two-column-section.vue";
import CaseStudyBarTitleParagraphListSection from "../../components/sections/case-study/case-study-bar-title-paragraph-list-section.vue";
import CaseStudyRecentSection from "../../components/sections/case-study/case-study-recent-section.vue";
import CaseStudyColorBoxItemsImageSection from "../../components/sections/case-study/case-study-color-box-items-image-section.vue";
import Subtitle from "../../components/feature-components/subtitle/subtitle.vue";
import CaseStudyImageGrid from "../../components/sections/case-study/case-study-image-grid.vue";
import CaseStudyColorIconItemsSection from "../../components/sections/case-study/case-study-color-icon-items-section.vue";
import PurpleFeatureBoxSection from "../../components/sections/case-study/purple-feature-box-section.vue";
import CaseStudyInfoSection from "../../components/sections/case-study/case-study-info-section.vue";
import InfoItemGradientBgSection from "../../components/sections/case-study/info-item-gradient-bg-section.vue";
import CaseStudyFullWidthSection from "../../components/sections/case-study/case-study-full-width-section.vue";

export default {
  components: {
    Layout,
    CaseStudyHero,
    CaseStudyIntro,
    CaseStudyPartnerProfile,
    CaseStudyImageParagraphSection,
    CaseStudyCustomerFeedback,
    TextParagraph,
    VideoSection,
    CaseStudyTitle,
    SideInfoParagraphSection,
    ImageParagraphSection,
    CaseStudyParagraph,
    ImageSection,
    HireDevelopersSection,
    CaseStudyBarParagraphSection,
    CaseStudyTwoColumnSection,
    CaseStudyBarTitleParagraphListSection,
    CaseStudyRecentSection,
    CaseStudyColorBoxItemsImageSection,
    Subtitle,
    CaseStudyImageGrid,
    CaseStudyColorIconItemsSection,
    PurpleFeatureBoxSection,
    CaseStudyInfoSection,
    InfoItemGradientBgSection,
    CaseStudyFullWidthSection
},
  async asyncData({ params, $strapi }) {
    try {
      const data = await $strapi.$http.get(
        "/case-studies/find-by-slug/" + params.slug
      );
      const caseStudy = await data.json();

      return {
        caseStudy,
      };
    } catch (error) {
      console.log(error);
    }
  },
  computed: {
    content() {
      return this.caseStudy.content || [];
    },
    imageColor() {
      return this.caseStudy.imageColor;
    },
  },
  head() {
    const title = `${this.caseStudy.miniTitle} | ${process.env.app}}`;
    return {
      title,
    };
  },
};
</script>
