<template>
  <layout>
    <div v-for="item in content" :key="`Hire-${item['__component']}${item.id}`">
      <hiring-form-section
        v-if="item['__component'] === 'common.hiring-hero'"
        :data="item"
      />
      <video-paragraph-section
        v-else-if="item['__component'] === 'common.video-paragraph-section'"
        :data="item"
      />
      <color-boxes-section
        v-else-if="item['__component'] === 'common.color-slider-section'"
        :data="item"
      />
      <client-logo-slider-section
        v-else-if="item['__component'] === 'common.trusted-clients-slider'"
        :data="item"
      />
      <hire-developers-section
        v-else-if="item['__component'] === 'common.action-banner'"
        :data="item"
      />
      <bar-title-section
        v-else-if="item['__component'] === 'common.bar-title-check-mark-list'"
        :data="item"
      />
      <!-- TODO Add slider -->
      <case-study-section
        v-else-if="item['__component'] === 'common.case-study-section'"
        :data="item"
      />
      <testimonial-section
        v-else-if="item['__component'] === 'common.testimonial-videos-slider'"
        :data="item"
      />
      <image-paragraph-section
        v-else-if="item['__component'] === 'common.image-paragraph-section'"
        :data="item"
      />
      <awards-and-recognition-section
        v-else-if="item['__component'] === 'common.awards-section'"
        :data="item"
      />
      <title-underline
        v-else-if="item['__component'] === 'common.title'"
        :data="item"
      />
      <text-paragraph
        v-else-if="item['__component'] === 'common.paragraph'"
        :data="item"
      />
      <subtitle
        v-else-if="item['__component'] === 'common.sub-title'"
        :data="item"
      />
      <light-background-paragraph
        v-else-if="item['__component'] === 'common.light-bg-paragraph'"
        :data="item"
      />
      <app-image
        v-else-if="item['__component'] === 'common.image'"
        :data="item"
      />
      <check-mark-list
        v-else-if="item['__component'] === 'common.check-mark-list'"
        :data="item"
      />
      <app-list
        v-else-if="item['__component'] === 'common.list'"
        :data="item"
      />
      <!-- TODO Add blog section -->
      <blog-section
        v-else-if="item['__component'] === 'common.recent-blogs'"
        :data="item"
      />
      <lets-talk-section
        v-else-if="item['__component'] === 'common.lets-talk'"
        :data="item"
      />
    </div>
  </layout>
</template>
<script>
import Layout from "../../components/primary/layout/layout";
import ClientLogoSliderSection from "../../components/sections/common/client-logo-slider-section.vue";
import BlogSection from "../../components/sections/common/blog-section.vue";
import TestimonialSection from "../../components/sections/common/testimonial-section.vue";
import HireDevelopersSection from "../../components/sections/home/hire-developers-section.vue";
import BarTitleSection from "../../components/sections/common/bar-title-section.vue";
import CaseStudySection from "../../components/sections/home/case-study-section.vue";
import AwardsAndRecognitionSection from "../../components/sections/common/awards-and-recognition-section.vue";
import LetsTalkSection from "../../components/sections/common/lets-talk-section.vue";
import ColorBoxesSection from "../../components/sections/common/color-boxes-section.vue";
import HiringFormSection from "../../components/sections/features/hire/hiring-form-section.vue";
import VideoParagraphSection from "../../components/sections/common/video-paragraph-section.vue";
import ImageParagraphSection from "../../components/sections/common/image-paragraph-section.vue";
import TextParagraph from "../../components/primary/paragraph/text-paragraph.vue";
import TitleUnderline from "../../components/primary/title/title-underline.vue";
import Subtitle from "../../components/primary/title/subtitle.vue";
import LightBackgroundParagraph from "../../components/primary/paragraph/light-background-paragraph.vue";
import AppImage from "../../components/primary/image/image.vue";
import CheckMarkList from "../../components/feature-components/check-mark-list/check-mark-list.vue";
import AppList from "../../components/primary/list/app-list.vue";

export default {
  components: {
    TestimonialSection,
    Layout,
    ClientLogoSliderSection,
    BlogSection,
    HireDevelopersSection,
    BarTitleSection,
    CaseStudySection,
    AwardsAndRecognitionSection,
    LetsTalkSection,
    ColorBoxesSection,
    HiringFormSection,
    VideoParagraphSection,
    ImageParagraphSection,
    TextParagraph,
    TitleUnderline,
    Subtitle,
    LightBackgroundParagraph,
    AppImage,
    CheckMarkList,
    AppList,
  },
  async asyncData({ params, $strapi }) {
    try {
      const data = await $strapi.$http.get(
        "/hirings/find-by-slug/" + params.slug
      );
      const hiring = await data.json();

      return {
        hiring,
      };
    } catch (error) {
      console.log(error);
    }
  },
  computed: {
    content() {
      return this.hiring.content;
    },
  },
  head() {
    const title = `Hire ${this.hiring.title} | ${process.env.APP}}`;
    return {
      title,
    };
  },
};
</script>
