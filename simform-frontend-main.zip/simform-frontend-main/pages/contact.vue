<template>
  <Layout>
    <div class="mt-10 max-w-6xl mx-auto">
      <div class="flex gap-10 mt-10 flex-col sm:flex-row">
        <div class="w-full sm:w-[25%] p-10">
          <h1 class="text-3xl font-bold my-3 mt-10">What will happen next?</h1>
          <p class="my-10">You are a step closer to building great software</p>

          <div class="content-list relative">
            <div class="mb-[1rem] sm:mb-[12rem]">
              <div class="list-bulk">
                <h4 class="font-bold text-base my-2">
                  1. Free technical consultation
                </h4>
                <p>
                  Detailed tech plan includes things like what tech stack to
                  use, tech architecture, timeline, and budget for your project.
                </p>
              </div>
            </div>

            <div class="mb-[1rem] sm:mb-[12rem] list-bulk">
              <h4 class="font-bold text-base my-2">
                2. Connect with the tech team
              </h4>
              <p>
                Over a series of calls, our tech team discusses how different
                technologies and frameworks will bring your vision to life.
              </p>
            </div>

            <div class="mb-[1rem] sm:mb-[12rem] list-bulk">
              <h4 class="font-bold text-base my-2">3. Onboarding the team</h4>
              <p>
                As soon as you sign-off on the team, they’ll be ready to
                integrate into your team—just like in-house employees.
              </p>
            </div>
          </div>
        </div>
        <div class="w-full sm:w-[75%] z-10">
          <div class="contact-form px-20 py-12 relative mt-12">
            <div
              class="flex flex-row gap-2 self-center align-middle content-center justify-items-center"
            >
              <img
                src="~/assets/images/contact-form-icon.svg"
                alt=""
                srcset=""
                class="hidden sm:block"
              />
              <h1 class="font-bold text-2xl flex items-center">
                Get in touch to discuss your project, request a quote or even
                just to pick our brains.
              </h1>
            </div>

            <div class="flex w-full">
              <div class="contact-step-form mt-10 w-full">
                <form ref="contactForm" id="contactFormBuild" url>
                  <div class="steps w-full">
                    <div>
                      <h5 class="font-bold">1. Tell us about your company</h5>

                      <InputText
                        label="Your Name"
                        required
                        name="name"
                      ></InputText>
                      <div class="flex flex-row w-full gap-5">
                        <InputText
                          label="Your Email"
                          required
                          name="email"
                          input-width="1/2"
                        ></InputText>

                        <InputText
                          label="Your Phone Number"
                          name="phone_number"
                          input-width="1/2"
                        ></InputText>
                      </div>

                      <InputText
                        label="Company Website"
                        name="website"
                      ></InputText>
                      <InputText
                        label="What’s your company’s biggest challenge today?"
                        name="company_challenge"
                      ></InputText>
                    </div>

                    <div>
                      <h5 class="font-bold mt-10">
                        2. What are you looking to work on?
                      </h5>
                      <InputTextarea
                        label="Describe your project briefly"
                        required
                        name="description"
                      >
                      </InputTextarea>
                      <InputRangeSlider></InputRangeSlider>
                      <InputFile></InputFile>
                    </div>

                    <div>
                      <h5 class="font-bold mt-10">
                        3. What services are you interested in?
                      </h5>
                      <div class="service-listing my-5">
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                          <ColourCheckbox
                            :label="item.label"
                            name="services"
                            :value="item.name"
                            :color="item.color"
                            v-for="(item, index) in services"
                            :key="index"
                          ></ColourCheckbox>
                        </div>
                      </div>
                    </div>

                    <h5 class="font-bold mt-10">
                      4. Schedule a call with our tech expert. Get a detailed
                      tech consultation for free!
                    </h5>

                    <div class="flex flex-col">
                      <div class="flex flex-row justify-between">
                        <div class="mt-3 block flex-1">
                          <div
                            class="bg-red-500 rounded-full p-2 inline-block"
                          ></div>
                          60 Min Meeting
                        </div>
                        <div class="mt-3 flex-1 justify-self-center">
                          Select a Day
                        </div>
                      </div>

                      <div class="flex flex-row items-center my-4">
                        <div class="w-10">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke-width="1.5"
                            stroke="currentColor"
                            class="w-6 h-6 cursor-pointer"
                            v-on:click="prev_date"
                          >
                            <path
                              stroke-linecap="round"
                              stroke-linejoin="round"
                              d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18"
                            />
                          </svg>
                        </div>
                        <div class="w-auto">
                          <div class="flex flex-row">
                            <div
                              v-for="(item, index) in business_days"
                              :key="index"
                            >
                              <input
                                type="radio"
                                name="selected_day"
                                :id="translated_day(item)"
                                :value="item"
                                class="hidden peer"
                              />
                              <label
                                :for="translated_day(item)"
                                class="p-2 pt-4 rounded-full border-[#6dd8ff] border-2 text-center inline-block bg-[#d3f3ff] w-20 h-20 mx-3 peer-checked:bg-[#6dd8ff] peer-checked:text-white text-sm"
                                v-html="day_to_name(item)"
                              >
                              </label>
                            </div>
                          </div>
                        </div>
                        <div class="w-10">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke-width="1.5"
                            stroke="currentColor"
                            class="w-6 h-6 cursor-pointer"
                            v-on:click="next_date"
                          >
                            <path
                              stroke-linecap="round"
                              stroke-linejoin="round"
                              d="M17.25 8.25L21 12m0 0l-3.75 3.75M21 12H3"
                            />
                          </svg>
                        </div>
                      </div>

                      <div class="flex gap-10">
                        <div class="flex gap-3 items-center">
                          <span class="text-sm">Timezone</span>
                          <select
                            class="form-select form-select-sm appearance-none block w-[72px] px-2 py-1 text-sm font-normal text-gray-700 bg-transparent bg-clip-padding bg-no-repeat border border-solid border-transparent rounded transition ease-in-out m-0 focus:text-gray-700 focus:bg-transparent focus:border-transparent focus:ring-0 focus:outline-none"
                          >
                            <option selected value="EST">EST</option>
                            <option value="MST">MST</option>
                            <option value="PST">PST</option>
                            <option value="CST">CST</option>
                          </select>
                        </div>
                        <div class="flex gap-3 items-center">
                          <span class="text-sm">Schedule Meeting</span>
                          <select
                            class="form-select form-select-sm appearance-none block w-[200px] px-2 py-1 text-sm font-normal text-gray-700 bg-transparent bg-clip-padding bg-no-repeat border border-solid border-transparent rounded transition ease-in-out m-0 focus:text-gray-700 focus:bg-transparent focus:border-transparent focus:ring-0 focus:outline-none"
                          >
                            <option selected value="1">
                              06:00 AM - 07:00 AM
                            </option>
                            <option value="2">07:00 AM - 08:00 AM</option>
                            <option value="3">08:00 AM - 09:00 AM</option>
                            <option value="4">09:00 AM - 10:00 AM</option>
                            <option value="5">10:00 AM - 11:00 AM</option>
                            <option value="6">11:00 AM - 12:00 PM</option>
                            <option value="7">12:00 PM - 01:00 PM</option>
                            <option value="8">01:00 PM - 02:00 PM</option>
                            <option value="9">02:00 PM - 03:00 PM</option>
                            <option value="10">03:00 PM - 04:00 PM</option>
                            <option value="11">04:00 PM - 05:00 PM</option>
                            <option value="12">05:00 PM - 06:00 PM</option>
                            <option value="13">06:00 PM - 07:00 PM</option>
                            <option value="14">07:00 PM - 08:00 PM</option>
                            <option value="15">08:00 PM - 09:00 PM</option>
                            <option value="16">09:00 PM - 10:00 PM</option>
                            <option value="17">10:00 PM - 11:00 PM</option>
                            <option value="18">11:00 PM - 12:00 AM</option>
                          </select>
                        </div>
                      </div>

                      <div class="grid grid-cols-1 sm:grid-cols-4 gap-4 mt-10">
                        <div>
                          <simform-button
                            :on-click="submitForm"
                            size="base"
                            class="justify-self-end flex align-middle sm:w-full"
                            expanded
                          >
                            <span
                              class="flex justify-center items-center uppercase tracking-widest font-semibold mt-[4px]"
                              >SUBMIT</span
                            >
                          </simform-button>
                        </div>
                        <div class="col-span-2 flex items-center">
                          <p class="text-lg font-semibold text-primary-500">
                            Please fill all the required fields
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </Layout>
</template>

<script>
import Layout from "../components/primary/layout/layout.vue";
import InputText from "../components/primary/input/input-text.vue";
import InputTextarea from "../components/primary/input/input-textarea.vue";
import InputRangeSlider from "../components/primary/input/input-range-slider.vue";
import InputFile from "../components/primary/input/input-file.vue";
import ColourCheckbox from "../components/feature-components/contact/colour-checkbox.vue";
import MomentBusinessDays from "moment-business-days";
import CircleDate from "../components/feature-components/contact/circle-date.vue";
import SimformButton from "../components/primary/button/simform-button.vue";

export default {
  name: "Contact",

  components: {
    Layout,
    InputText,
    InputTextarea,
    InputRangeSlider,
    InputFile,
    ColourCheckbox,
    CircleDate,
    SimformButton,
  },

  async mounted() {
    try {
      await this.$recaptcha.init();
    } catch (e) {
      console.error(e);
    }
  },
  head: () => {
    return {
      title: `Contact us | ${process.env.APP}`,
    };
  },
  computed: {
    business_days: function () {
      let startingDay = this.today;
      let dayArray = [startingDay];

      for (let index = 0; index < 5; index++) {
        let newBusinessDay = MomentBusinessDays(
          dayArray[index]
        ).nextBusinessDay()._d;
        dayArray.push(newBusinessDay);
      }

      return dayArray;
    },
  },
  methods: {
    translated_day(day) {
      return `day_radio_${MomentBusinessDays(day).format("DDMMYYYY")}`;
    },
    day_to_name(day) {
      return `<b>${MomentBusinessDays(day).format(
        "DD"
      )}</b><br><span class='break-keep text-xs	'>${MomentBusinessDays(
        day
      ).format("ddd MMM")}<span>`;
    },
    next_date() {
      this.today = MomentBusinessDays(this.today).nextBusinessDay();
    },
    prev_date() {
      this.today = MomentBusinessDays(this.today).prevBusinessDay();
    },
    async submitForm() {
      event.preventDefault();
      if (this.$refs["contactForm"]) {
        const form = this.$refs["contactForm"];

        let data = {};
        const formData = new FormData();

        form.elements.forEach(({ name, type, value, files, ...element }) => {
          if (!["submit", "file"].includes(type)) {
            data[name] = value;
          } else if (type === "file") {
            files.forEach((file) => {
              formData.append(`files.${name}`, file, file.name);
            });
          }
        });

        const token = await this.$recaptcha.execute("login");
        data = { ...data, token };
        new FormData(this.$refs["contactForm"])
          .getAll("services")
          .forEach((item) => {
            data[item] = true;
          });

        formData.append("data", JSON.stringify(data));

        await fetch(`${this.$config.baseURL}/api/contact-forms`, {
          method: "post",
          body: formData,
        });
      }
    },
  },
  data() {
    return {
      selectedDate: undefined,
      services: [
        {
          label: "Web or Mobile Apps Development",
          name: "web_or_mobile_app_dev",
          color: "peach",
        },
        {
          label: "Hire Dedicated Developers",
          name: "hire_dedicated_developers",
          color: "grayblue",
        },
        {
          label: "AI/ML Development Services",
          name: "ai_ml_development",
          color: "emptygreen",
        },
        {
          label: "Custom Software Development",
          name: "custom_software_development",
          color: "dullyellow",
        },
        {
          label: "Software Testing and QA",
          name: "software_testing_and_qa",
          color: "lesspink",
        },
        {
          label: "API Development & Integration",
          name: "api_development_integration",
          color: "peach",
        },
      ],
    };
  },
};
</script>

<style :scoped>
.content-list > .list-bulk::after {
  content: "";
  position: absolute;
  width: 2px;
  background: rgba(145, 225, 255, 0.2);
  left: -26px;
  top: 6px;
  height: 100%;
}

.list-bulk::before {
  content: "";
  width: 18px;
  height: 18px;
  border: 3px solid rgb(255, 255, 255);
  background: rgb(145, 225, 255);
  position: absolute;
  left: -34px;
  border-radius: 50%;
  z-index: 1;
  display: inline-block;
}

.contact-form::after {
  content: "";
  position: absolute;
  width: 100%;
  height: 100%;
  background: rgb(220, 245, 254);
  top: -20px;
  right: -20px;
  z-index: -1;
}

.contact-form {
  background: rgba(235, 250, 255, 0.7);
}

.form-item {
  margin-top: 0.6rem;
  margin-bottom: 0.6rem;
}

.contact-input {
  border: 1px solid rgba(0, 0, 0, 0.2);
}
.contact-input:focus {
  border-color: rgb(119, 218, 254);
}
.contact-label {
  color: rgba(80, 79, 79, 1);
}

.contact-input:focus + .contact-label {
  top: -6px;
  font-size: 11px;
  line-height: 12px;
  padding: 0px 2px;
  background: rgb(231, 248, 255);
  z-index: 9;
}
</style>
