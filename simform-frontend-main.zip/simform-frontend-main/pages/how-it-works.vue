<template>
  <layout>
    <div
      v-for="item in content"
      :key="`how-it-works-${item['__component']}${item.id}`"
    >
      <hero-with-accordion
        :data="item"
        v-if="item['__component'] === 'common.hero-with-accordion'"
      />
      <color-grid-box-section
        :data="item"
        v-else-if="item['__component'] === 'common.color-grid-section'"
      />
      <hire-developers-section
        v-else-if="item['__component'] === 'common.action-banner'"
        :data="item"
        withTweak
      />
    </div>
  </layout>
</template>
<script>
import Layout from "../components/primary/layout/layout";
import FaqSection from "../components/sections/common/faq-section.vue";
import HeroWithAccordion from "../components/sections/common/hero-with-accordion.vue";
import ColorGridBoxSection from "../components/sections/common/color-grid-box-section.vue";
import HireDevelopersSection from "../components/sections/home/hire-developers-section.vue";

export default {
  components: { HeroWithAccordion },
  head: () => {
    return {
      title: `How it works | ${process.env.APP}`,
    };
  },
  async asyncData({ $strapi }) {
    try {
      const data = await $strapi.$http.get("/how-it-work?populate=deep");
      const howItWorks = await data.json();

      return {
        howItWorks,
      };
    } catch (error) {
      console.log(error);
    }
  },
  computed: {
    content() {
      return this.howItWorks?.data.attributes.content;
    },
  },
  components: {
    Layout,
    FaqSection,
    HeroWithAccordion,
    ColorGridBoxSection,
    HireDevelopersSection,
  },
};
</script>
