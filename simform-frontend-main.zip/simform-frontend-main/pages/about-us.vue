<template>
  <layout>
    <div v-for="item in content" :key="`about-${item['__component']}${item.id}`">
      <about-hero :data="item" v-if="item['__component'] === 'about.about-hero'" />
      <dev-stack-section :data="item" v-else-if="item['__component'] === 'about.dev-stack-section'" />
      <about-call-to-action :data="item" v-else-if="item['__component'] === 'about.about-call-to-action'" />
      <about-team-section :data="item" v-else-if="item['__component'] === 'about.team'" />
      <about-more-section :data="item" v-else-if="item['__component'] === 'about.about-more'" />
    </div>
  </layout>
</template>

<script>
import layout from '../components/primary/layout/layout.vue';
import AboutCallToAction from '../components/sections/about/about-call-to-action.vue';
import AboutHero from '../components/sections/about/about-hero.vue';
import AboutMoreSection from '../components/sections/about/about-more-section.vue';
import AboutTeamSection from '../components/sections/about/about-team-section.vue';
import DevStackSection from '../components/sections/about/dev-stack-section.vue';
export default {
  components: { layout, AboutHero, DevStackSection, AboutCallToAction, AboutTeamSection, AboutMoreSection },
  head: () => {
    return {
      title: `About us | ${process.env.APP}`,
    };
  },
  data() {
    return {
      about: {},
    };
  },
  async asyncData({ $strapi }) {
    try {
      const data = await $strapi.$http.get("/about?populate=deep");
      const about = await data.json();

      return {
        about,
      };
    } catch (error) {
      console.log(error);
    }
  },
  computed: {
    content() {
      return this.about.data.attributes.content;
    },
  },
};
</script>
