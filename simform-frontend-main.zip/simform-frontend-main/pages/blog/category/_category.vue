<template>
  <layout>
    <div class="max-w-6xl mx-auto mt-10">
      <div class="my-5">
        <blog-breadcrumb :breadcrumbs="breadcrumbs" />
      </div>
      <div class="my-10">
        <h2 class="text-4xl font-semibold">{{ this.category.attributes.name }}</h2>
      </div>
      <div class="grid grid-cols-8 gap-8">
        <div class="col-span-6" v-if="articles">
          <blog-preview
            v-for="article in articles"
            :key="article.id"
            :article="article"
          />
        </div>
        <div class="col-span-2">
          <blog-side-panel :topics="topics" />
        </div>
      </div>
    </div>
  </layout>
</template>

<script>
import BlogBreadcrumb from '../../../components/feature-components/blog/blog-breadcrumb.vue';
import BlogPreview from "../../../components/feature-components/blog/blog-preview.vue";
import BlogSidePanel from "../../../components/feature-components/blog/blog-side-panel.vue";
import Layout from "../../../components/primary/layout/layout";

export default {
  async asyncData({ $strapi, params }) {
    try {
      const data = await $strapi.$http.get(
        "/articles/find-by-category/" + params.category
      );

      const articles = await data.json()

      const { data: topics } = await $strapi.find("categories");
      const category = topics.find(t => t.attributes.slug === params.category)
      console.log(category)
      
      return {
        articles,
        category,
        topics
      };
    } catch (error) {
      console.log(error);
    }
  },
  computed: {
    breadcrumbs() {
      return [
        {
          to: "/",
          text: "Simform",
        },
        {
          to: "/blog",
          text: "Blog",
        },
        {
          text: this.category.attributes.name,
        }
      ];
    },
  },
  components: { BlogPreview, Layout, BlogSidePanel, BlogBreadcrumb },
  head() {
    const title = `${this.category.attributes.name} | ${process.env.APP}}`;
    return {
      title,
    };
  },
};
</script>
