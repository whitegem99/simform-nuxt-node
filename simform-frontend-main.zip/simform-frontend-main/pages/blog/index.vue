<template>
  <layout>
    <div class="max-w-6xl mx-auto mt-10">
      <div class="grid grid-cols-8 gap-8">
        <div class="col-span-6">
          <blog-preview
            v-for="article in articles"
            :key="article.id"
            :article="article"
          />
          <div class="my-10">
            <custom-pagination :page="page" :page-count="pageCount" />
          </div>
        </div>
        <div class="col-span-2">
          <blog-side-panel :topics="topics" />
        </div>
      </div>
    </div>
  </layout>
</template>
<script>
import BlogPreview from "../../components/feature-components/blog/blog-preview.vue";
import BlogSidePanel from "../../components/feature-components/blog/blog-side-panel.vue";
import Layout from "../../components/primary/layout/layout";
import CustomPagination from '../../components/primary/pagination/custom-pagination.vue';

export default {
  async asyncData({ $strapi }) {
    try {
      const { data: topics } = await $strapi.find("categories");

      const { data: articles, meta: { pagination } } = await $strapi.find("articles", {
        populate: "featuredImage,creator,category,creator.avatar",
        sort: "publishedAt:DESC",
        "pagination[pageSize]": 1,
        "pagination[page]": 1,
      });

      const { page, pageCount } = pagination;

      return {
        articles,
        topics,
        page,
        pageCount
      };
    } catch (error) {
      console.log(error);
    }
  },
  watch: {
    '$route.query': '$fetch'
  },
  async fetch() {
      try {
        const { data: articles, meta: { pagination } } = await this.$strapi.find("articles", {
          populate: "featuredImage,creator,category,creator.avatar",
          sort: "publishedAt:DESC",
          "pagination[pageSize]": 1,
          "pagination[page]": this.$route.query.page || 1,
        });

        const { page } = pagination;

        this.articles = articles;
        this.page = page;
      } catch (error) {
        console.log(error);
      }
    },
  components: { BlogPreview, Layout, BlogSidePanel, CustomPagination },
  head: () => {
    return {
      title: `Insights on Latest Software Technologies | ${process.env.APP} Blog`,
    };
  },
};
</script>
