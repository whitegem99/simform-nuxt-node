<template>
  <Layout>
    <div class="max-w-3xl mx-auto mt-10 text-xl">
      <blog-preview-section :article="article" :author="author" />
    </div>
    <div class="max-w-7xl mx-auto mt-10 text-xl">
      <div class="flex gap-5">
        <div class="max-w-[250px] w-[250px]">
          <share-links :blog-url="this.blogUrl" />
        </div>
        <div class="flex-1">
          <div class="my-8 mb-12 blog-content">
            <div v-for="item in content" :key="`Blog-${item['__component']}${item.id}`">
              <text-paragraph
                v-if="item['__component'] === 'common.paragraph'"
                :data="item"
              />
              <light-background-paragraph
                v-else-if="item['__component'] === 'common.light-bg-paragraph'"
                :data="item"
              />
              <quick-links
                v-else-if="item['__component'] === 'common.quick-links'"
                :items="item.quickLinkItems"
              />
              <title-underline
                v-else-if="item['__component'] === 'common.title'"
                :data="item"
              />
              <app-image
                v-else-if="item['__component'] === 'common.image'"
                :data="item"
              />
              <subtitle
                v-else-if="item['__component'] === 'common.sub-title'"
                :data="item"
              />
              <check-mark-list
                v-else-if="item['__component'] === 'common.check-mark-list'"
                :data="item"
              />
              <app-list
                v-else-if="item['__component'] === 'common.list'"
                :data="item"
              />
              <compare-table
                v-else-if="item['__component'] === 'common.compare-table'"
                :data="item"
              />
            </div>
          </div>
        </div>
        <div class="max-w-[250px] w-[250px]">
          <blog-contact-box-float />
        </div>
      </div>

      <author-section :author="author" />
    </div>
    <newsletter-section />
    <div>
      <blog-section :categorySlug="categorySlug" :postId="postId" />
    </div>
  </Layout>
</template>
<script>
import BlogPreviewSection from "../../components/feature-components/blog/single/blog-preview-section.vue";
import Layout from "../../components/primary/layout/layout";
import TitleUnderline from "../../components/primary/title/title-underline.vue";
import CheckMarkList from "../../components/feature-components/check-mark-list/check-mark-list.vue";
import TextParagraph from "../../components/primary/paragraph/text-paragraph.vue";
import LightBackgroundParagraph from "../../components/primary/paragraph/light-background-paragraph.vue";
import QuickLinks from "../../components/feature-components/quick-links/quick-links.vue";
import AppImage from "../../components/primary/image/image.vue";
import Subtitle from "../../components/primary/title/subtitle.vue";
import AppList from "../../components/primary/list/app-list.vue";
import AuthorSection from "../../components/feature-components/blog/single/author-section.vue";
import NewsletterSection from "../../components/feature-components/blog/single/newsletter-section.vue";
import BlogSection from "../../components/sections/common/blog-section.vue";
import CompareTable from "../../components/feature-components/compare-table/compare-table.vue";
import { getImage } from "../../helpers/imageHelper";
import BlogContactBoxFloat from "../../components/feature-components/blog/single/blog-contact-box-float.vue";
import ShareLinks from '../../components/feature-components/blog/single/share-links.vue';

export default {
  computed: {
    content() {
      return this.article.content;
    },
    author() {
      return {
        name: this.article.creator.fullName,
        username: this.article.creator.username,
        avatar: getImage(this.article.creator.avatar),
        postsBy: `/blog/author/${this.article.creator.username}`,
        description: this.article.creator.description,
        linkedIn: this.article.creator.linkedin,
        twitter: this.article.creator.twitter,
      };
    },
    categorySlug() {
      return this.article.category.slug;
    },
    postId() {
      return this.article.id.toString();
    },
  },
  methods: {
    getListItems(items) {
      return items.map(({ text }) => ({ text }));
    },
  },
  async asyncData({ params, $strapi }) {
    try {
      const data = await $strapi.$http.get(
        "/articles/find-by-slug/" + params.slug
      );
      const article = await data.json();

      const blogUrl = `${process.env.BASE_HOST}/blog/${params.slug}`;

      return {
        article,
        blogUrl,
      };
    } catch (error) {
      console.log(error);
    }
  },
  components: {
    BlogPreviewSection,
    Layout,
    TitleUnderline,
    CheckMarkList,
    TextParagraph,
    LightBackgroundParagraph,
    QuickLinks,
    AppImage,
    Subtitle,
    AppList,
    AuthorSection,
    NewsletterSection,
    BlogSection,
    CompareTable,
    BlogContactBoxFloat,
    ShareLinks,
  },
  head() {
    const title = this.article.displayTitle;
    return {
      title,
    };
  },
};
</script>
