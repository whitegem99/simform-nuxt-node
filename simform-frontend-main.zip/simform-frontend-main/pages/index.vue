<template>
  <layout>
    <div
      v-for="item in content"
      :key="`Index-${item['__component']}${item.id}`"
    >
      <hero :data="item" v-if="item['__component'] === 'common.hero'" />
      <service-slider-section
        v-else-if="item['__component'] === 'common.service-slider'"
      />
      <color-boxes-section
        v-else-if="item['__component'] === 'common.color-slider-section'"
        :data="item"
      />
      <video-paragraph-section
        v-else-if="item['__component'] === 'common.video-paragraph-section'"
        :data="item"
      />
      <client-logo-slider-section
        v-else-if="item['__component'] === 'common.trusted-clients-slider'"
        :data="item"
      />
      <title-underline
        v-else-if="item['__component'] === 'common.title'"
        :data="item"
      />
      <case-study-section
        v-else-if="item['__component'] === 'common.case-study-section'"
        :data="item"
      />
      <testimonial-section
        v-else-if="item['__component'] === 'common.testimonial-videos-slider'"
        :data="item"
        white
      />
      <working-with-us-section
        v-else-if="item['__component'] === 'common.customer-feedback-section'"
        :data="item"
      />
      <advanced-image-paragraph-section
        v-else-if="
          item['__component'] === 'common.advanced-image-paragraph-section'
        "
        :data="item"
      />
      <development-approach-section
        v-else-if="item['__component'] === 'common.color-grid-section'"
        :data="item"
      />
      <tech-stack-section
        v-else-if="item['__component'] === 'common.tech-stack-section'"
        :data="item"
      />
      <how-works-section
        v-else-if="item['__component'] === 'common.animated-color-grid-section'"
        :data="item"
      />
      <guarantee-section
        v-else-if="item['__component'] === 'common.guarantee-section'"
        :data="item"
      />
      <featured-resources-section
        v-else-if="item['__component'] === 'common.recent-blogs'"
        :data="item"
      />
      <hire-developers-section
        v-else-if="item['__component'] === 'common.action-banner'"
        :data="item"
        with-tweak
      />
    </div>
  </layout>
</template>

<script>
import Hero from "../components/sections/common/hero.vue";
import BlogSection from "../components/sections/common/blog-section.vue";
import ClientLogoSliderSection from "../components/sections/common/client-logo-slider-section.vue";
import VideoParagraphSection from "../components/sections/common/video-paragraph-section.vue";
import ServiceSliderSection from "../components/sections/home/service-slider-section.vue";
import TechStackSection from "../components/sections/common/tech-stack-section.vue";
import WorkingWithUsSection from "../components/sections/home/working-with-us-section.vue";
import HireDevelopersSection from "../components/sections/home/hire-developers-section.vue";
import CustomerSaySliderSection from "../components/sections/common/customer-say-slider-section.vue";
import CaseStudySection from "../components/sections/home/case-study-section.vue";
import GuaranteeSection from "../components/sections/common/guarantee-section.vue";
import AdvancedImageParagraphSection from "../components/sections/home/advanced-image-paragraph-section.vue";
import DevelopmentApproachSection from "../components/sections/home/development-approach-section.vue";
import HowWorksSection from "../components/sections/home/how-works-section.vue";
import Layout from "../components/primary/layout/layout.vue";
import HighlightedText from "@/components/primary/highlight-text/highlight-text";
import ColorBoxesSection from "../components/sections/common/color-boxes-section.vue";
import TitleUnderline from "../components/primary/title/title-underline.vue";
import TestimonialSection from "../components/sections/common/testimonial-section.vue";
import FeaturedResourcesSection from "../components/sections/common/featured-resources-section.vue";

export default {
  name: "IndexPage",
  head: {
    title: "Software Development Company in USA",
  },
  async asyncData({ $strapi }) {
    try {
      const { data } = await $strapi.find("home", {
        populate: "deep",
      });

      const { content } = data.attributes;

      return {
        content,
      };
    } catch (error) {
      console.log(error);
    }
  },
  components: {
    HighlightedText,
    Hero,
    BlogSection,
    ClientLogoSliderSection,
    VideoParagraphSection,
    ServiceSliderSection,
    TechStackSection,
    WorkingWithUsSection,
    HireDevelopersSection,
    CaseStudySection,
    CustomerSaySliderSection,
    GuaranteeSection,
    AdvancedImageParagraphSection,
    DevelopmentApproachSection,
    HowWorksSection,
    Layout,
    ColorBoxesSection,
    TitleUnderline,
    TestimonialSection,
    FeaturedResourcesSection,
  },
};
</script>
