<template>
  <layout :withTalkFooter="withTalkFooter" :talkFooterData="talkFooterData">
    <div v-for="item in content" :key="`Services-${item['__component']}${item.id}`">
      <hiring-form-section
        v-if="item['__component'] === 'common.hiring-hero'"
        :data="item"
      />
      <hero :data="item" v-if="item['__component'] === 'common.hero'" />
      <video-paragraph-section
        v-else-if="item['__component'] === 'common.video-paragraph-section'"
        :data="item"
      />
      <client-logo-slider-section
        v-else-if="item['__component'] === 'common.trusted-clients-slider'"
        :data="item"
      />
      <color-boxes-section
        v-else-if="item['__component'] === 'common.color-slider-section'"
        :data="item"
      />
      <image-paragraph-section
        v-else-if="item['__component'] === 'common.image-paragraph-section'"
        :data="item"
      />
      <connected-image-paragraph-section
        v-else-if="
          item['__component'] === 'common.connected-image-paragraph-section'
        "
        :data="item"
      />
      <case-study-section
        v-else-if="item['__component'] === 'common.case-study-section'"
        :data="item"
      />
      <tell-us-about-project-section
        v-else-if="item['__component'] === 'common.tell-us-about-section'"
        :data="item"
      />
      <testimonial-section
        v-else-if="item['__component'] === 'common.testimonial-videos-slider'"
        :data="item"
      />
      <image-titled-activity-flow-section
        v-else-if="item['__component'] === 'common.flow-color-box-section'"
        :data="item"
      />
      <industries-we-serve
        v-else-if="item['__component'] === 'common.industry-section'"
        :data="item"
      />
      <awards-and-recognition-section
        v-else-if="item['__component'] === 'common.awards-section'"
        :data="item"
      />
      <FaqSection
        with-sidebar
        v-else-if="item['__component'] === 'common.faq-section'"
        :data="item"
      />
      <blog-section
        v-else-if="item['__component'] === 'common.recent-blogs'"
        :data="item"
      />
      <bar-title-section
        v-else-if="item['__component'] === 'common.bar-title-check-mark-list'"
        :data="item"
      />
      <from-experts-section
        v-else-if="item['__component'] === 'common.blog-grid'"
        :data="item"
      />
      <lets-talk-section
        v-else-if="item['__component'] === 'common.lets-talk'"
        :data="item"
      />
      <guarantee-section
        v-else-if="item['__component'] === 'common.guarantee-section'"
        :data="item"
      />
      <list-paragraph-section
        v-else-if="item['__component'] === 'common.list-paragraph-section'"
        :data="item"
      />
      <list-column-section
        v-else-if="item['__component'] === 'common.list-column-section'"
        :data="item"
      />
      <hire-developers-section v-else-if="item['__component'] === 'common.action-banner'" :data="item" />
      <image-grid-section v-else-if="item['__component'] === 'common.image-grid-section'" :data="item" />
    </div>
  </layout>
</template>
<script>
import Layout from "../../components/primary/layout/layout";
import ClientLogoSliderSection from "../../components/sections/common/client-logo-slider-section.vue";
import BlogSection from "../../components/sections/common/blog-section.vue";
import TestimonialSection from "../../components/sections/common/testimonial-section.vue";
import HireDevelopersSection from "../../components/sections/home/hire-developers-section.vue";
import BarTitleSection from "../../components/sections/common/bar-title-section.vue";
import CaseStudySection from "../../components/sections/home/case-study-section.vue";
import AwardsAndRecognitionSection from "../../components/sections/common/awards-and-recognition-section.vue";
import LetsTalkSection from "../../components/sections/common/lets-talk-section.vue";
import ColorBoxesSection from "../../components/sections/common/color-boxes-section.vue";
import HiringFormSection from "../../components/sections/features/hire/hiring-form-section.vue";
import VideoParagraphSection from "../../components/sections/common/video-paragraph-section.vue";
import ImageParagraphSection from "../../components/sections/common/image-paragraph-section.vue";
import TextParagraph from "../../components/primary/paragraph/text-paragraph.vue";
import TitleUnderline from "../../components/primary/title/title-underline.vue";
import Subtitle from "../../components/primary/title/subtitle.vue";
import LightBackgroundParagraph from "../../components/primary/paragraph/light-background-paragraph.vue";
import AppImage from "../../components/primary/image/image.vue";
import CheckMarkList from "../../components/feature-components/check-mark-list/check-mark-list.vue";
import AppList from "../../components/primary/list/app-list.vue";
import Hero from "../../components/sections/common/hero.vue";
import ConnectedImageParagraphSection from "../../components/sections/common/connected-image-paragraph-section.vue";
import TellUsAboutProjectSection from "../../components/sections/features/software-development/custom-software-development/tell-us-about-project-section.vue";
import HowWeDevelopAgileSection from "../../components/sections/features/software-development/custom-software-development/how-we-develop-agile-section.vue";
import ImageTitledActivityFlowSection from "../../components/sections/common/image-titled-activity-flow-section.vue";
import IndustriesWeServe from "../../components/sections/common/industries-we-serve.vue";
import FaqSection from "../../components/sections/common/faq-section.vue";
import FromExpertsSection from "../../components/sections/common/from-experts-section.vue";
import GuaranteeSection from "../../components/sections/common/guarantee-section.vue";
import ListParagraphSection from "../../components/sections/common/list-paragraph-section.vue";
import ListColumnSection from "../../components/sections/common/list-column-section.vue";
import ImageGridSection from "../../components/sections/common/image-grid-section.vue";

export default {
  components: {
    TestimonialSection,
    Layout,
    ClientLogoSliderSection,
    BlogSection,
    HireDevelopersSection,
    BarTitleSection,
    CaseStudySection,
    AwardsAndRecognitionSection,
    LetsTalkSection,
    ColorBoxesSection,
    HiringFormSection,
    VideoParagraphSection,
    ImageParagraphSection,
    TextParagraph,
    TitleUnderline,
    Subtitle,
    LightBackgroundParagraph,
    AppImage,
    CheckMarkList,
    AppList,
    Hero,
    ConnectedImageParagraphSection,
    TellUsAboutProjectSection,
    HowWeDevelopAgileSection,
    ImageTitledActivityFlowSection,
    IndustriesWeServe,
    FaqSection,
    FromExpertsSection,
    GuaranteeSection,
    ListParagraphSection,
    ListColumnSection,
    ImageGridSection
},
  async asyncData({ params, $strapi }) {
    try {
      const data = await $strapi.$http.get(
        "/services/find-by-slug/" + params.slug
      );
      const service = await data.json();

      return {
        service,
      };
    } catch (error) {
      console.log(error);
    }
  },
  computed: {
    content() {
      return this.service?.content;
    },
    withTalkFooter() {
      return this.service?.withLetsTalk;
    },
    talkFooterData() {
      return this.service?.letsTalk;
    },
  },
  head() {
    const title = `${this.service.title} Services | ${process.env.APP}`;
    return {
      title,
    };
  },
};
</script>
