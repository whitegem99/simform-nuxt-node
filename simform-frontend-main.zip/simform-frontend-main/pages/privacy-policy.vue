<template>
  <div>Privacy Policy Page</div>
</template>
<script>
export default {};
</script>
