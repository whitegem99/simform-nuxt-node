require("dotenv").config();

export default {
  // Target: https://go.nuxtjs.dev/config-target
  target: "static",
  ssr: true,

  // Global page headers: https://go.nuxtjs.dev/config-head
  head: {
    title: "simform-clone",
    htmlAttrs: {
      lang: "en",
    },
    meta: [
      { charset: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { hid: "description", name: "description", content: "" },
      { name: "format-detection", content: "telephone=no" },
    ],
    link: [{ rel: "icon", type: "image/x-icon", href: "/favicon.ico" }],
  },

  // Global CSS: https://go.nuxtjs.dev/config-css
  css: [
    "@/assets/css/main.css",
    "vue-slick-carousel/dist/vue-slick-carousel.css",
  ],

  // Plugins to run before rendering page: https://go.nuxtjs.dev/config-plugins
  plugins: [
    { src: "~/plugins/vue-plyr", mode: "client" },
    { src: "./plugins/vue-slick-carousel.js" },
    { src: "./plugins/vue-infinite-bar.js" },
    { src: "./plugins/vue-nav-tabs.js" },
    // { src: "./plugins/vue-dragscroll.js" },
  ],

  // Auto import components: https://go.nuxtjs.dev/config-components
  components: true,

  // Modules for dev and build (recommended): https://go.nuxtjs.dev/config-modules
  buildModules: [
    "@nuxt/postcss8",
    "@nuxtjs/google-fonts",
    "@nuxt/image",
    "@nuxtjs/dotenv",
  ],

  tailwindcss: {},

  // Modules: https://go.nuxtjs.dev/config-modules
  modules: ["@nuxtjs/strapi", "@nuxtjs/recaptcha"],

  // Build Configuration: https://go.nuxtjs.dev/config-build
  build: {
    extend(config, ctx) {
      config.node = {
        fs: "empty",
      };
    },
    postcss: {
      plugins: {
        tailwindcss: {},
        autoprefixer: {},
        ...(process.env.NODE_ENV === "production" ? { cssnano: {} } : {}),
      },
    },
    transpile: ["oh-vue-icons"],
  },

  strapi: {
    url: `${process.env.BASE_URL}/api/`,
    entities: ["articles", "categories"],
  },
  loading: {
    color: "red",
    height: "2px",
  },

  googleFonts: {
    families: {
      Nunito: [500, 700],
    },
  },

  recaptcha: {
    hideBadge: false, // Hide badge element (v3 & v2 via size=invisible)
    mode: "base", // Mode: 'base', 'enterprise'
    siteKey: "6LdBEY8kAAAAAI9Jyt_MFbGbk5OMOlMKxoxcJk5-", // Site key for requests
    version: 3,
  },

  publicRuntimeConfig: {
    baseURL: process.env.BASE_URL,
  },
};
