<template>
  <div
    class="mt-12 hover:-translate-y-4 transition-transform ease-in-out duration-500 group"
  >
    <div class="shadow-lg">
      <div class="overflow-hidden h-[115px]">
        <img
          class="w-full object-cover desc hover:opacity-70 transition-opacity ease-in-out duration-500"
          :src="featuredImage.src"
          :alt="featuredImage.alt"
        />
      </div>
      <div class="">
        <div class="px-8 py-6 desc text-left">
          <div class="mb-4">
            <nuxt-link :to="`/blog/${slug}`">
              <div
                class="text-secondary-800 hover:text-primary-600 ease-in-out duration-500 font-semibold text-lg min-h-[30px]"
              >
                {{ title }}
              </div>
            </nuxt-link>
          </div>

          <span
            class="w-[60px] h-[3px] bg-primary-600 rounded mb-4 block"
          ></span>

          <div class="flex">
            <div class="w-20">
              <img
                class="inline-block h-12 w-12 rounded-full"
                :src="userImage.src"
                :alt="userImage.alt"
              />
            </div>
            <div class="flex-1">
              <div class="mb-1 font-semibold text-lg text-primary-600">
                {{ blog.creator.fullName }}
              </div>
              <div class="text-sm font-semibold">
                {{ createdDate }}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { getImage } from "../../../helpers/imageHelper";
export default {
  name: "BlogItem",
  props: {
    blog: {
      type: Object,
      required: true,
    },
  },
  computed: {
    title() {
      return this.blog.attributes?.title || this.blog.title;
    },
    featuredImage() {
      return getImage(
        this.blog.attributes?.featuredImage || this.blog.featuredImage
      );
    },
    slug() {
      return this.blog.attributes?.slug || this.blog.slug;
    },
    userImage() {
      return getImage(this.blog.creator.avatar);
    },
    createdDate() {
      const date = new Date(this.blog.createdAt);
      const formattedDate = date.toLocaleDateString("en-US", {
        month: "long",
        day: "numeric",
        year: "numeric",
      });
      return formattedDate.toUpperCase();
    },
  },
};
</script>

<style scoped>
.item {
  backface-visibility: hidden;
}

.desc {
  -webkit-backface-visibility: hidden;
  transform: translateZ(0) scale(1.05, 1.05);
}
</style>
