<template>
  <div class="mt-12 hover:-translate-y-4 transition-transform ease-in-out duration-500 group">
    <div class="shadow-lg">
      <div class="overflow-hidden">
        <img
          class="h-48 w-full object-cover desc hover:opacity-70 transition-opacity ease-in-out duration-500"
          :src="featuredImage.src"
          :alt="featuredImage.alt"
        />
      </div>
      <div class="">
        <div class="px-8 py-6 desc text-left">
          <h4
            class="mb-4 text-base text-secondary-900 item group-hover:text-primary-600 transition-colors ease-in-out duration-500 text-left">
            {{ title }}
          </h4>
          <span class="w-[60px] h-[3px] bg-primary-600 rounded mb-4 block"></span>
          <nuxt-link class="text-red-600 text-base" :to="`/blog/${slug}`">Read More</nuxt-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { getImage } from '../../../helpers/imageHelper';
export default {
  name: "BlogItem",
  props: {
    blog: {
      type: Object,
      required: true,
    },
  },
  computed: {
    title() {
      return this.blog.attributes?.title || this.blog.title;
    },
    featuredImage() {
      return getImage(this.blog.attributes?.featuredImage || this.blog.featuredImage);
    },
    slug() {
      return this.blog.attributes?.slug || this.blog.slug;
    },
  },
};
</script>

<style scoped>
.item {
  backface-visibility: hidden
}

.desc {
  -webkit-backface-visibility: hidden;
  transform: translateZ(0) scale(1.05, 1.05);
}
</style>
