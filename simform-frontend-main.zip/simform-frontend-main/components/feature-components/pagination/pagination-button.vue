<template>
  <div>
    <nuxt-link :to="toValue" v-if="!selected">
      <button
        class="rounded w-[30px] h-[30px] flex items-center justify-center mx-[6px] text-sm text-secondary-700 hover:bg-primary-500 hover:text-white transition-all cursor-pointer"
      >
        {{ value }}
      </button>
    </nuxt-link>
    <button
      class="rounded w-[30px] h-[30px] flex items-center justify-center mx-[6px] text-sm bg-primary-500 text-white transition-all cursor-default"
      v-else
    >
      {{ value }}
    </button>
  </div>
</template>
<script>
export default {
  props: {
    value: {
      type: Number,
      required: true,
    },
    selected: {
      type: Boolean,
      default: false,
    },
    toValue: {
      type: String,
      required: true,
    },
  },
  computed: {
    additionalClass() {
      return this.selected ? "bg-primary-500 text-white" : "text-secondary-700";
    },
  },
  methods: {},
};
</script>
