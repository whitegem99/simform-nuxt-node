<template>
  <div class="flex justify-center my-16">
    <PaginationButton
      v-for="button in buttonList"
      :key="button"
      :value="button"
      :selected="button === current"
      :toValue="toValue(button)"
    />
  </div>
</template>
<script>
import PaginationButton from "./pagination-button.vue";

export default {
  components: {
    PaginationButton,
  },
  props: {
    pageCount: {
      type: Number,
      default: 10,
    },
    totalCount: {
      type: Number,
      required: true,
    },
    current: {
      type: Number,
      required: true,
    },
    path: {
      type: String,
      required: true,
    },
  },
  computed: {
    buttonList() {
      return Array.from(
        Array(Math.ceil(this.totalCount / this.pageCount)).keys()
      ).map((i) => i + 1);
    },
  },
  methods: {
    toValue(index) {
      return `/${this.path}/${index}`;
    },
  },
};
</script>
