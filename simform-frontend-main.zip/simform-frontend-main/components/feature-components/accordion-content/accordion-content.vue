<template>
  <div class="group">
    <div class="flex gap-10">
      <div
        class="flex-1 flex justify-center items-center group-even:order-first group-odd:order-last py-10"
      >
        <img v-if="image" :src="image.src" :alt="image.alt" class="mx-auto" />
      </div>
      <div class="flex-1">
        <title-underline :data="{ text: data.title, align: 'left' }" small :spaced="false"/>
        <div v-html="data.description" class="text-xl"></div>
        <faqs :faqItems="accordionItems" />
      </div>
    </div>
    <div class="flex justify-center group-last:hidden">
      <img
        alt=""
        src="~/assets/images/accordion-arrows/ltr.svg"
        class="group-even:block group-odd:hidden"
      />
      <img
        alt=""
        src="~/assets/images/accordion-arrows/rtl.svg"
        class="group-even:hidden group-odd:block"
      />
    </div>
  </div>
</template>
<script>
import { getImage } from "../../../helpers/imageHelper";
import TitleUnderline from "../../primary/title/title-underline.vue";
import faqs from "../faq/faqs.vue";

export default {
  components: { faqs, TitleUnderline },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    image() {
      if (!this.data.image) return null;

      return getImage(this.data.image);
    },
    accordionItems() {
      return this.data.items;
    },
  },
};
</script>
