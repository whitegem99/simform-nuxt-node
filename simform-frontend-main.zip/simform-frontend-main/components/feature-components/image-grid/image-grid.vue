<template>
  <div class="my-5">
    <div class="grid grid-cols-4">
      <div v-for="item in gridItems" class="flex flex-col justify-center">
        <div class="mx-auto">
          <img :src="item.image.src" :alt="item.image.alt" class="flex-none" />
        </div>
        <div class="my-10 text-center text-xl font-light px-10">{{ item.text }}</div>
      </div>
    </div>
  </div>
</template>
<script>
import { getImage } from "../../../helpers/imageHelper";

export default {
  props: {
    items: {
      type: Array,
      required: true,
    },
  },
  computed: {
    gridItems() {
      return this.items.map((item) => {
        return {
          image: getImage(item.image),
          text: item.text,
        };
      });
    },
  },
};
</script>
