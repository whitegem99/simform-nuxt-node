<template>
  <div class="mt-10 sm:mx-auto w-full flex flex-col gap-20 mx-10">
    <!-- Images ratio should be 4 : 3 -->

    <div
      class="relative mx-3 sm:mx-0"
      v-for="item in caseStudyItems"
      :key="item.id"
    >
      <div class="mx-auto">
        <case-study
          :description="item.description"
          :title="item.title"
          :color="item.color"
          :image="item.image"
          :slug="`/case-studies/${item.slug}`"
        />
      </div>
    </div>
  </div>
</template>

<script>
import { getImage } from "../../../helpers/imageHelper";
import CaseStudy from "../case-study/case-study.vue";
export default {
  props: {
    caseStudies: {
      type: Array,
      required: true,
    },
  },
  components: { CaseStudy },
  computed: {
    caseStudyItems() {
      return this.caseStudies
        .reverse()
        .slice(0, 3)
        .map((item) => {
          return {
            id: item.id,
            title: (item.attributes || item).title,
            description: `...${(item.attributes || item).description}...`,
            color: (item.attributes || item).color.toLowerCase(),
            image: getImage((item.attributes || item).image),
            slug: (item.attributes || item).slug,
          };
        });
    },
  },
};
</script>
