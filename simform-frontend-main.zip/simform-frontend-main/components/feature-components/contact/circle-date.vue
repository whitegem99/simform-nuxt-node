<template>
  <div
    :class="[
      'w-20 h-20 rounded-full flex flex-col items-center justify-center text-sm border-4 border-sky-400 cursor-pointer transition-all duration-300',
      selectedClass,
    ]"
    @click="$emit('click')"
  >
    <div class="font-bold text-base">{{ day }}</div>
    <div>{{ monthAndDate }}</div>
  </div>
</template>
<script>
export default {
  props: {
    date: {
      type: Date,
      required: true,
    },
    selected: {
      type: Boolean,
      default: false,
    },
  },
  computed: {
    selectedClass: function () {
      if (this.selected) {
        return "bg-sky-400 text-white";
      }
      return "text-slate-700 bg-sky-200";
    },
    day: function () {
      return this.date.toLocaleString("en-us", { weekday: "short" });
    },
    monthAndDate: function () {
      return `${this.date.toLocaleString("en-us", { month: "short" })} ${this.date.getDate()}`;
    },
  },
  methods: {
    toggle() {
      this.selected = !this.selected;
    },
  },
};
</script>
