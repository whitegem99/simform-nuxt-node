<template>
  <div
    :class="[
      'bg-white px-8 py-5 rounded-md flex gap-4 h-20 transition-all duration-300',
      selectedShadow,
    ]"
  >
    <input
      type="checkbox"
      :class="[
        'p-2 border-[3px] focus:outline-none outline-none focus:ring-0 ring-0 transition-all duration-300',
        colorClass,
      ]"
      :name="name"
      :value="value"
      :id="name"
      :checked="checked"
      @change="toggle"
    />

    <label :for="name">{{ label }}</label>
  </div>
</template>
<script>
export default {
  name: "ColourCheckbox",
  data() {
    return {
      checked: false,
    };
  },
  methods: {
    toggle() {
      this.checked = !this.checked;
    },
  },
  props: {
    name: {
      type: String,
      required: true,
    },
    label: {
      type: String,
      required: true,
    },
    color: {
      type: String,
      required: true,
    },
    value: {
      type: String,
      required: true,
    },
  },
  computed: {
    colorClass: function () {
      switch (this.color) {
        case "peach":
          return "text-peach border-peach";
        case "grayblue":
          return "text-grayblue border-grayblue";
        case "emptygreen":
          return "text-emptygreen border-emptygreen";
        case "dullyellow":
          return "text-dullyellow border-dullyellow";
        case "lesspink":
          return "text-lesspink border-lesspink";
        default:
          return "";
      }
    },
    selectedShadow: function () {
      if (this.checked) {
        return "shadow-lg";
      }
      return "";
    },
  },
};
</script>
<style>
.periwinkle {
  background-color: rgb(194, 210, 245);
}
</style>
