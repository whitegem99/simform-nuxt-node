<template>
  <div class="px-10 relative">
    <div class="absolute top-[-30px] right-[15px]">
      <img src="~/assets/images/badge.svg" alt="" />
    </div>
    <div class="bg-white px-5 rounded custom-shadow pb-5 pt-10">
      <div class="text-center">
        <p class="font-semibold text-xl">Request a Free Quote</p>
        <p class="w-2/3 mx-auto font-light">
          Guaranteed Response within One Business Day!
        </p>
      </div>

      <div>
        <form action="" class="flex flex-col gap-5 p-5 pb-0">
          <input
            type="text"
            name="name"
            placeholder="Name"
            id=""
            class="rounded-md border-none bg-white placeholder:text-gray-400 p-4 ring-1 focus:ring-1 ring-secondary-300 focus:ring-primary-500 outline-none transition-all duration-300 font-sans font-light"
          />
          <input
            type="email"
            name="email"
            placeholder="Email"
            id=""
            class="rounded-md border-none bg-white placeholder:text-gray-400 p-4 ring-1 focus:ring-1 ring-secondary-300 focus:ring-primary-500 outline-none transition-all duration-300 font-sans font-light"
          />
          <input
            type="tel"
            name="phone"
            placeholder="Phone Number"
            id=""
            class="rounded-md border-none bg-white placeholder:text-gray-400 p-4 ring-1 focus:ring-1 ring-secondary-300 focus:ring-primary-500 outline-none transition-all duration-300 font-sans font-light"
          />
          <textarea
            name="message"
            placeholder="Tell us about your project"
            id=""
            cols="30"
            rows="5"
            class="rounded-md border-none bg-white placeholder:text-gray-400 p-4 ring-1 focus:ring-1 ring-secondary-300 focus:ring-primary-500 outline-none transition-all duration-300 font-sans font-light"
          ></textarea>
          <SimformButton bold :on-click="() => {}">
            <span
              class="flex justify-center items-center tracking-wide font-semibold mt-[4px]"
              >{{ buttonText }}</span
            >
          </SimformButton>
        </form>

        <div class="p-5 flex gap-2">
          <input
            type="checkbox"
            name="checkbox"
            id="checkbox"
            class="mt-1 w-6 h-6 text-primary-600 outline-none focus:outline-none ring-0 bg-gray-100 rounded border-gray-300 focus:ring-0 mr-1"
          />
          <span class="text-sm mt-1">
            Please send me a Non-Disclosure Agreement for a Confidential
            Consultation
          </span>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import SimformButton from "../../primary/button/simform-button.vue";

export default {
  name: "HiringForm",
  components: { SimformButton },
  props: {
    buttonText: {
      type: String,
      default: "GET STARTED",
    },
  },
};
</script>
<style>
.custom-shadow {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.05), 0 6px 20px 0 rgba(0, 0, 0, 0.05);
}
</style>
