<template>
  <div class="max-w-6xl mx-auto px-10">
    <div v-html="text" class="leading-snug" :class="fontClass"></div>
  </div>
</template>
<script>
export default {
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    text() {
      return this.data.text;
    },
    italic() {
      return this.data.italic;
    },
    fontClass() {
      let fontClass = "font-nexa font-semibold text-3xl";
      if (this.italic) {
        fontClass = "font-merriweather italic text-4xl";
      }
      return fontClass;
    },
  },
};
</script>
