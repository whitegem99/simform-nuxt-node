<template>
  <div class="relative w-[1066px] h-[300px]">
    <div
      class="w-full transition-all duration-300 h-[335px] absolute"
      :class="itemColor"
    >
      &nbsp;
    </div>
    <div
      :class="bgColor"
      class="bg-blend-overlay w-full top-5 right-5 h-[335px] absolute group-hover:translate-x-1 group-hover:-translate-y-1 duration-500 transition-all"
    >
      <div class="flex p-5">
        <div class="h-full flex w-[200px]">
          <img
            src="https://web.archive.org/web/20220523092820oe_/https://www.simform.com/static/1d9acfc/eae5d/swiftshopper-casestudies-thumb%402x.webp"
            alt=""
          />
        </div>
        <div class="pl-5 flex-1 flex justify-between flex-col">
          <div>
            <h3
              class="text-2xl font-extrabold antialiased group-hover:text-primary-500 transition-colors duration-300 ease-in"
            >
              {{ this.title | truncate(20) }}
            </h3>
            <p class="text-lg font-light mt-3">
              {{ this.description | truncate(120) }}
            </p>
          </div>
          <div class="mt-8">
            <span class="line transition-all duration-500 ease-in"></span>
            <nuxt-link
              :to="to"
              class="text-red-600 text-lg group-hover:text-secondary-800 transition-colors duration-500 ease-in"
            >
              <span
                class="text-red-600 text-xl group-hover:text-secondary-800 transition-colors duration-500 ease-in"
              >
                Read Case Study
              </span>
            </nuxt-link>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    caseStudy: {
      type: Object,
      required: true,
    },
  },
  computed: {
    title() {
      return this.caseStudy.title;
    },
    description() {
      return this.caseStudy.description.length > 120
        ? `${this.caseStudy.description.substring(0, 120)}...`
        : this.caseStudy.description;
    },
    itemColor() {
      return `${this.caseStudy.color}`;
    },
    bgColor() {
      return `${this.caseStudy.color}-bg`;
    },
    to() {
      return `/case-studies/${this.caseStudy.slug}`;
    },
  },
  filters: {
    truncate: function (value, cutOff) {
      return value.length > cutOff ? `${value.slice(0, cutOff - 3)}...` : value;
    },
  },
};
</script>
<style scoped>
.pink {
  background: rgb(255, 220, 249);
}

.orange {
  background: rgb(255, 225, 193);
}

.pink-bg {
  background-image: linear-gradient(238deg, #ffe5fab3, #ffe8fbb3);
}

.orange-bg {
  background: linear-gradient(238deg, #fff0e1b3, #ffeedbb3);
}

.cyan {
  background: rgb(194, 244, 240);
}

.cyan-bg {
  background-image: linear-gradient(
    113deg,
    rgba(222, 255, 252, 0.7),
    rgba(207, 254, 250, 0.7)
  );
}

.yellow {
  background: rgb(255, 225, 193);
}

.yellow-bg {
  background-image: linear-gradient(
    113deg,
    rgba(255, 241, 222, 0.7),
    rgba(255, 237, 213, 0.7)
  );
}

.sky {
  background: rgb(204, 239, 253);
}

.sky-bg {
  background-image: linear-gradient(
    247deg,
    rgba(226, 247, 255, 0.7) 100%,
    rgba(225, 246, 255, 0.7) 0%
  );
}

.green {
  background: rgb(186, 229, 151);
}

.green-bg {
  background-image: linear-gradient(
    247deg,
    rgba(209, 231, 191, 0.7),
    rgba(222, 254, 197, 0.7)
  );
}

.gray {
  background: rgb(226, 222, 222);
}

.gray-bg {
  background-image: linear-gradient(
    247deg,
    rgba(242, 242, 242, 0.7),
    rgba(245, 245, 245, 0.7)
  );
}

.red {
  background: rgb(249, 187, 192);
}

.red-bg {
  background-image: linear-gradient(
    247deg,
    rgba(255, 220, 222, 0.7),
    rgba(252, 212, 215, 0.7)
  );
}

.line {
  width: 60px;
  height: 3px;
  background: rgb(239, 83, 102);
  border-radius: 1px;
  margin-bottom: 25px;
  display: block;
  transition: all 0.5s ease 0s;
  position: relative;
}
</style>
