<template>
  <nuxt-link
    :to="slug"
    class="group content w-full sm:w-[1066px] block h-[700px] sm:h-[500px] px-3 sm:px-0"
  >
    <div
      class="w-full transition-all duration-300 case-study-wrap h-[700px] sm:h-[505px] absolute"
      :class="color"
    >
      &nbsp;
    </div>
    <div
      :class="`${color}-bg`"
      class="bg-blend-overlay w-full case-study-bg top-5 right-5 h-[700px] sm:h-[505px] absolute group-hover:translate-x-1 group-hover:-translate-y-1 duration-500 transition-all"
    >
      <div class="grid grid-cols-1 sm:grid-cols-2 h-full">
        <div class="pl-16 pr-20 py-10 flex flex-col justify-center">
          <h3
            class="text-xl sm:text-3xl font-extrabold antialiased group-hover:text-primary-500 transition-colors duration-300 ease-in"
          >
            {{ this.title }}
          </h3>
          <p class="text-md sm:text-xl font-medium mt-5">
            ...{{ this.description }}...
          </p>
          <div class="mt-10">
            <span class="line transition-all duration-500 ease-in"></span>
            <span
              class="text-red-600 text-xl group-hover:text-secondary-800 transition-colors duration-500 ease-in"
            >
              Read More
            </span>
          </div>
        </div>
        <div>
          <div class="sm:h-full flex items-end">
            <img :src="image.src" :alt="image.alt" class="h-1/4 sm:h-auto" />
          </div>
        </div>
      </div>
    </div>
  </nuxt-link>
</template>

<script>
export default {
  props: {
    title: String,
    description: String,
    color: String,
    image: Object,
    slug: String,
  },
};
</script>

<style scoped>
.content:hover .line::before {
  content: "";
  height: 100%;
  background: rgb(0, 0, 0);
  position: absolute;
  top: 0;
  left: 0;
  transition: all 0.5s ease 0s;
  animation: fill-line 0.3s linear;
  animation-fill-mode: forwards;
}

.line {
  width: 60px;
  height: 3px;
  background: rgb(239, 83, 102);
  border-radius: 1px;
  margin-bottom: 25px;
  display: block;
  transition: all 0.5s ease 0s;
  position: relative;
}

@keyframes fill-line {
  0% {
    width: 0;
  }
  100% {
    width: 100%;
  }
}

.cyan {
  background: rgb(194, 244, 240);
}

.cyan-bg {
  background-image: linear-gradient(
    113deg,
    rgba(222, 255, 252, 0.7),
    rgba(207, 254, 250, 0.7)
  );
}

.yellow {
  background: rgb(255, 225, 193);
}

.yellow-bg {
  background-image: linear-gradient(
    113deg,
    rgba(255, 241, 222, 0.7),
    rgba(255, 237, 213, 0.7)
  );
}

.sky {
  background: rgb(204, 239, 253);
}

.sky-bg {
  background-image: linear-gradient(
    247deg,
    rgba(226, 247, 255, 0.7) 100%,
    rgba(225, 246, 255, 0.7) 0%
  );
}

.green {
  background: rgb(186, 229, 151);
}

.green-bg {
  background-image: linear-gradient(
    247deg,
    rgba(209, 231, 191, 0.7),
    rgba(222, 254, 197, 0.7)
  );
}

.gray {
  background: rgb(226, 222, 222);
}

.gray-bg {
  background-image: linear-gradient(
    247deg,
    rgba(242, 242, 242, 0.7),
    rgba(245, 245, 245, 0.7)
  );
}

.red {
  background: rgb(249, 187, 192);
}

.red-bg {
  background-image: linear-gradient(
    247deg,
    rgba(255, 220, 222, 0.7),
    rgba(252, 212, 215, 0.7)
  );
}
</style>
