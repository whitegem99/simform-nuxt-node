<template>
  <div class="group grid grid-cols-1 lg:grid-cols-2 gap-5 my-5">
    <div
      class="px-10 text-light"
    >
      <img :src="image.src" :alt="image.alt" />
    </div>
    <div class="py-5 px-5 order-first lg:group-even:order-first lg:group-odd:order-last">
      <div class="text-3xl font-bold mb-3" v-html="title"></div>
      <div class="text-xl">
        <div v-html="paragraph" v-if="paragraph" class="font-light"></div>
        <ul class="mt-3 leading-2 pt-4" v-if="list">
          <li
            v-for="(item, index) in list"
            :key="index"
            class="flex items-start font-semibold"
          >
            <div class="h-10 pr-2">
              <check-mark v-if = "type === 'check'"/>
              <dot-mark v-else/>
            </div>
            <div class="text-bold text-[22px] pb-2" v-html="item.text"></div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
<script>
import CheckMark from "../../primary/checkmark/check-mark.vue";
import DotMark from "../../primary/checkmark/dot-mark.vue";

export default {
  props: {
    image: {
      type: Object,
      required: true,
    },
    title: {
      type: String,
      required: true,
    },
    list: {
      type: Array,
    },
    paragraph: {
      type: String,
    },
    type: {
      type: String,
      default: "dot",
    },
  },
  computed: {
    reversed() {
      return this.reversedLayout ? "order-last" : "order-0";
    },
  },
  components: { DotMark, CheckMark },
  name: "ImageParagraph",
};
</script>
