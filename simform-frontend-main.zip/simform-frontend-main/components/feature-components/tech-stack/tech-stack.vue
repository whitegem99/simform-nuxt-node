<template>
  <tabs @select-tab="selected" :tabs="tabs" :default-select="tabs[0].key">
    <div class="flex flex-wrap justify-center gap-1">
      <div
        v-for="(item, index) in selectedItem.items"
        :key="`${item.key}-${index}`"
        class="w-[160px] bg-gray-100 min-h-[100px]"
      >
        <img :src="item.src" :alt="item.alt" />
      </div>
    </div>
  </tabs>
</template>

<script>
import Tabs from "../../primary/tabs/tabs.vue";

export default {
  components: { Tabs },
  data() {
    return {
      selectedItem: this.tabs[0],
    };
  },
  props: {
    tabs: {
      type: Array,
      required: true,
    },
  },
  methods: {
    selected(item) {
      this.selectedItem = item;
    },
  },
};
</script>
