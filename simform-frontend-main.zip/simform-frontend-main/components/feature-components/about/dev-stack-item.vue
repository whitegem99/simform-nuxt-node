<template>
  <div class="group">
    <div
      class="rounded relative py-10 flex items-center min-h-60"
      :class="`bg-gradient-to-br from-${color}-200 to-${color}-400`"
    >
      <div class="w-[136px] relative h-32">
        <div
          class="-translate-y-1/2 -rotate-90 absolute text-center font-semibold mt-16"
        >
          <div>
            {{ title }}
          </div>
        </div>
      </div>
      <div class="flex-1 relative">
        <div
          class="flex flex-wrap gap-4 justify-center text-secondary-700 text-sm font-bold leading-6 rounded-lg w-full"
        >
          <div
            v-for="item in textItems"
            :key="`dev-stack-item-${data.id}-${item.id}`"
            class="p-4 w-1/4 rounded-lg flex bg-white shadow-lg justify-center items-center"
          >
            <div>
              {{ item.text }}
            </div>
          </div>
        </div>
        <!-- separator row -->
        <div class="absolute z-10 w-full bottom-[-70px] group-last:hidden">
          <div class="flex justify-around">
            <div class="h-9 w-1 border-l-4 border-dotted border-cyan-300"></div>
            <div class="h-9 w-1 border-l-4 border-dotted border-cyan-300"></div>
            <div class="h-9 w-1 border-l-4 border-dotted border-cyan-300"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    data: {
      type: Object,
      default: {},
    },
  },
  computed: {
    title() {
      return this.data.title;
    },
    color() {
      return this.data.color;
    },
    outsideTitle() {
      return this.data.outsideTitle;
    },
    textItems() {
      return this.data.items;
    },
  },
};
</script>
