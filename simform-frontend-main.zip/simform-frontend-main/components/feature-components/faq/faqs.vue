<template>
  <div class="max-w-6xl mx-auto">
    <div>
      <div class="my-10">
        <accordion-item
          :title="item.title"
          @toggle-item="toggleItem"
          :on-my-event="myEventSource"
          v-for="(item, index) in faqItems"
          :key="index"
        >
          <div v-html="item.description" class="faq max-h-40 font-light overflow-y-auto overflow-x-hidden"></div>
        </accordion-item>
      </div>
    </div>
  </div>
</template>
<script>
import Button from "../../primary/button/simform-button.vue";
import AccordionItem from "../../primary/accordian/accordion-item.vue";
import {newEventSource} from "vue-parent-emit";

export default {
  components: {Button, AccordionItem},
  props: {
    faqItems: {
      type: Array,
      required: true,
    },
  },
  methods: {
    toggleItem(id) {
      this.myEventSource.emit(id);
    },
  },
  data() {
    return {
      myEventSource: newEventSource(),
    };
  },
};
</script>
<style scoped>
.faq ul {
  @apply list-disc list-inside py-3;
}
</style>
