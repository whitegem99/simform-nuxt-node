<template>
  <div class="bg-[#cae8f8] flex align-middle justify-center flex-col">
    <img :src="image.src" :alt="image.alt" />
    <div class="px-10 pb-10 ">
      <h4 class="text-xl mt-2 text-center">{{ data.title }}</h4>
      <p class="mt-1 text-center font-light my-4">
        {{ data.description }}
      </p>
      <div class="w-full flex justify-center">
        <simform-button reverse class="mt-2" :url="data.button.link"
        >
        <span class="font-bold text-sm text-primary-600 group-hover:text-white transition-all duration-300 px-5">
          {{ data.button.text }}
        </span>
        </simform-button
      >
      </div>
    </div>
  </div>
</template>
<script>
import { getImage } from "../../../helpers/imageHelper";
import SimformButton from "../../primary/button/simform-button.vue";

export default {
  components: {
    SimformButton,
  },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    image() {
      return getImage(this.data.image);
    },
  },
};
</script>
