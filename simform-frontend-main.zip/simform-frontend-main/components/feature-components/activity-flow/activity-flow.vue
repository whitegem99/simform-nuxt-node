<template>
  <div class="max-w-7xl mx-auto mt-10">
    <div class="flex gap-[30px]">
      <color-box-item
        v-for="(item, index) in items"
        :key="item.title"
        :item="item"
        :index="index"
        with-x-arrow
        isTop
        :is-last="index === items.length - 1"
      />
    </div>
    <div class="-mt-2 w-full m-auto">
      <img
        src="~/assets/images/services/custom_agile/icons/footer_arrow.svg"
        class="m-auto block"
        alt=""
      />
    </div>
  </div>
</template>
<script>
import ColorBoxItem from "../color-box-item/color-box-item.vue";

export default {
  props: {
    items: {
      type: Array,
      required: true,
    },
  },
  components: { ColorBoxItem },
};
</script>
