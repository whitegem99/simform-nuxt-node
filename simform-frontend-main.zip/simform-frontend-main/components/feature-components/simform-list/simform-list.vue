<template>
  <div>
    <div v-for="item in list" class="flex gap-3 mb-8 items-center">
      <check-mark v-if="withCheckMark"/>
      <p class="font-merriweather font-medium italic text-xl lg:text-2xl">{{item}}</p>
    </div>
  </div>
</template>

<script>
import CheckMark from "@/components/primary/checkmark/check-mark";
export default {
  name: "simform-list",
  components: {CheckMark},
  props: {
    list: {
      type: Array,
      required: true
    },
    withCheckMark: {
      type: Boolean,
      default: false,
    }
  },
}
</script>
