<template>
  <div
    class="even:mt-10 p-5 shadow-md mx-3 rounded-sm min-w-[240px] w-[240px] h-[240px] min-h-[240px] flex items-center justify-center bg-white"
  >
    <img :src="image.src" :alt="image.alt" />
  </div>
</template>
<script>
export default {
  props: {
    image: {
      type: Object,
      required: true,
    },
  },
};
</script>
<style lang=""></style>
