<template lang="">
  <div
    class="h-[265px] w-full border"
    :class="getColor(item.color).border"
  >
    <div>
      <div class="h-[30px] flex justify-end">
        <span
          class="font-bold w-[30px] flex justify-center items-center"
          :class="[getColor(item.color).bg, getColor(item.color).text]"
          >{{ index + 1 }}</span
        >
      </div>
      <div class="h-[235px] px-5 pb-5">
        <div class="mb-2">
          <img :src="item.image.src" :alt="item.image.alt" />
        </div>
        <div class="my-1">
          <h4 class="text-[20px] font-semibold mb-1">{{ item.title }}</h4>
          <div class="text-[17px] font-light" v-html="item.description"></div>
        </div>
      </div>
    </div>

    <div
      class="w-full flex justify-center -mt-2"
      :class="isTop ? '-mt-2' : '-mt-[298px]'"
      v-if="withYArrow && !isLast"
    >
      <img
        :src="arrowImages[index].src"
        :alt="arrowImages[index].alt"
      />
    </div>
    <div
      class="w-full flex justify-end ml-5 -mt-[133px]"
      v-if="withXArrow && !isLast"
    >
      <img
        :src="arrowImages[index].src"
        :alt="arrowImages[index].alt"
        class="-rotate-90"
      />
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      arrowImages: [
        {
          src: require("assets/images/arrows/flow-arrow1.svg"),
          alt: "flow-arrow1",
        },
        {
          src: require("assets/images/arrows/flow-arrow2.svg"),
          alt: "flow-arrow2",
        },
        {
          src: require("assets/images/arrows/flow-arrow3.svg"),
          alt: "flow-arrow3",
        },
        {
          src: require("assets/images/arrows/flow-arrow4.svg"),
          alt: "flow-arrow4",
        },
        {
          src: require("assets/images/arrows/flow-arrow5.svg"),
          alt: "flow-arrow5",
        },
        {
          src: require("assets/images/arrows/flow-arrow6.svg"),
          alt: "flow-arrow6",
        },
      ],
    };
  },
  props: {
    item: {
      type: Object,
      required: true,
    },
    index: {
      type: Number,
      required: true,
    },
    isTop: {
      type: Boolean,
      default: false,
    },
    withYArrow: {
      type: Boolean,
      default: false,
    },
    withXArrow: {
      type: Boolean,
      default: false,
    },
    isLast: {
      type: Boolean,
      default: false,
    },
  },
  methods: {
    getColor(color) {
      switch (color) {
        case "blue":
          return {
            bg: "bg-[#eaf1ff]",
            text: "text-[#698ede]",
            border: "border-[#c4d1ea]",
          };
        case "green":
          return {
            bg: "bg-[#e5ffe9]",
            text: "text-[#5db86b]",
            border: "border-[#b6e7bd]",
          };
        case "yellow":
          return {
            bg: "bg-[#fff4dc]",
            text: "text-[#edb441]",
            border: "border-[#ead8b2]",
          };
        case "purple":
          return {
            bg: "bg-[#f5e8ff]",
            text: "text-[#9a64c3]",
            border: "border-[#dfcbee]",
          };
        case "orange":
          return {
            bg: "bg-[#fff0e5]",
            text: "text-[#f78761]",
            border: "border-[#fcd9c3]",
          };
        case "sky":
          return {
            bg: "bg-[#ddf0ff]",
            text: "text-[#65a1d2]",
            border: "border-[#b8dffd]",
          };
        case "gray":
          return {
            bg: "bg-[#f1f1f1]",
            text: "text-[#888888]",
            border: "border-[#dcdcdc]",
          };
        case "teal":
          return {
            bg: "bg-[#e3fffd]",
            text: "text-[#3ebcb6]",
            border: "border-[#b5ebe7]",
          };
        case "red":
          return {
            bg: "bg-[#ffefef]",
            text: "text-[#d28585]",
            border: "border-[#f3cccc]",
          };
        case "olive":
          return {
            bg: "bg-[#fffde6]",
            text: "text-[#a5a271]",
            border: "border-[#e7e4bb]",
          };
        default:
          return {
            bg: "bg-[#eaf1ff]",
            text: "text-[#698ede]",
            border: "border-[#c4d1ea]",
          };
      }
    },
  },
};
</script>
