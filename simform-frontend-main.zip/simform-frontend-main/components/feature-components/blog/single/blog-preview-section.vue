<template>
  <div>
    <div class="mb-4">
      <div class="my-10">
        <blog-breadcrumb :breadcrumbs="breadcrumbs" />
      </div>
      <h2 class="text-5xl font-bold leading-none bolder">
        {{ displayTitle }}
      </h2>
      <div class="font-merriweather py-4 text-xl italic">
        {{ summary }}
      </div>
    </div>
    <div class="flex items-center">
      <div class="w-20">
        <avatar :src="author.avatar.src" :alt="author.avatar.alt" />
      </div>
      <div class="flex flex-col flex-grow h-14 pt-2">
        <div class="flex">
          <nuxt-link
            :to="authorUrl"
            class="text-lg font-semibold text-primary-600"
          >
            {{ author.name }}
          </nuxt-link>
        </div>
        <div class="flex gap-2 items-center justify-between">
          <span class="font-base text-slate-500 text-base">
            {{ publishedDate }}
          </span>
          <div class="flex items-end justify-end gap-2">
            <svg
              id="Layer_1"
              data-name="Layer 1"
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              class="w-6 h-6 text-slate-400"
            >
              <path
                fill="currentColor"
                d="M15.09814,12.63379,13,11.42285V7a1,1,0,0,0-2,0v5a.99985.99985,0,0,0,.5.86621l2.59814,1.5a1.00016,1.00016,0,1,0,1-1.73242ZM12,2A10,10,0,1,0,22,12,10.01114,10.01114,0,0,0,12,2Zm0,18a8,8,0,1,1,8-8A8.00917,8.00917,0,0,1,12,20Z"
              />
            </svg>

            <span class="text-slate-600 h-5 text-base mr-2"
              >{{ readingTime }} mins read</span
            >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke-width="1.5"
              stroke="currentColor"
              class="w-6 h-6 text-slate-400"
            >
              <path
                stroke-linecap="round"
                stroke-linejoin="round"
                d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75m-18 0v-7.5A2.25 2.25 0 015.25 9h13.5A2.25 2.25 0 0121 11.25v7.5"
              />
            </svg>
            <span class="text-slate-600 h-5 text-base"
              >Last Updated {{ lastUpdatedDate }}</span
            >
          </div>
        </div>
      </div>
    </div>
    <div class="my-14">
      <img :src="featuredImage.src" :alt="featuredImage.alt" />
    </div>
    <div class="italic font-merriweather text-xl leading-relaxed font-light">
      <span class="text-primary-600 font-bold">Quick Summary :-</span>
      {{ quickSummary }}
    </div>
  </div>
</template>
<script>
import { getImage } from "../../../../helpers/imageHelper";
import Avatar from "../../../primary/avatar/avatar.vue";
import BlogBreadcrumb from "../blog-breadcrumb.vue";

export default {
  props: {
    article: {
      type: Object,
      required: true,
    },
    author: {
      type: Object,
      required: true,
    },
  },
  components: { BlogBreadcrumb, Avatar },
  data() {
    return {
      readingTime: 0,
    };
  },
  computed: {
    category() {
      return {
        name: this.article?.category.name,
        slug: this.article?.category.slug || "/",
      };
    },
    publishedDate() {
      return new Date(this.article?.publishedAt).toLocaleDateString("en-us", {
        year: "numeric",
        month: "short",
        day: "numeric",
      });
    },
    lastUpdatedDate() {
      return new Date(this.article?.updatedAt).toLocaleDateString("en-us", {
        year: "numeric",
        month: "short",
        day: "numeric",
      });
    },
    featuredImage() {
      return getImage(this.article.featuredImage);
    },
    quickSummary() {
      return this.article.quickSummary;
    },
    summary() {
      return this.article.summary;
    },
    title() {
      return this.article.title;
    },
    displayTitle() {
      return this.article.displayTitle;
    },
    miniTitle() {
      return this.article.miniTitle;
    },
    breadcrumbs() {
      return [
        {
          to: "/",
          text: "Simform",
        },
        {
          to: "/blog",
          text: "Blog",
        },
        {
          to: `/blog/category/${this.category.slug}`,
          text: this.category.name,
        },
        {
          text: this.title,
        },
      ];
    },
    authorUrl: function () {
      return `/author/${this.author.username}`;
    },
  },
  mounted() {
    this.readingTime = Math.ceil(
      document
        .getElementsByClassName("blog-content")[0]
        .innerText.replace(/(\r\n|\n|\r)/gm, "")
        .split(" ").length / 225
    );
  },
};
</script>
<style>
.bolder {
  font-weight: 800;
}
</style>
