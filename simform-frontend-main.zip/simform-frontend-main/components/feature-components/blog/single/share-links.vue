<template>
  <div class="flex flex-col gap-5 my-5 sticky top-24">
    <!-- facebook -->
    <a
      :href="`https://www.facebook.com/sharer/sharer.php?u=${blogUrl}`"
      target="_blank"
    >
      <span
        class="text-xl font-bold text-white bg-primary-600 w-11 h-11 flex rounded-full justify-center items-center"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          data-name="Layer 1"
          viewBox="0 0 24 24"
          class="w-6 h-6"
        >
          <path
            fill="currentColor"
            d="M15.12,5.32H17V2.14A26.11,26.11,0,0,0,14.26,2C11.54,2,9.68,3.66,9.68,6.7V9.32H6.61v3.56H9.68V22h3.68V12.88h3.06l.46-3.56H13.36V7.05C13.36,6,13.64,5.32,15.12,5.32Z"
          />
        </svg>
      </span>
    </a>
    <!-- twitter -->
    <a :href="`http://twitter.com/share?&url=${blogUrl}`" target="_blank">
      <span
        class="text-xl font-bold text-white bg-primary-600 w-11 h-11 flex rounded-full justify-center items-center"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          data-name="Layer 1"
          viewBox="0 0 24 24"
          class="w-6 h-6"
        >
          <path
            fill="currentColor"
            d="M22,5.8a8.49,8.49,0,0,1-2.36.64,4.13,4.13,0,0,0,1.81-2.27,8.21,8.21,0,0,1-2.61,1,4.1,4.1,0,0,0-7,3.74A11.64,11.64,0,0,1,3.39,4.62a4.16,4.16,0,0,0-.55,2.07A4.09,4.09,0,0,0,4.66,10.1,4.05,4.05,0,0,1,2.8,9.59v.05a4.1,4.1,0,0,0,3.3,4A3.93,3.93,0,0,1,5,13.81a4.9,4.9,0,0,1-.77-.07,4.11,4.11,0,0,0,3.83,2.84A8.22,8.22,0,0,1,3,18.34a7.93,7.93,0,0,1-1-.06,11.57,11.57,0,0,0,6.29,1.85A11.59,11.59,0,0,0,20,8.45c0-.17,0-.35,0-.53A8.43,8.43,0,0,0,22,5.8Z"
          />
        </svg>
      </span>
    </a>
    <!-- linkedin -->
    <a
      :href="`https://www.linkedin.com/sharing/share-offsite/?url=${blogUrl}`"
      target="_blank"
    >
      <span
        class="text-xl font-bold text-white bg-primary-600 w-11 h-11 flex rounded-full justify-center items-center"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 124 124"
          class="w-6 h-6"
        >
          <path
            fill="currentColor"
            d="M102.4 70.7v28.5c0 .7-.6 1.3-1.3 1.3H86.4c-.7 0-1.3-.6-1.3-1.3V72.7c0-7-2.5-11.8-8.8-11.8-4.8 0-7.6 3.2-8.9 6.3-.5 1.1-.6 2.7-.6 4.2v27.8c0 .7-.6 1.3-1.3 1.3H50.9c-.7 0-1.3-.6-1.3-1.3 0-7.1.2-41.4 0-49.4 0-.7.6-1.3 1.3-1.3h14.7c.7 0 1.3.6 1.3 1.3v6.1c0 .1-.1.1-.1.2h.1v-.2c2.3-3.5 6.4-8.6 15.6-8.6 11.4 0 19.9 7.5 19.9 23.4zM24 100.6h14.7c.7 0 1.3-.6 1.3-1.3V49.8c0-.7-.6-1.3-1.3-1.3H24c-.7 0-1.3.6-1.3 1.3v49.5c.1.7.6 1.3 1.3 1.3z"
          />
          <circle cx="30.9" cy="32.7" r="9.3" fill="currentColor" />
        </svg>
      </span>
    </a>
  </div>
</template>
<script>
export default {
  props: {
    blogUrl: {
      type: String,
      default: "",
    },
  },
};
</script>
