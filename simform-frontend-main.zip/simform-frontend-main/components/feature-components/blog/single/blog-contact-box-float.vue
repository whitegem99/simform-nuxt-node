<template>
  <div class="sticky top-20 bg-white p-4 rounded shadow-sm w-full">
    <h5 class="font-bold">Get in Touch</h5>
    <small class="mt-2">
      Leverage the power of {{ category?.name }} and accelerate your application
      development.
    </small>
    <form ref="contactForm">
      <InputText label="First Name" required name="name"></InputText>
      <InputText label="Email" required name="email"></InputText>
      <InputTextarea label="Message" required name="message"> </InputTextarea>
      <simform-button
        :on-click="submitForm"
        size="base"
        class="justify-self-end flex align-middle"
        expanded
      >
        <span
          class="flex justify-center items-center uppercase tracking-widest font-semibold mt-[4px]"
          >SUBMIT</span
        >
      </simform-button>
    </form>
  </div>
</template>
<script>
import InputText from "../../../primary/input/input-text.vue";
import InputTextarea from "../../../primary/input/input-textarea.vue";
import SimformButton from "../../../primary/button/simform-button.vue";

export default {
  name: "BlogContactBoxFloat",
  props: {
    category: {
      type: Object,
      required: false,
    },
  },
  components: { InputText, InputTextarea, SimformButton },
  methods: {
    async submitForm() {
      event.preventDefault();
      if (this.$refs["contactForm"]) {
        const form = this.$refs["contactForm"];

        let data = {};
        const formData = new FormData();

        form.elements.forEach(({ name, type, value, files, ...element }) => {
          if (!["submit", "file"].includes(type)) {
            data[name] = value;
          } else if (type === "file") {
            files.forEach((file) => {
              formData.append(`files.${name}`, file, file.name);
            });
          }
        });

        const token = await this.$recaptcha.execute("login");
        data = { ...data, token };
        new FormData(this.$refs["contactForm"])
          .getAll("services")
          .forEach((item) => {
            data[item] = true;
          });

        formData.append("data", JSON.stringify(data));

        await fetch(`${process.env.STRAPI_HOST}/api/contact-forms`, {
          method: "post",
          body: formData,
        });
      }
    },
  },
};
</script>
