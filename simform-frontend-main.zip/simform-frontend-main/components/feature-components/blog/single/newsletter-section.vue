<template>
  <div class="mt-20">
    <div class="bg-[#ecc2e5] h-6"></div>
    <div class="bg-[#ffe0f9] py-20">
      <div class="max-w-2xl mx-auto text-center">
        <h3 class="font-bold text-4xl">Sign up for the free Newsletter</h3>
        <p class="text-xl text-slate-800 py-3">
          For exclusive strategies not found on the blog
        </p>

        <div class="mt-6 flex px-10">
          <input
            type="text"
            class="ring-0 focus:ring-0 border-none outline-none focus:outline-none rounded-l-md px-6 w-full text-xl pt-4 pb-3 placeholder:pt-4 placeholder:pb-3 text-slate-400 placeholder:text-slate-400 flex items-center"
            placeholder="Email"
          />
          <Button :onClick="submitForm" classData="min-w-[140px]">
            <span
              class="flex justify-center items-center text-center tracking-wide font-medium text-base max-w-fit"
            >
              SIGN UP</span
            >
          </Button>
          <div class="relative hidden lg:block">
              <div class="font-semibold text-primary-500 text-xl w-[200px] absolute -top-11 left-5">
                Sign up today!
              </div>
              <span class="newsletter-arrow"></span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import Button from "../../../primary/button/simform-button.vue";

export default {
  components: { Button },
  methods: {
    submitForm() {
      console.log("submit");
    },
  },
};
</script>
<style scoped>
.note {
  position: absolute;
  font-size: 18px;
  font-family: "Graphik";
  font-weight: 500;
  line-height: 24px;
  color: #ef5366;
  right: 70px;
  top: 48px;
}

.newsletter-arrow {
  position: absolute;
  background-image: url("~/assets/images/css-sprite.png");
  width: 55px;
  height: 55px;
  background-position: -296px -120px;
  left: 15px;
  top: -15px;
  content: "";
}
</style>
