<template>
  <div class="my-10 flex gap-5">
    <div class="img-blk-wrapper w-[270px] flex-none">
      <div class="img-blk">
        <img :src="author.avatar.src" :alt="author.name" class="w-full absolute z-10" />
      </div>
    </div>
    <div class="flex-grow">
      <h4 class="text-3xl font-bold mb-3">{{ author.name }}</h4>
      <div class="text-xl lead" v-html="author.description"></div>
      <div class="flex gap-5 my-5">
        <a v-if="author.twitter" :href="author.twitter">
          <span
            class="text-xl font-bold text-white bg-primary-600 w-11 h-11 flex rounded-full justify-center items-center"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              data-name="Layer 1"
              viewBox="0 0 24 24"
              class="w-6 h-6"
            >
              <path
                fill="currentColor"
                d="M22,5.8a8.49,8.49,0,0,1-2.36.64,4.13,4.13,0,0,0,1.81-2.27,8.21,8.21,0,0,1-2.61,1,4.1,4.1,0,0,0-7,3.74A11.64,11.64,0,0,1,3.39,4.62a4.16,4.16,0,0,0-.55,2.07A4.09,4.09,0,0,0,4.66,10.1,4.05,4.05,0,0,1,2.8,9.59v.05a4.1,4.1,0,0,0,3.3,4A3.93,3.93,0,0,1,5,13.81a4.9,4.9,0,0,1-.77-.07,4.11,4.11,0,0,0,3.83,2.84A8.22,8.22,0,0,1,3,18.34a7.93,7.93,0,0,1-1-.06,11.57,11.57,0,0,0,6.29,1.85A11.59,11.59,0,0,0,20,8.45c0-.17,0-.35,0-.53A8.43,8.43,0,0,0,22,5.8Z"
              />
            </svg>
          </span>
        </a>
        <a v-if="author.linkedIn" :href="author.linkedIn">
          <span
            class="text-xl font-bold text-white bg-primary-600 w-11 h-11 flex rounded-full justify-center items-center"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 124 124"
              class="w-6 h-6"
            >
              <path
                fill="currentColor"
                d="M102.4 70.7v28.5c0 .7-.6 1.3-1.3 1.3H86.4c-.7 0-1.3-.6-1.3-1.3V72.7c0-7-2.5-11.8-8.8-11.8-4.8 0-7.6 3.2-8.9 6.3-.5 1.1-.6 2.7-.6 4.2v27.8c0 .7-.6 1.3-1.3 1.3H50.9c-.7 0-1.3-.6-1.3-1.3 0-7.1.2-41.4 0-49.4 0-.7.6-1.3 1.3-1.3h14.7c.7 0 1.3.6 1.3 1.3v6.1c0 .1-.1.1-.1.2h.1v-.2c2.3-3.5 6.4-8.6 15.6-8.6 11.4 0 19.9 7.5 19.9 23.4zM24 100.6h14.7c.7 0 1.3-.6 1.3-1.3V49.8c0-.7-.6-1.3-1.3-1.3H24c-.7 0-1.3.6-1.3 1.3v49.5c.1.7.6 1.3 1.3 1.3z"
              />
              <circle cx="30.9" cy="32.7" r="9.3" fill="currentColor" />
            </svg>
          </span>
        </a>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    author: {
      type: Object,
      required: true,
    },
  },
};
</script>
<style scoped>
.img-blk {
  position: relative;
  width: 100%;
  height: 100%;
  background: linear-gradient(132deg, #ecc2e5, #edc4e6);
}

.img-blk:before {
  content: "";
  width: 100%;
  height: 100%;
  position: absolute;
  left: -18px;
  top: -18px;
  background: #ffe0f9;
}
.img-blk:after {
  content: "";
  width: 100%;
  height: 100%;
  position: absolute;
  right: -18px;
  bottom: -18px;
  background: #ffe0f9;
}

.img-blk-wrapper {
  width: 270px;
  height: 270px;
  margin-right: 40px;
  padding: 18px;
}
</style>
