<template>
  <div class="flex gap-3 flex-wrap text-base">
    <div class="flex gap-3 items-center group" v-for="(item, index) in breadcrumbs" :key="index">
      <nuxt-link
        v-if="item.to"
        :to="item.to"
        class="flex items-center hover:text-primary-500 transition-colors duration-300 font-semibold"
        >{{ item.text  }}</nuxt-link
      >
      <div v-else>{{ item.text }}</div>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        fill="none"
        viewBox="0 0 30 30"
        stroke-width="1.5"
        stroke="currentColor"
        class="w-5 h-5 group-last:hidden"
      >
        <path
          stroke-linecap="round"
          stroke-linejoin="round"
          d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"
        />
      </svg>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    breadcrumbs: {
      type: Array,
      required: true,
    },
  },
  computed: {
    categoryUrl() {
      return `/category/${this.category.slug}`;
    },
  },
};
</script>
