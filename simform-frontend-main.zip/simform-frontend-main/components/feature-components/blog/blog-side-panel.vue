<template>
  <div>
    <search-box />
    <topics-panel v-if="topics" :topics="topics" />
    <newsletter-panel />
    <popular-articles-panel />
  </div>
</template>
<script>
import Card from "../card/card.vue";
import NewsletterPanel from "./side-panel/newsletter-panel.vue";
import PopularArticlesPanel from "./side-panel/popular-articles-panel.vue";
import SearchBox from "./side-panel/search-box.vue";
import TopicsPanel from "./side-panel/topics-panel.vue";

export default {
  components: { Card, SearchBox, TopicsPanel, NewsletterPanel, PopularArticlesPanel },
  props: {
    topics: {
      type: Array,
      required: true,
    },
  },
};
</script>
