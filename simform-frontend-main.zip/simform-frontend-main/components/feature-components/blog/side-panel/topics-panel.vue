<template>
  <card class="mb-6">
    <template v-slot:content>
        <div class="text-primary-500 font-semibold text-xl mb-5">Topics</div>
        <div v-for="topic in topics" class="mb-4" :key="topic.id">
            <nuxt-link :to="getTopicSlug(topic)" class="text-lg hover:text-primary-500 transition-all duration-300">
                {{ topic.attributes.name }}
            </nuxt-link>
        </div>
    </template>
  </card>
</template>
<script>
import Card from "../../card/card.vue";

export default {
  components: { Card },
  props: {
    topics: {
      type: Array,
      required: true,
    },
  },
  methods: {
    getTopicSlug(topic) {
      const basePath = '/blog/category'
      return topic.attributes.slug ? `${basePath}/${topic.attributes.slug}` : '/blog';
    },
  },
};
</script>
