<template>
  <card class="mb-6">
    <template v-slot:content>
      <div>
        <img
          src="~/assets/images/user.jpeg"
          alt=""
          class="mb-4 rounded-full w-16"
        />
      </div>
      <div>
        <p class="text-xl font-semibold mb-3">
          Monthly Newsletter for Tech Experts
        </p>
        <p class="text-base font-light">
          Join 12,000+ business leaders, designers, and developers who receive
          blogs, e-Books, and case studies on emerging technology.
        </p>
      </div>
      <div>
        <div class="relative">
          <span class="newsletter-arrow"></span>
        </div>
        <div class="pt-10">
          <input
            type="email"
            v-model="text"
            placeholder="Email*"
            class="w-full border-gray-200 rounded-sm flex items-center ring-0 focus:ring-0 focus:border-gray-200 pt-3 bg-gray-50"
          />
          <simform-button class="mt-2" :on-click="joinNewsLetter" expanded>
            <div class="font-semibold tracking-wider">SIGN UP</div>
          </simform-button>
        </div>
      </div>
    </template>
  </card>
</template>
<script>
import Card from "../../card/card.vue";
import SimformButton from "@/components/primary/button/simform-button";

export default {
  components: { Card, SimformButton },
  data() {
    return {
      text: "",
    };
  },
  methods: {
    joinNewsLetter() {
      if (this.validateEmail(this.text)) {
        console.log(this.text)
        this.text = "";
      }
    },

    validateEmail(email) {
      return String(email)
        .toLowerCase()
        .match(
          /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
        );
    },
  },
};
</script>
<style>
.newsletter-arrow {
  position: absolute;
  background-image: url("~/assets/images/css-sprite.png");
  width: 21px;
  height: 49px;
  background-position: -267px -122px;
  left: 125px;
  top: -20px;
}
</style>
