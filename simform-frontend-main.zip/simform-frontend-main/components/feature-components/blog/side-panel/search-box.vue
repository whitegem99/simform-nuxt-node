<template>
  <card class="mb-6">
    <template v-slot:content>
      <div class="flex">
        <input
          type="text"
          placeholder="Search..."
          class="border-gray-200 rounded-l-md flex items-center ring-0 focus:ring-0 focus:border-gray-200 pt-3 bg-gray-50"
        />
        <button
          class="bg-primary-500 w-12 h-12 flex items-center justify-center rounded-r-md"
        >
          <img src="~/assets/images/search-icon.svg" alt="" />
        </button>
      </div>
    </template>
  </card>
</template>
<script>
import Card from "../../card/card.vue";

export default {
  components: { Card },
};
</script>
