<template>
  <div class="bg-primary-100 rounded p-4">
    <div class="text-xl text-primary-500 mb-5 mt-2 font-semibold">Popular Articles</div>
    <div v-for="article in articles" class="mb-4 flex gap-2 items-start">
      <div class="w-3">
        <div class="bg-primary-500 w-[7px] h-[7px] mt-1"></div>
      </div>
      <nuxt-link
        :to="article.slug"
        class="text-base hover:text-primary-500 transition-all duration-300 flex-grow"
      >
        {{ article.title }}
      </nuxt-link>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      articles: [
        {
          title:
            "A Guide on What Are Microservices: Pros, Cons, Use Cases, and More",
          slug: "/how-to-create-a-new-blog-post",
        },
        {
          title:
            "How Netflix Became A Master of DevOps? An Exclusive Case Study",
          slug: "/how-to-create-a-new-blog-post",
        },
        {
          title: "Top Benefits of DevOps: What do you Need to Know as a CIO?",
          slug: "/how-to-create-a-new-blog-post",
        },
        {
          title:
            "Capital One DevOps Case Study: A Bank with the Heart of Tech Company",
          slug: "/how-to-create-a-new-blog-post",
        },
        {
          title: "Etsy DevOps Case Study: The Secret to 50 Plus Deploys a Day",
          slug: "/how-to-create-a-new-blog-post",
        },
      ],
    };
  },
};
</script>
<style scoped>
.item:before {
  content: "";
  width: 7px;
  height: 7px;
  background: #ef5366;
  top: 9px;
  position: absolute;
  left: 0;
}
</style>
