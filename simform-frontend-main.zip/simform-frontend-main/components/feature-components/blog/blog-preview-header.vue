<template>
  <div>
    <div class="mb-4">
      <nuxt-link
      :to="articleUrl"
      class="hover:text-primary-600 transition-all duration-300 mb-4 cursor-pointer"
    >
      <h2 class="text-3xl font-semibold">
        {{ displayTitle }}
      </h2>
    </nuxt-link>
    </div>
    <div>
      <div class="flex justify-between">
        <div class="flex gap-3">
          <img
            class="w-12 h-12 rounded-full"
            :src="author.image.src"
            :alt="author.image.alt"
          />
          <div>
            <nuxt-link to="">
              <div class="text-primary-600 cursor-pointer font-semibold text-[18px]">
                {{ author.fullName }}
              </div>
            </nuxt-link>
            <div class="flex gap-2 items-center">
              <span
                class="bg-slate-100 text-slate-400 text-[14px] tracking-wide pt-[6px] pb-[2px] flex items-center rounded-full px-2 font-semibold"
                >{{ category }}</span
              >
              <span class="font-semibold text-[16px] mt-[4px]">{{ publishedDate }}</span>
            </div>
          </div>
        </div>
        <div class="flex items-end">
          <div class="flex gap-1">
            <span class="date-icon"></span>
            <span class="font-light"> Last Updated {{ lastUpdatedDate }} </span>
          </div>
        </div>
      </div>
    </div>
    <div class="my-6">
      <img :src="featuredImage.src" :alt="featuredImage.alt" />
    </div>
  </div>
</template>
<script>
import { getImage } from '../../../helpers/imageHelper';

export default {
  name: "BlogPreviewHeader",
  components: {},
  props: {
    article: {
      type: Object,
      required: true,
    },
  },
  computed: {
    author() {
      return {
        fullName: this.processedArticle.creator.data?.attributes.fullName || this.processedArticle.creator.fullName,
        image: getImage(this.processedArticle.creator.data?.attributes.avatar || this.processedArticle.creator.avatar),
      };
    },
    processedArticle() {
      return this.article?.attributes || this.article 
    },
    displayTitle() {
      return this.processedArticle.displayTitle;
    },
    category() {
      return this.processedArticle.category.data?.attributes.name || this.processedArticle.category.name;
    },
    publishedDate() {
      return new Date(this.processedArticle.publishedAt).toLocaleDateString('en-us', { year:"numeric", month:"short", day:"numeric"});
    },
    lastUpdatedDate() {
      return new Date(this.processedArticle.updatedAt).toLocaleDateString('en-us', { year:"numeric", month:"short", day:"numeric"});
    },
    articleUrl() {
      return `/blog/${this.processedArticle.slug}`;
    },
    featuredImage() {
      return getImage(this.processedArticle.featuredImage)
    },
  }
};
</script>
<style>
.date-icon {
  display: flex;
  height: 18px;
  flex: 0 0 18px;
  width: 18px;
  margin-right: 10px;
  background-image: url("~/assets/images/css-sprite.png");
  background-position: 121px 44px;
}
</style>
