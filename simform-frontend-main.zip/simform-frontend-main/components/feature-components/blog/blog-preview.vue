<template>
  <div class="w-full shadow-md mb-10 rounded p-7 bg-white">
    <blog-preview-header :article="article" />
    <div>
      <p class="text-[21px] tracking-wide leading-relaxed">
        {{ article.attributes?.quickSummary || article.quickSummary }}
      </p>
      <div class="mt-4">
        <nuxt-link :to="articleUrl" class="text-xl text-primary-600 underline cursor-pointer">Continue Reading</nuxt-link>
      </div>
    </div>
  </div>
</template>
<script>
import BlogPreviewHeader from "./blog-preview-header.vue";
export default {
  components: { BlogPreviewHeader },
  props: {
    article: {
      type: Object,
      required: true,
    },
  },
  computed: {
    articleUrl() {
      return `/blog/${this.article.attributes?.slug || this.article.slug}`;
    },
  },
};
</script>
