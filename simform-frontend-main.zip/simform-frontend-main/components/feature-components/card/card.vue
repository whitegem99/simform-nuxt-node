<template>
  <div class="bg-white p-4 py-5 shadow-md">
    <slot name="content"></slot>
  </div>
</template>
<script>
export default {};
</script>
<style lang=""></style>
