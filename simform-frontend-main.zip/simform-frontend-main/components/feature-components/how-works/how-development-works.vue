<template>
  <div class="mt-[40px] mx-auto w-[944px]">
    <div class="flex justify-between">
      <div class="max-w-[284px]" v-for="(item, index) in top">
        <color-box-item
          :key="item.title"
          :item="item"
          :index="index"
          isTop
          with-y-arrow
        />
      </div>
    </div>
    <div class="my-12">
      <animated-block />
    </div>
    <div class="flex justify-between flex-row-reverse">
      <div class="max-w-[284px]" v-for="(item, index) in bottom">
        <color-box-item
          :key="item.title"
          :item="item"
          :index="index + 3"
          with-y-arrow
        />
      </div>
    </div>
  </div>
</template>

<script>
import ColorBoxItem from "../color-box-item/color-box-item.vue";
import AnimatedBlock from "./animated-block.vue";

export default {
  components: { AnimatedBlock, ColorBoxItem },
  computed: {
    top() {
      return this.items.slice(0, 3);
    },
    bottom() {
      return this.items.slice(3, 6);
    },
  },
  props: {
    items: {
      type: Array,
      required: true,
    },
  },
};
</script>
