<template>
  <div class="grid grid-cols-3 mb-14">
    <div
      class="flex relative place-content-end user-image -space-x-4 overflow-hidden drop-shadow-sm"
    >
      <img alt="" :src="image" v-for="image in firstImageBlock" class="w-[124px] h-[124px]" />
    </div>
    <div class="px-20">
      <title-underline :data="{ text: title, align: 'center' }" :spaced="false" />
    </div>
    <div
      class="flex relative place-content-start user-image -space-x-4 overflow-hidden"
    >
      <img alt="" :src="image" v-for="image in secondImageBlock" class="w-[124px] h-[124px]" />
    </div>
  </div>
</template>

<script>
import TitleUnderline from '../../primary/title/title-underline.vue';

export default {
  components: { TitleUnderline, TitleUnderline },
  props: {
    title: {
      type: String,
      required: true,
    },
  },
  data() {
    return {
      firstImageBlock: [
        require("~/assets/images/services/custom_agile/service-user-1@2x.png"),
        require("~/assets/images/services/custom_agile/service-user-2@2x.png"),
        require("~/assets/images/services/custom_agile/service-user-3@2x.png"),
      ],
      secondImageBlock: [
        require("~/assets/images/services/custom_agile/service-user-4@2x.png"),
        require("~/assets/images/services/custom_agile/service-user-5@2x.png"),
        require("~/assets/images/services/custom_agile/service-user-6@2x.png"),
      ],
    };
  },
};
</script>

<style scoped></style>
