<template>
  <div class="w-full single-block group mb-[129px]">
    <div class="three-layer">
      <div class="back-layer"></div>
      <div class="front-layer"></div>
      <div class="middle-layer">
        <div class="image-wrapper">
          <img :src="image.src" :alt="image.alt" />
        </div>
      </div>
    </div>
    <div
      class="flex flex-col content-block justify-start group-odd:order-last group-even:order-first"
    >
      <div v-if="title" class="text-3xl font-bold mb-4" v-html="title" ></div>
      <div v-if="description" v-html="description" class="text-[22px] font-light"></div>
    </div>
    <div class="pattern-block">
      <img src="~/assets/images/services/benefits_of_working/lr-connector.svg" class="group-even:hidden group-last:hidden" alt=""/>
      <img src="~/assets/images/services/benefits_of_working/rl-connector.svg" class="group-odd:hidden group-last:hidden" alt=""/>
    </div>
  </div>
</template>
<script>
import { getImage } from '../../../helpers/imageHelper';

export default {
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    layout() {
      return this.reverseLayout ? "order-first" : "";
    },
    bottom() {
      return this.enableConnector ? "mb-[129px]" : "mb-10";
    },
    title() {
      return this.data.title;
    },
    description() {
      return this.data.description;
    },
    image() {
      return getImage(this.data.image);
    },
  },
};
</script>
<style scoped>
.content-block {
  max-width: 468px;
  width: 100%;
  margin: 0px 50px;
  max-height: 472px;
  overflow: hidden;
}
.single-block {
  width: 100%;
  display: flex;
  -webkit-box-align: center;
  align-items: center;
  position: relative;
}
.pattern-block {
  position: absolute;
  bottom: -145px;
  left: 0px;
  right: 0px;
  margin: 0px auto;
  z-index: 2;
  display: block;
}
.pattern-block > img {
  display: block;
  margin: 0 auto;
}
.front-layer {
  background-image: linear-gradient(
    to top,
    rgb(238, 242, 255),
    rgb(255, 255, 255)
  );
  position: absolute;
  width: calc(100% - 60px);
  height: calc(100% - 60px);
  bottom: 0px;
  left: 0px;
  opacity: 0.7;
  z-index: 2;
}

.back-layer {
  background-image: linear-gradient(
    to top,
    rgb(255, 255, 255),
    rgb(238, 242, 255)
  );
  position: absolute;
  width: calc(100% - 60px);
  height: calc(100% - 60px);
  top: 0;
  right: 0;
  opacity: 0.5;
  z-index: 1;
}
.middle-layer {
  backdrop-filter: blur(10px);
  box-shadow: rgb(161 175 221 / 9%) 0px 5px 10px 0px;
  border: 1px solid rgb(232, 233, 243);
  background-color: rgba(255, 255, 255, 0.7);
  width: calc(100% - 60px);
  height: calc(100% - 60px);
  position: relative;
  z-index: 3;
  display: flex;
  -webkit-box-align: center;
  align-items: center;
}

.middle-layer > img {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: center center;
  opacity: 1;
  transition: opacity 500ms ease 0s;
}

.image-wrapper {
  max-width: 320px;
  margin: 0 auto;
}

.three-layer {
  max-width: 468px;
  height: 472px;
  width: 100%;
  margin: 0 50px;
  display: flex;
  -webkit-box-align: center;
  align-items: center;
  -webkit-box-pack: center;
  justify-content: center;
  position: relative;
}
</style>
