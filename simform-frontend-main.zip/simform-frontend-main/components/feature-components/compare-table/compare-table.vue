<template>
  <div class="border-2 bg-slate-200 border-slate-700 px-6 mb-10 max-w-6xl mx-auto">
    <div class="grid grid-cols-3 group text-lg" v-for="item in tableItems">
      <div class="border-r border-slate-700 py-5 font-semibold" v-html="item[0]" />
      <div class="border-r border-slate-700 group-first:font-semibold py-4 pl-6" v-html="item[1]" />
      <div class="border-slate-700 group-first:font-semibold py-4 pl-4" v-html="item[2]" />
    </div>
  </div>
</template>
<script>
export default {
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    tableItems() {
      const { compareTableRowItems, firstColumnTitle, secondColumnTitle } = this.data;
      const dataItems = compareTableRowItems.map((item) => {
        return [item.key, item.firstColumnValue, item.secondColumnValue];
      });

      return [["", firstColumnTitle, secondColumnTitle], ...dataItems];
    },
  },
};
</script>
