<template>
  <div class="h-[330px] w-[300px] sm:w-[355px] mx-auto group relative">
    <div class="cst-inset group-hover:h-[355px] mx-auto"></div>
    <div
      class="bg-white shadow-md group-hover:translate-y-3 transition-transform duration-500"
    >
      <div class="h-[200px] bg-primary-700 relative">
        <img
          src="~/assets/images/quote.svg"
          alt="Quote"
          class="testimonial-quote-img-mobile sm:testimonial-quote-img"
        />
        <client-only>
          <vue-plyr :options="playerOptions">
            <div class="plyr__video-embed">
              <iframe :src="videoLink"></iframe>
            </div>
          </vue-plyr>
        </client-only>
      </div>
      <div class="px-8 py-5 h-[100px] text-ellipsis overflow-hidden">
        <p class="desc">
          {{ text }}
        </p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    text: {
      type: String,
      required: true,
    },
    videoLink: {
      type: String,
      required: true,
    },
  },
  data() {
    return {
      playerOptions: {
        controls: ["play-large"],
      },
    };
  },
};
</script>

<style scoped>
.testimonial-quote-img {
  position: absolute;
  left: -29px;
  bottom: -15px;
  z-index: 9;
  transition: all 800ms cubic-bezier(0.2, 0.8, 0.2, 1) 0s;
}

.testimonial-quote-img-mobile {
  position: absolute;
  left: 10px;
  bottom: -10px;
  z-index: 9;
  transition: all 800ms cubic-bezier(0.2, 0.8, 0.2, 1) 0s;
}

.desc {
  -webkit-backface-visibility: hidden;
  transform: translateZ(0) scale(1.05, 1.05);
}

.cst-inset {
  animation: 70s linear 0s infinite normal none running linear_run;
  position: absolute;
  inset: 45% 0 auto;
  z-index: -1;
  width: 335px;
  height: 0;

  background-color: rgb(235, 224, 255);
  background-position: 0 0;
  background-image: url("~/assets/images/back-pattern.png");
  background-size: 24px;
  opacity: 1;
  transform: translate(0px, -50%);
  transition: all 800ms cubic-bezier(0.2, 0.8, 0.2, 1) 0s;
}

.cst-inset:hover {
  transition: all 400ms cubic-bezier(0.2, 0.8, 0.2, 1) 0s;
}

.cst-hover {
  height: 355px;
}

@keyframes linear_run {
  from {
    background-position: 0 0;
  }

  to {
    background-position: 400px 0;
  }
}
</style>
