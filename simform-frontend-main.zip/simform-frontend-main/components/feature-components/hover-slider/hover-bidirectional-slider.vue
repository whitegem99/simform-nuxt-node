<template>
  <div class="py-5">
    <div
      class="min-h-[300px] w-full mx-auto p-4 mt-6 flex overflow-hidden service-item-container transition-all duration-500 pl-[40%] py-5"
      @mouseenter="hover = true"
      @mouseleave="hover = false"
      @mousemove="sliderEvent"
      ref="sliderContainer"
    >
      <slot></slot>
    </div>
    <div class="max-w-[150px] mx-auto mt-14">
      <div class="border-b border-gray-300 relative">
        <div
          class="scroll-block w-8 h-1.5 bg-black absolute bottom-[-1px]"
          ref="scrollBlock"
        ></div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  mounted() {
    this.timer = setInterval(() => {
      let width = this.$refs.sliderContainer?.clientWidth || 0;
      if (this.hover) {
        if (this.eClientX < width / 2) {
          this.$refs.sliderContainer.scrollLeft -= 1;
        } else {
          this.$refs.sliderContainer.scrollLeft += 1;
        }

        const scrollBlockItemWidth = 32;
        const scrollBlockWidth = 150 - scrollBlockItemWidth;

        let scrollAmount =
          (this.$refs.sliderContainer.scrollLeft /
            (this.$refs.sliderContainer.scrollWidth -
              this.$refs.sliderContainer.offsetWidth)) *
          scrollBlockWidth;

        this.$refs.scrollBlock.style.left = `${scrollAmount}px`;
      }
    }, 2);
  },
  unmounted() {
    clearTimeout(this.timer);
  },
  methods: {
    sliderEvent(e) {
      this.eClientX = e.clientX;
    },
  },
  data() {
    return {
      hover: false,
      eClientX: null,
      timer: null,
    };
  },
};
</script>
