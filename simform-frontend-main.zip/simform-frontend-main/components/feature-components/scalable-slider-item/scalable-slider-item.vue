<template>
  <div
    class="p-8 py-10 self-card transition-all duration-500 border border-solid border-gray-200 hover:shadow-lg group min-w-[350px] w-[350px] h-[350px] min-h-[350px] bg-white mr-3"
    :style="cardBackground"
  >
    <div>
      <img
        :src="icon.src"
        class="w-24 h-24 self-start place-self-start group-hover:-translate-y-2 transition-all duration-500 group-hover:drop-shadow-lg"
        :alt="icon.alt"
      />
    </div>
    <div>
      <div class="mt-5 group-hover:-translate-y-2 transition-all duration-500">
        <h5 class="text-[18px] font-semibold transition-all duration-500">
          {{ title }}
        </h5>
        <div
          class="mt-2 transition-all duration-500 text-[17px] font-light"
          v-html="description"
        ></div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  components: {},
  props: {
    icon: {
      type: Object,
      required: true,
    },
    title: {
      type: String,
    },
    description: {
      type: String,
    },
    color: {
      type: Object,
      required: true,
    },
  },
  computed: {
    cardBackground() {
      return `--bg-color: ${this.color.bg}`;
    },
    onlySlots() {
      return !this.title && !this.description;
    },
  },
};
</script>
<style>
.self-card:hover {
  background-color: var(--bg-color);
}
</style>
