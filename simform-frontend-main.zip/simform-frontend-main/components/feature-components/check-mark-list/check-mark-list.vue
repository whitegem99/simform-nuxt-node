<template>
  <div class="max-w-7xl mx-auto checkmark">
    <div
      v-for="(item, index) in items"
      class="flex mb-2 gap-3"
      :key="index"
    >
      <check-mark-item>
        <div v-html="item.text" class="leading-relaxed tracking-wide -mt-[2px]" :class="large ? 'text-[26px] font-semibold -mt-1' : 'text-xl'"></div>
      </check-mark-item>
    </div>
  </div>
</template>

<script>
import SimformSection from "@/components/sections/basic/simform-section";
import TitleUnderline from "@/components/primary/title/title-underline";
import CheckMark from "@/components/primary/checkmark/check-mark";
import CheckMarkItem from "./check-mark-item.vue";

export default {
  name: "check-mark-list",
  components: { CheckMark, TitleUnderline, SimformSection, CheckMarkItem },
  props: {
    data: {
      type: Object,
      required: true,
    },
    large: {
      type: Boolean,
      default: false,
    },
  },
  computed: {
    items() {
      return this.data.checkMarkItems;
    },
  },
};
</script>
