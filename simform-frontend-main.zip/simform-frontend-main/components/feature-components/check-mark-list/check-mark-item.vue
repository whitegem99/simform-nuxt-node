<template>
  <div class="flex mb-5 gap-3 text-2xl font-merriweather italic" :class="[center ? 'items-center': 'items-start']">
    <span class="flex" :class="[center ? 'items-center': 'pt-[2px] items-start']">
      <check-mark />
    </span>
    <div class="flex-grow">
      <slot></slot>
    </div>
  </div>
</template>
<script>
import CheckMark from "@/components/primary/checkmark/check-mark";

export default {
  name: "check-mark-item",
  components: { CheckMark },
  props: {
    center: {
      type: Boolean,
      default: false,
    },
  },
};
</script>
