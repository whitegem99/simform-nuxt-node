<template>
  <div class="max-w-full mx-auto">
    <hover-bidirectional-slider>
      <service-item
        :icon="item.icon"
        :color="item.color"
        :title="item.title"
        :description="item.description"
        v-for="(item, index) in items"
        :key="index"
      />
    </hover-bidirectional-slider>
  </div>
</template>

<script>
import ServiceItem from "../../primary/service-item/service-item.vue";
import HoverBidirectionalSlider from "../hover-slider/hover-bidirectional-slider.vue";

export default {
  name: "ServiceSlider",
  components: { ServiceItem, HoverBidirectionalSlider },
  props: {
    items: {
      type: Array,
      required: true,
    },
  },
};
</script>
