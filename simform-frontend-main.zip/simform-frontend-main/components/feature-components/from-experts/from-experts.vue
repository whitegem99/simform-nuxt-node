<template>
  <div class="grid grid-cols-4 gap-8">
    <div :class="[item.isLarge ? 'col-span-2': 'col-span-1']" v-for="item in items">
      <figure class="drop-shadow-md">
        <a :href="item.link" target="_blank">
          <img :src="item.image.src" :alt="item.image.alt" />
        </a>
      </figure>
    </div>
    <!-- <div class="col-span-1">
      <figure class="drop-shadow-md">
        <a href="#" target="_blank">
          <img src="~/assets/images/from-experts/Foodtruck-spaces.png" />
        </a>
      </figure>
    </div>
    <div class="col-span-2">
      <figure class="drop-shadow-md">
        <a href="#" target="_blank">
          <img src="~/assets/images/from-experts/Building-high-performing-web-apps-eBook.png" />
        </a>
      </figure>
    </div>
    <div class="col-span-2">
      <figure class="drop-shadow-md">
        <a href="#" target="_blank">
          <img src="~/assets/images/from-experts/DevOps-consulting-services-1.png" />
        </a>
      </figure>
    </div>
    <div class="col-span-1">
      <figure class="drop-shadow-md">
        <a href="#" target="_blank">
          <img src="~/assets/images/from-experts/eCommerce-strategies.png" />
        </a>
      </figure>
    </div>
    <div class="col-span-1">
      <figure class="drop-shadow-md">
        <a href="#" target="_blank">
          <img src="~/assets/images/from-experts/QA-Managers-guide.png" />
        </a>
      </figure>
    </div> -->
  </div>
</template>
<script>
export default {
  props: {
    items: {
      type: Array,
      required: true,
    },
  },
};
</script>
