<template>
  <div class="grid grid-cols-5 p-3 mt-8">
    <div class="col-span-2 pr-2">
      <h4 class="text-2xl font-semibold mb-6">
        {{ title }}
      </h4>
      <p class="text-xl mt-3">
        {{ description }}
      </p>
    </div>
    <img :src="image.src" class="p-5 w-full h-full"  :alt="image.alt" v-for="image in images"/>
  </div>
</template>
<script>
export default {
  props: {
    title: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
    images: {
      type: Array,
      required: true,
    },
  },
};
</script>
