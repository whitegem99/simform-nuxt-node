<template>
  <div
    class="border border-gray-200 bg-gray-50 border-b-0 last:border-b p-9"
  >
    <div class="flex gap-8 px-5">
      <div class="w-[50px]">
        <img :src="icon.src" :alt="icon.alt" />
      </div>
      <div class="flex-1">
        <h3 class="font-semibold text-[25px] tracking-normal" :class="color">
          {{ item.title }}
        </h3>
        <div class="text-xl font-light py-2 color-box-item" v-html="item.text"></div>
      </div>
    </div>
  </div>
</template>
<script>
import { getImage } from "../../../helpers/imageHelper";

export default {
  props: {
    item: {
      type: Object,
      required: true,
    },
  },
  computed: {
    icon() {
      return this.getIcon(this.item.icon);
    },
    color() {
      return this.getColor(this.item.color);
    },
  },
  methods: {
    getIcon(icon) {
      return getImage(icon);
    },
    getColor(color) {
      switch (color) {
        case "green":
          return "text-lime-500";
        case "blue":
          return "text-blue-500";
        case "red":
          return "text-rose-400";
        case "purple":
          return "text-purple-500";
        case "sky":
          return "text-sky-500";
        case "orange":
          return "orange";
        default:
          return "text-blue-500";
      }
    },
  },
};
</script>
<style scoped>
.orange {
  color: rgb(246, 162, 95);
}

li {
    color: aqua;
}
</style>
