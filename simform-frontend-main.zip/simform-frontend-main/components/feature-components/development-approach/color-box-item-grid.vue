<template>
  <div class="mt-20 block h-auto" :class="heightClass">
    <div
      :class="gridClasses"
      class="grid border-t-[#e8e9f3] border-b-[#e8e9f3] grid-cols-1 px-5 sm:px-0"
    >
      <div
        class="border border-gray-100 item-background px-4 py-8"
        v-for="item in items"
        :key="item.id"
      >
        <div class="flex gap-3 px-5">
          <div class="flex-none w-[60px]">
            <img :src="getIcon(item.icon).src" alt="getIcon(item.icon).alt" />
          </div>
          <div class="flex-grow">
            <h3
              class="font-semibold text-[22px] tracking-wide"
              :class="getColor(item.color)"
            >
              {{ item.title }}
            </h3>
            <div class="text-xl font-light py-2" v-html="item.text"></div>
          </div>
        </div>
      </div>
    </div>
    <img
      src="~/assets/images/adopting-process-men.png"
      class="relative top-[-252px] left-[-160px] hidden sm:block"
      alt=""
      v-if="withImage"
    />
  </div>
</template>
<script>
import { getImage } from "../../../helpers/imageHelper";

export default {
  components: {},
  props: {
    items: {
      type: Array,
      required: true,
    },
    withImage: {
      type: Boolean,
      default: true,
    },
    singleColumn: {
      type: Boolean,
      default: false,
    },
    threeColumns: {
      type: Boolean,
      default: false,
    },
    allowDynamicHeight: {
      type: Boolean,
      default: false,
    },
  },
  computed: {
    gridClasses() {
      if (this.threeColumns) return "sm:grid-cols-3";
      return this.singleColumn
        ? "sm:grid-cols-1"
        : "sm:grid-cols-2 sm:grid-rows-3";
    },
    heightClass() {
      return this.allowDynamicHeight ? "" : "sm:h-[830px]";
    },
  },
  methods: {
    getIcon(icon) {
      return getImage(icon);
    },
    getColor(color) {
      switch (color) {
        case "green":
          return "text-lime-500";
        case "blue":
          return "text-blue-500";
        case "red":
          return "text-rose-400";
        case "purple":
          return "text-purple-500";
        case "sky":
          return "text-sky-500";
        case "orange":
          return "text-orange-500";
        default:
          return "text-blue-500";
      }
    },
  },
};
</script>
<style scoped>
.item-background {
  background: rgba(255, 255, 255, 0.5);
}
</style>
