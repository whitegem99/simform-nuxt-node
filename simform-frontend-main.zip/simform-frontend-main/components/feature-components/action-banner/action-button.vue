<template>
  <div>
    <div
      v-if="withButtonTweak"
      :class="[
        'justify-center -translate-y-5 transition-transform ease-in duration-300 hidden sm:flex',
        upClass,
      ]"
    >
      <img alt="" src="~/assets/images/top-sign.svg" class="h-[35px]" />
    </div>
    <div @mouseenter="updateClass(true)" @mouseleave="updateClass(false)">
      <simform-button
        :on-click="action"
        size="large"
        class="justify-self-end flex align-middle"
        :url="url"
        expanded
      >
        <span
          class="flex justify-center items-center uppercase tracking-wide font-semibold mt-[4px] px-4"
          >{{ actionText }}</span
        >
      </simform-button>
    </div>
    <div
      v-if="withButtonTweak"
      :class="[
        'hidden sm:flex justify-center translate-y-5 transition-transform ease-in duration-300',
        downClass,
      ]"
    >
      <img alt="" src="~/assets/images/bottom-sign.svg" class="h-[35px]" />
    </div>
  </div>
</template>

<script>
import SimformButton from "@/components/primary/button/simform-button";

export default {
  components: { SimformButton },
  props: {
    action: {
      type: Function,
    },
    actionText: {
      type: String,
      required: true,
    },
    url: {
      type: String,
    },
    withButtonTweak: {
      type: Boolean,
      default: true,
    },
  },
  data() {
    return {
      upClass: "",
      downClass: "",
    };
  },
  methods: {
    updateClass(isHover) {
      this.upClass = isHover ? "-translate-y-7" : "";
      this.downClass = isHover ? "translate-y-7" : "";
    },
  },
};
</script>
