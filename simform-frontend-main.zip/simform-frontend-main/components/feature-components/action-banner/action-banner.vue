<template>
  <div
    class="bg-gradient-to-r from-[#4e66d3] to-[#35439e] px-4 sm:px-20 py-10 sm:py-14 rounded-lg group"
    :class="withTweak ? 'py-14' : 'py-10'"
  >
    <div class="flex gap-4 flex-col sm:flex-row">
      <div class="flex flex-1 items-center">
        <h4 class="text-white text-4xl font-semibold leading-relaxed">
          {{ title }}
        </h4>
      </div>
      <div class="flex justify-center flex-1 items-center gap-2">
        <div>
          <img
            alt=""
            src="~/assets/images/rotated-right-arrow.svg"
            class="group-hover:animate-swing transition-transform ease-in-out duration-500 w-[120px] sm:w-[200px] h-[33px] sm:h-[55px] hidden sm:block"
          />
        </div>
        <div>
          <action-button
            :actionText="actionText"
            :action="action"
            :url="url"
            :with-button-tweak="withTweak"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import ActionButton from "./action-button.vue";
export default {
  components: { ActionButton },
  props: {
    title: {
      type: String,
      required: true,
    },
    action: {
      type: Function,
    },
    url: {
      type: String,
    },
    actionText: {
      type: String,
      required: true,
    },
    withTweak: {
      type: Boolean,
      default: false,
    },
  },
};
</script>
