<template>
  <div>
    <div
      class="text-2xl mt-16 text-center px-10 sm:px-32 font-light"
      v-html="data.paragraph"
    ></div>
    <div class="mt-8 flex justify-center">
      <simform-button reverse :url="data.button.link">
        <span class="font-medium">{{ data.button.text }}</span>
      </simform-button>
    </div>
    <div class="mt-12">
      <img :alt="image.alt" :src="image.src" />
    </div>
  </div>
</template>

<script>
import HighlightText from "../../primary/highlight-text/highlight-text.vue";
import SimformButton from "@/components/primary/button/simform-button";
import { getImage } from "../../../helpers/imageHelper";

export default {
  components: { SimformButton, HighlightText },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    image() {
      return getImage(this.data.image);
    },
  },
};
</script>
