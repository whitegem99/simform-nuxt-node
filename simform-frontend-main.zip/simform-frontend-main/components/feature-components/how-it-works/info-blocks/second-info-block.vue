<template>
  <div class="relative mb-[200px]">
    <div class="grid grid-cols-2 my-24 gap-10">
      <div class="flex items-center" :class="reversedComponent">
        <img
          class="h-[350px]"
          src="https://web.archive.org/web/20220125122047oe_/https://www.simform.com/static/594f7a2/10da0/great-engineering-illustration%402x.webp"
          alt=""/>
      </div>
      <div>
        <title-underline
          text="Hire the <u>best developers</u> for your project"
          fontSize="4xl"
          singleLine
          textAlign="left"
        />
        <p class="text-xl py-10">
          Whether you want to add a member to your existing tech team or build a
          standalone project from scratch, we can help you find the
          <highlight-text text="best developers"/>
          for the job and make sure
          the project is successfully delivered on time.
        </p>
        <accordion-item
          title="What does your tech consultation include? Why is it valuable?"
          @toggle-item="toggleItem"
          :on-my-event="myEventSource"
        >
          <p class="font-light max-h-[140px] overflow-x-hidden overflow-scroll">
            The detailed technical consultation (which itself is worth thousands
            of dollars in value) includes things like challenges of the project,
            what tech-stack to use to solve those challenges. A detailed hiring
            plan is also part of this consultation and includes details on what
            skill set and experience your team need to have.
            <br/><br/>
            Project’s execution roadmap brings all the pieces together to show
            how your project will come to life. Based on your project goals we
            help you define processes and delivery roadmap that suits your
            needs.
            <br/><br/>
            Tech architecture solution includes things like how features will be
            implemented with what technology and framework. It will also include
            things like algorithms and cloud integrations will be required to
            build your IP and build the tech engine.
            <br/><br/>
            This tech consultation and talent skillset specification are
            provided for free so even if you don't work with us you can take it
            forward and use it in the future.
          </p>
        </accordion-item>
        <accordion-item
          title="How is Simform different from other online platforms and development agencies?"
          @toggle-item="toggleItem"
          :on-my-event="myEventSource"
        >
          <p class="font-light max-h-[140px] overflow-x-hidden overflow-scroll">
            Simform’s team extension service allows you to hire pre-vetted,
            world-class developers as part of your team.
            <br/><br/>
            We handle all aspects of finding, vetting, and choosing the right
            candidates that you don't have the time, focus, desire, or sometimes
            expertise to do.
            <br/><br/>
            Most of our competitors provide TRANSACTIONAL hiring services. You
            post a gig, they match you up with a developer and you take it from
            there. We aren't a transactional service.
            <br/><br/>
            Best of all, you don’t need to spend hours sifting through online
            profiles, sorting candidates by hourly rates, and then picking the
            person you hope can do the job quickly, reliably, and for the right
            price.
            <br/><br/>
            We aren't just adding development capacity to your team. Our value
            is equally distributed across the entire project execution
            lifecycle. We take ownership and guarantee the delivery and quality
            of your project.
            <br/><br/>
            We use our proven processes, experience, and engagement models to
            make sure remote engagement delivers successful results.
            <br/><br/>
            This way you get the best of both worlds. You get transparency,
            access, and skill set you get from working with full-time
            developers. You also get the benefit of an experienced technology
            firm who is involved in successfully delivering your project.
          </p>
        </accordion-item>
        <accordion-item
          title="What kind of commitment do I need to make up front?"
          @toggle-item="toggleItem"
          :on-my-event="myEventSource"
        >
          <p class="font-light max-h-[140px] transition-all">
            None! We operate under the policy that it is our responsibility to
            find you the right person for the job. If you don’t find the right
            one, you won’t spend a dime.
          </p>
        </accordion-item>
      </div>
    </div>
    <div v-if="enableConnector" class="pattern-block">
      <img
        src="~/assets/images/pages/how-it-works/left-to-right.svg"
        v-if="!reversed"
        alt=""/>
      <img src="~/assets/images/pages/how-it-works/right-to-left.svg" v-else alt=""/>
    </div>
  </div>
</template>
<script>
import TitleUnderline from "../../../primary/title/title-underline.vue";
import HighlightText from "../../../primary/highlight-text/highlight-text.vue";
import Accordian from "../../../primary/accordian/accordian.vue";
import AccordionItem from "../../../primary/accordian/accordion-item.vue";
import {newEventSource} from "vue-parent-emit";

export default {
  components: {TitleUnderline, HighlightText, Accordian, AccordionItem},
  methods: {
    toggleItem(id) {
      this.myEventSource.emit(id);
    },
  },
  data() {
    return {
      myEventSource: newEventSource(),
    };
  },
  props: {
    reversed: {
      type: Boolean,
      default: false,
    },
    enableConnector: {
      type: Boolean,
      default: true,
    },
  },
  computed: {
    reversedComponent: function () {
      return this.reversed ? "order-last justify-start" : "justify-end";
    },
  },
};
</script>
<style scoped>
.pattern-block {
  position: absolute;
  bottom: -300px;
  left: 0;
  right: 0;
  margin: 0 auto;
  z-index: 2;
  display: block;
}

.pattern-block > img {
  display: block;
  margin: 0 auto;
}
</style>
