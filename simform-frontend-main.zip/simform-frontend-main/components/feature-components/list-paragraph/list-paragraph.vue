<template>
  <div class="grid grid-cols-2 gap-5">
    <div v-html="paragraph.text" class="text-xl font-light leading-relaxed"></div>
    <div>
      <ul class="list-none">
        <li v-for="item in list" :key="item.id">
          <check-mark-item>
            <div
              v-html="item.text"
              class="font-merriweather text-xl font-light italic leading-relaxed"
            ></div>
          </check-mark-item>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
import CheckMarkItem from "../check-mark-list/check-mark-item.vue";

export default {
  props: {
    list: {
      type: Array,
      required: true,
    },
    paragraph: {
      type: Object,
      required: true,
    },
  },
  components: { CheckMarkItem },
};
</script>
