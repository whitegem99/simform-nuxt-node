<template>
  <div class="px-5">
    <div
      class="font-merriweather text-2xl lg:text-3xl font-bold italic tracking-wider antialiased lg:leading-9 flex flex-col gap-2"
    >
      <span>“{{ primaryText }}</span
      ><span class="font-sans not-italic font-medium"
        >{{ secondaryText }}<span class="font-merriweather">”</span></span
      >
    </div>
  </div>
</template>
<script>
export default {
  props: {
    primaryText: String,
    secondaryText: String,
  },
};
</script>
