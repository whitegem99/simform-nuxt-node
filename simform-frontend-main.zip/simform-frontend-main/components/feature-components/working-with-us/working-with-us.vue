<template>
  <div class="max-w-4xl mx-auto">
    <div class="text-center text-2xl pt-10 font-medium">
      <div class="pt-12">
        <div class="item">
          <VueSlickCarousel
            v-bind="slickOptions"
            ref="carousel"
            @beforeChange="beforeChange"
          >
            <testimonial
              v-for="(item, index) in data.customerFeedbackItems"
              :key="index"
              :primaryText="item.firstTextLine"
              :secondaryText="item.secondTextLine"
            />
          </VueSlickCarousel>
        </div>
      </div>
      <div>
        <customers
          @go-to="goTo"
          :selectedIndex="selectedIndex"
          :customers="customers"
        />
      </div>
    </div>
  </div>
</template>

<script>
import Testimonial from "./testimonial.vue";
import Customers from "./customers.vue";
import { getImage } from "../../../helpers/imageHelper";

export default {
  components: { Testimonial, Customers },
  data() {
    return {
      slickOptions: {
        slidesToShow: 1,
        arrows: false,
        autoplay: true,
        initialSlide: 0,
      },
      selectedIndex: 0,
    };
  },
  methods: {
    goTo(index) {
      this.$refs.carousel.goTo(index);
      this.updateIndex(index);
    },
    beforeChange(old, index) {
      this.updateIndex(index);
    },
    updateIndex(index) {
      this.selectedIndex = index;
    },
  },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    customers() {
      return this.data.customerFeedbackItems.map((item) => ({
        name: item.customerName,
        designation: item.customerTitle,
        image: getImage(item.customerAvatar),
      }));
    },
  },
};
</script>

<style scoped>
.item {
  position: relative;
}

.item::before {
  content: "";
  width: 100px;
  height: 71px;
  background: url("https://www.simform.com/static/quote-gray.svg");
  position: absolute;
  top: -40px;
  left: 0px;
  right: 0px;
  margin: 0px auto;
}
</style>
