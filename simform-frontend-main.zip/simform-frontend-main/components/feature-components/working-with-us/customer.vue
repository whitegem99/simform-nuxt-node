<template>
  <div
    :class="[
      'flex gap-4 antialiased w-full py-5 px-3 cursor-pointer transition-all duration-300 border-t-[3px]',
      selected && !single ? 'border-teal-400' : 'border-transparent',
    ]"
    @click="moveSlider()"
  >
    <div>
      <img :src="image.src" :alt="image.alt" class="w-14" />
    </div>
    <div class="text-left text-lg font-normal">
      <div
        :class="[
          'font-semibold transition-colors duration-300',
          selected ? 'text-primary-600' : '',
        ]"
      >
        {{ name }}
      </div>
      <div class="font-light text-base">{{ designation }}</div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    selected: Boolean,
    name: String,
    designation: String,
    image: Object,
    moveSlider: Function,
    single: {
      type: Boolean,
      default: false,
    },
  },
};
</script>
