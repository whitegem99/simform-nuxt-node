<template>
  <div class="mt-6 lg:mt-16 px-5">
    <div class="hidden lg:grid grid-cols-3">
      <customer
        v-for="(customer, index) in customers"
        :key="index"
        :name="customer.name"
        :designation="customer.designation"
        :image="customer.image"
        :selected="selectedIndex === index"
        :moveSlider="() => goTo(index)"
      />
    </div>

    <div class="block lg:hidden">
      <customer
        :name="selectedCustomer.name"
        :designation="selectedCustomer.designation"
        :image="selectedCustomer.image"
        selected
        :moveSlider="() => goTo(index)"
        single
      />
    </div>
  </div>
</template>

<script>
import Customer from "./customer.vue";
export default {
  components: { Customer },
  props: {
    selectedIndex: {
      type: Number,
      default: 0,
    },
    customers: {
      type: Array,
      required: true,
    },
  },
  data() {
    return {
      selectedIdx: this.selectedIndex,
      // customers: [
      //   {
      //     name: "Lenny Perkins",
      //     designation: "VP of Engineering",
      //     image: "https://www.simform.com/static/lenny-perkins.png",
      //   },
      //   {
      //     name: "Jawann Swislow",
      //     designation: "CIO",
      //     image: "https://www.simform.com/static/jawann-swislow-pic.png",
      //   },
      //   {
      //     name: "Harsimran Singh Virk",
      //     designation: "Head of Technology",
      //     image: "https://www.simform.com/static/harsimran-singh-virk.png",
      //   },
      // ],
    };
  },
  computed: {
    selectedCustomer() {
      return this.customers[this.selectedIdx];
    },
  },
  updated() {
    this.selectedIdx = this.selectedIndex;
  },
  methods: {
    goTo(index) {
      this.$emit("go-to", index);
    },
  },
};
</script>
