<template>
  <div class="flex-none">
    <div>
      <a
        href="http://www.redbull.com"
        target="_blank"
        @mouseenter="onHover(true)"
        @mouseleave="onHover(false)"
      >
        <span class="block">
          <img
            :src="colorImage.src"
            :alt="colorImage.alt"
            class="absolute opacity-0 transition-all duration-700 ease-in-out z-10"
            :style="styleLogo"
          />
          <img
            :src="grayImage.src"
            :alt="grayImage.alt"
            class="relative w-full"
          />
        </span>
      </a>
    </div>
  </div>
</template>

<script>
export default {
  name: "ClientSliderItem",
  props: {
    colorImage: Object,
    grayImage: Object,
  },
  data() {
    return {
      isHover: false,
    };
  },
  methods: {
    onHover(hoverState) {
      this.isHover = hoverState;
      this.$emit("on-hover", hoverState);
    },
  },
  computed: {
    styleLogo: function () {
      return {
        opacity: this.isHover ? 1 : 0,
      };
    },
  },
};
</script>
