<template>
  <client-only>
    <div class="mt-10 bg-[#d7e9ff26]">
      <div class="group pointer-events-none">
        <infinite-slide-bar
          :barStyle="{
            padding: '40px 0',
            'animation-play-state': hovered ? 'paused' : 'running',
          }"
          :duration="speed"
        >
          <div class="flex items-center justify-around gap-20 ml-20">
            <client-slider-item
              v-for="(item, index) in clientSliderItems"
              :key="index"
              :colorImage="item.colorImage"
              :grayImage="item.grayImage"
              class="group-hover:blur-sm transition-all duration-700 item-client-logo-slider pointer-events-auto"
              @on-hover="onPause"
            />
          </div>
        </infinite-slide-bar>
      </div>
    </div>
  </client-only>
</template>

<script>
import ClientSliderItem from "./client-slider-item.vue";
import ClientOnly from "vue-client-only";
export default {
  components: { ClientSliderItem, ClientOnly },
  props: {
    clientSliderItems: {
      type: Array,
      required: true,
    },
  },
  data() {
    return {
      isPaused: false,
      speed: "24s",
      hovered: false,
    };
  },
  methods: {
    onPause(value) {
      this.hovered = value;
    },
  },
};
</script>

<style>
.item-client-logo-slider:hover {
  filter: blur(0px) !important;
}
</style>
