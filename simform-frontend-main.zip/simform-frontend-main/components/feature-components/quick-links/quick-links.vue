<template>
  <div class="bg-[#fbeaea] rounded border border-[#f0f0f0] px-10 py-6 my-10">
    <h2 class="text-4xl font-extrabold py-8 pl-10">Quick Links</h2>
    <div>
      <check-mark-item v-for="item in items" :key="item.id">
        <template v-slot:default>
          <a :href="getLink(item.displayText)" class="underline font-bold text-primary-600">
            <div class="text-2xl font-semibold">{{ item.displayText }}</div>
          </a>
        </template>
      </check-mark-item>
    </div>
  </div>
</template>
<script>
import CheckMarkItem from "../check-mark-list/check-mark-item.vue";

export default {
  props: {
    items: {
      type: Array,
      required: true,
    },
  },
  components: { CheckMarkItem },
  methods: {
    getLink(text) {
      return `#${text.trim().replace(/<[^>]*>?/gm, '').toLowerCase().replace(/[^a-zA-Z0-9 ]/g, "").replace(/\s/g, "-")}`;
    },
  },
};
</script>
