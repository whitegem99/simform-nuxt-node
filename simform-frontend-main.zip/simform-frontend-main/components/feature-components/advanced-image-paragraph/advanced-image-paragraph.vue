<template>
  <div class="flex gap-10 my-16 group px-3 sm:px-0">
    <div
      class="group-odd:order-last group-even:order-first flex-1 group-odd:pl-10"
    >
      <title-underline :data="{ text: item.title, align: 'left' }" small />
      <div class="text-2xl mt-3 font-light" v-html="item.paragraph"></div>
      <review-person
        v-if="!!item.customerFeedbackItem"
        :name="item.customerFeedbackItem.customerName"
        :designation="item.customerFeedbackItem.customerTitle"
        :image="getImageData(item.customerFeedbackItem.customerAvatar)"
        description="Simform is quick to identify larger problem with the Software so we decided to expand our scope to build new modules"
      />
      <simple-check-mark-list
        v-if="item.checkMarkListItems.length > 0"
        :items="item.checkMarkListItems"
      />
    </div>
    <div class="flex-1 hidden sm:block">
      <div
        class="p-8 w-full h-full transition-all duration-500 ease-in-out"
        @mousemove="calculatePerspective"
        v-on:mouseleave="resetPerspective"
        :style="calculatedTranslate"
      >
        <div class="w-[95%] h-[70%] z-10" :style="_bgTransparent"></div>
        <div
          class="w-[95%] h-[80%] relative -top-[calc(70%-40px)] left-[40px] z-20 flex items-end"
          :style="_bgPrimary"
        >
          <img :src="image.src" class="w-[95%]" alt="image.alt" />
        </div>
        <div
          class="w-[95%] h-[70%] relative -top-[calc(200%-60%-80px)] left-[80px] z-10"
          :style="_bgTransparent"
        ></div>
      </div>
    </div>
  </div>
</template>

<script>
import { convertHexToRGB } from "@/helpers/HexConvert";
import { getImage } from "../../../helpers/imageHelper";
import TitleUnderline from "../../primary/title/title-underline.vue";
import SimpleCheckMarkList from "../simple-check-mark-list/simple-check-mark-list.vue";
import ReviewPerson from "./review-person.vue";

export default {
  name: "SoftwareBuildItem",
  components: { TitleUnderline, ReviewPerson, SimpleCheckMarkList },
  props: {
    item: {
      type: Object,
      required: true,
    },
  },
  data() {
    return {
      calculatedTranslate: {},
    };
  },
  computed: {
    _bgPrimary: function () {
      return `background-color: ${convertHexToRGB(this.color, 100)}`;
    },
    _bgTransparent: function () {
      return `background-color: ${convertHexToRGB(this.color, 50)}`;
    },
    image: function () {
      return getImage(this.item.image);
    },
    color: function () {
      return this.getColor(this.item.color);
    },
  },
  methods: {
    calculatePerspective(e) {
      return;

      let _x,
        _y,
        x,
        y = 0;

      _x = e.target.offsetLeft + Math.floor(e.target.offsetWidth / 2);
      _y = e.target.offsetTop + Math.floor(e.target.offsetHeight / 2);

      x = e.clientX - _x;
      y = (e.clientY - _y) * -1;

      let finalY = (y / e.target.offsetHeight / 2).toFixed(2);
      let finalX = (x / e.target.offsetWidth / 2).toFixed(2);

      const style =
        "perspective(200px) rotateX(" +
        finalX +
        "deg) rotateY(" +
        finalY +
        "deg) ";

      this.calculatedTranslate = {
        transform: style,
        webkitTransform: style,
        mozTranform: style,
        msTransform: style,
        oTransform: style,
      };
    },
    resetPerspective() {
      this.calculatedTranslate = {
        transform: "none",
        webkitTransform: "none",
        mozTranform: "none",
        msTransform: "none",
        oTransform: "none",
      };
    },
    getImageData(image) {
      return getImage(image);
    },
    getColor(color) {
      switch (color) {
        case "green":
          return "#bdefe4";
        case "purple":
          return "#c8bce7";
        case "yellow":
          return "#ffe4ad";
        case "pink":
          return "#edc2e6";
        default:
          return "#bdefe4";
      }
    },
  },
};
</script>
