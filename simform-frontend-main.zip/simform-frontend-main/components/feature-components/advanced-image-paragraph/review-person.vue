<template>
  <div>
    <div class="w-24 h-1 bg-teal-400 mt-10 mb-2"></div>
    <div
      class="py-3 text-2xl italic text-teal-400 font-light font-merriweather"
    >
      "{{ description }}"
    </div>
    <div
      class="flex gap-4 antialiased w-full py-5 px-3 cursor-pointer transition-all duration-300"
    >
      <div>
        <img :src="image.src" :alt="image.alt" class="w-16 h-16" />
      </div>
      <div class="text-left text-lg font-normal">
        <div
          class="font-semibold transition-colors duration-300 text-primary-600"
        >
          {{ name }}
        </div>
        <div class="font-bold text-base">{{ designation }}</div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "ReviewPerson",
  props: {
    name: {
      type: String,
      required: true,
    },
    designation: {
      type: String,
      required: true,
    },
    image: {
      type: Object,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
  },
};
</script>
