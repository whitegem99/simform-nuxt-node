<template>
  <div class="flex justify-center w-full">
    <div class="text-primary-500 text-3xl text font-merriweather italic max-w-xl">
    <span class="border-t-2 w-32 gray-bar"></span>
    <div class="my-5">
      {{ text }}
    </div>
    <span class="border-t-2 w-32 gray-bar"></span>
  </div>
  </div>
</template>
<script>
export default {
  props: {
    text: {
      type: String,
      required: true,
    },
  },
};
</script>
<style scoped>
.gray-bar {
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  width: 124px;
  height: 2px;
  background: #d8d8d8;
}

.text {
  position: relative;
  padding: 14px 0 16px;
  text-align: center;
  margin: 70px 0 50px;
}
</style>