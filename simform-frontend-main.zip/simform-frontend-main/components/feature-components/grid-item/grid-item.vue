<template>
  <div
    class="grid grid-cols-5 gap-2 p-6 self-card transition-all duration-500 border border-solid border-gray-200 hover:shadow-lg group bg-white"
    :style="cardBackground"
  >
    <div class="col-span-1">
      <img
        :src="item.icon.src"
        class="w-12 h-12 self-start place-self-start group-hover:-translate-y-2 transition-all duration-500 group-hover:drop-shadow-xl"
        :alt="item.icon.alt"
      />
    </div>
    <div class="col-span-4">
      <div>
        <h5
          class="text-xl font-semibold group-hover:-translate-y-2 transition-all duration-500"
        >
          {{ item.title }}
        </h5>
        <div
          class="mt-2 group-hover:-translate-y-1 transition-all duration-500 font-[17px] font-light"
          v-html="item.description"
        ></div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    item: {
      type: Object,
      required: true,
    },
  },
  computed: {
    cardBackground() {
      return `--bg-color: ${this.item.color.bg}`;
    },
  },
};
</script>
<style>
.self-card:hover {
  background-color: var(--bg-color);
}
</style>
