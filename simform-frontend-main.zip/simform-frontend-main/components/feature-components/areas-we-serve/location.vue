<template>
  <div class="flex flex-col max-w-[230px]">
    <span class="font-bold mb-1">{{ location }}</span>
    <p class="font-normal text-gray-600">{{ address }}</p>
    <a :href="phoneLink" class="mt-2 font-medium">Call us now</a>
  </div>
</template>
<script>
export default {
  props: ['location', 'address', 'phone'],
  computed: {
    phoneLink: function () {
      return `tel:${this.phone}`
    }
  }
}
</script>
