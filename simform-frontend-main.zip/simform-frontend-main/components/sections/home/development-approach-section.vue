<template>
  <simform-section gradient>
    <div class="max-w-6xl pt-20 mx-auto">
      <div class="max-w-xl mx-auto">
        <title-underline
          :data="{ text: data.title, align: 'center' }"
          singleLine
        />
      </div>
      <color-box-item-grid :items="data.colorGridItems" />
    </div>
  </simform-section>
</template>

<script>
import TitleUnderline from "../../primary/title/title-underline.vue";
import ColorBoxItemGrid from "../../feature-components/development-approach/color-box-item-grid.vue";
import SimformSection from "@/components/sections/basic/simform-section";
export default {
  components: { SimformSection, TitleUnderline, ColorBoxItemGrid },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
};
</script>
