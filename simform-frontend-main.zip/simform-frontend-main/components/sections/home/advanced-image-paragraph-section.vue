<template>
  <simform-section white>
    <div class="max-w-6xl mx-auto">
      <div class="my-20 max-w-xl mx-auto">
        <title-underline :data="{ text: data.title, align: 'center' }" />
      </div>
      <advanced-image-paragraph
        :item="item"
        v-for="item in data.advancedImageParagraphItems"
        :key="item.id"
      />
    </div>
  </simform-section>
</template>

<script>
import TitleUnderline from "../../primary/title/title-underline.vue";
import AdvancedImageParagraph from "../../feature-components/advanced-image-paragraph/advanced-image-paragraph.vue";
import ReviewPerson from "../../feature-components/advanced-image-paragraph/review-person.vue";
import HighlightText from "../../primary/highlight-text/highlight-text.vue";
import SimformSection from "@/components/sections/basic/simform-section";
import SimpleCheckMarkList from "../../feature-components/simple-check-mark-list/simple-check-mark-list.vue";

export default {
  name: "WayOfBuildingSection",
  components: {
    SimformSection,
    TitleUnderline,
    AdvancedImageParagraph,
    ReviewPerson,
    HighlightText,
    SimpleCheckMarkList,
  },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
};
</script>
