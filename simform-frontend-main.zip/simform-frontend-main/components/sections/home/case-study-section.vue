<template>
  <simform-section white>
    <div class="max-w-5xl mx-auto my-10">
      <title-underline
        :data="{ text: data.title, align: 'center' }"
        singleLine
      />
      <div class="mt-20">
        <case-studies-list :case-studies="this.data.case_studies.data" />
      </div>
    </div>

    <div class="hidden">
      <div class="bg-sky-300/70 bg-sky-200"></div>
      <div class="bg-lime-300/70 bg-lime-200"></div>
      <div class="bg-teal-300/70 bg-teal-200"></div>
      <div class="bg-amber-300/70 bg-amber-200"></div>
    </div>
    <div class="w-full flex justify-center pt-10">
      <simform-button reverse class="mx-auto block px-8" url="/case-studies">
        <span class="font-medium">Read more case studies</span>
      </simform-button>
    </div>
  </simform-section>
</template>

<script>
import TitleUnderline from "../../primary/title/title-underline.vue";
import CaseStudiesList from "../../feature-components/case-studies/case-studies-list.vue";
import SimformButton from "@/components/primary/button/simform-button";
import SimformSection from "@/components/sections/basic/simform-section";

export default {
  components: {
    SimformSection,
    SimformButton,
    TitleUnderline,
    CaseStudiesList,
  },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
};
</script>
