<template>
  <section :class="backgroundClass" class="py-10">
    <div class="max-w-7xl mx-auto py-10 px-4">
      <action-banner
        :title="data.text"
        :actionText="data.buttonText"
        url="/contact"
        :withTweak="withTweak"
      />
    </div>
  </section>
</template>

<script>
import ActionBanner from "../../feature-components/action-banner/action-banner.vue";
import SimformSection from "@/components/sections/basic/simform-section";
export default {
  components: { SimformSection, ActionBanner },
  props: {
    data: {
      type: Object,
      required: true,
    },
    withTweak: {
      type: Boolean,
      default: false,
    },
  },
  computed: {
    backgroundClass() {
      return this.data.withPurpleBackground ? "purple-background" : "";
    },
  },
};
</script>
<style scoped>
.purple-background {
  background: rgb(238, 242, 255)
}
</style>
