<template>
  <simform-section white extra-padding>
    <div class="mt-10">
      <div>
        <title-underline :data="{ text: data.title, align: 'center' }" />
      </div>
      <working-with-us :data="data" />
    </div>
  </simform-section>
</template>

<script>
import WorkingWithUs from "../../feature-components/working-with-us/working-with-us.vue";
import TitleUnderline from "../../primary/title/title-underline.vue";
import SimformSection from "@/components/sections/basic/simform-section";

export default {
  name: "WorkingWithUsSection",
  components: { SimformSection, WorkingWithUs, TitleUnderline },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
};
</script>
