<template>
  <div>
    <service-item-slider :items="items" />
  </div>
</template>

<script>
import ServiceItemSlider from "../../feature-components/service-item-slider/service-item-slider.vue";
import TitleUnderline from "../../primary/title/title-underline.vue";
import SimformSection from "@/components/sections/basic/simform-section";
export default {
  components: { SimformSection, ServiceItemSlider, TitleUnderline },
  props: {
    items: {
      type: Array,
      required: true,
    },
  },
};
</script>
