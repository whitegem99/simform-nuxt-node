<template>
  <simform-section white extra-padding>
    <div class="max-w-7xl mx-auto hidden sm:block">
      <div class="pb-10">
        <title-underline
          :data="{
            text: data.title,
            align: 'center',
          }"
        />
      </div>
      <how-development-works :items="items" />
    </div>
  </simform-section>
</template>

<script>
import TitleUnderline from "../../primary/title/title-underline.vue";
import HowDevelopmentWorks from "../../feature-components/how-works/how-development-works.vue";
import SimformSection from "@/components/sections/basic/simform-section";
import { getImage } from "../../../helpers/imageHelper";
export default {
  components: { SimformSection, TitleUnderline, HowDevelopmentWorks },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    items() {
      return this.data.colorGridItems.map((item) => ({
        title: item.title,
        description: item.text,
        image: getImage(item.icon),
        color: item.color,
      }));
    },
  },
};
</script>
