<template>
  <section class="py-12 bg-gradient-to-b from-blue-100 to-white">
    <div class="max-w-6xl mx-auto">
        <img :src="image.src" :alt="image.alt" class="mx-auto py-5" />
        <div v-html="title" class="title text-5xl font-semibold text-center mx-auto leading-tight py-5"></div>
        <div class="max-w-4xl mx-auto">
          <div v-html="description" class="text-2xl font-light text-center"></div>
        </div>
    </div>
  </section>
</template>
<script>
import { getImage } from '../../../helpers/imageHelper';
export default {
  props: {
    data: {
      type: Object,
      default: {},
    },
  },
  computed: {
    title() {
      return this.data.title;
    },
    image() {
      return getImage(this.data.heroImage);
    },
    description() {
      return this.data.description;
    },
  },
};
</script>
<style scoped>
.title > p > u {
  text-decoration: none;
  background-image: linear-gradient(
    100deg,
    rgb(61, 61, 61),
    rgb(61, 61, 61),
    rgb(255, 77, 99)
  );
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
  display: inline;
}
</style>
