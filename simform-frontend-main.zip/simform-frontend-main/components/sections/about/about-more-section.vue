<template>
  <simform-section white>
    <div class="max-w-6xl mx-auto">
      <title-underline :data="{ text: title, align: 'center' }" />
      <about-more-item
        v-for="item in items"
        :key="`about-more-item-${item.id}`"
        :data="item"
        class="mb-14"
      />
      <div class="flex justify-center my-20">
        <simform-button reverse url="/contact">
        <span class="font-medium">Explore our openings</span>
      </simform-button>
      </div>
    </div>
  </simform-section>
</template>
<script>
import SimformButton from "../../primary/button/simform-button.vue";
import TitleUnderline from "../../primary/title/title-underline.vue";
import simformSection from "../basic/simform-section.vue";
import AboutMoreItem from "./about-more-item.vue";
export default {
  components: { simformSection, TitleUnderline, AboutMoreItem, SimformButton },
  props: {
    data: {
      type: Object,
      default: {},
    },
  },
  computed: {
    title() {
      return this.data.title;
    },
    items() {
      return this.data.items;
    },
  },
};
</script>
<style lang=""></style>
