<template>
  <simform-section white>
    <div class="max-w-6xl mx-auto">
      <title-underline :data="{ text: title, align: 'center' }" />
      <about-team-item v-for="(item,index) in items" :key="`about-team-item-${item.id}`" :items="item" class="mt-10 mb-32 transform odd:translate-x-12" :index="index" />
    </div>
  </simform-section>
</template>
<script>
import TitleUnderline from "../../primary/title/title-underline.vue";
import simformSection from "../basic/simform-section.vue";
import AboutTeamItem from './about-team-item.vue';
export default {
  components: { simformSection, TitleUnderline, AboutTeamItem },
  props: {
    data: {
      type: Object,
      default: {},
    },
  },
  computed: {
    title() {
      return this.data.title;
    },
    items() {
      const chunkSize = 3;
      return this.data.items
        .reduce((acc, curr, index) => {
          const chunkIndex = Math.floor(index / chunkSize);
          if (!acc[chunkIndex]) {
            acc[chunkIndex] = [];
          }
          acc[chunkIndex].push(curr);
          return acc;
        }, [])
        .map((subArray) => subArray.filter(Boolean));
    },
  },
};
</script>
