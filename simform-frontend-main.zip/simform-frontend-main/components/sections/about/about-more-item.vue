<template>
  <div class="flex group mt-10">
    <div class="flex-1 group-even:order-last group-odd:order-first relative">
      <img
        :src="img.src"
        :alt="img.alt"
        v-for="(img, index) in images"
        :key="`about-more-item-${img.id}`"
        class="absolute group-even:block group-odd:hidden"
        :class="getImageClass(index, true)"
      />

      <img
        :src="img.src"
        :alt="img.alt"
        v-for="(img, index) in images"
        :key="`about-more-item-${img.id}`"
        class="absolute group-odd:block group-even:hidden"
        :class="getImageClass(index, false)"
      />
    </div>
    <div class="flex-1 group-even:pr-14 group-odd:pl-14 mt-10">
      <div
        v-for="item in items"
        :key="`about-more-item-col-${item.id}`"
        class="flex flex-col gap-5 mb-20"
      >
        <img :src="item.icon.src" :alt="item.icon.alt" class="w-16 h-16" />
        <div v-html="item.title" class="text-3xl font-semibold"></div>
        <div v-html="item.text" class="text-2xl font-light"></div>
      </div>
    </div>
  </div>
</template>
<script>
import { getImage } from "../../../helpers/imageHelper";

export default {
  props: {
    data: {
      type: Object,
      default: {},
    },
  },
  computed: {
    title() {
      return this.data.title;
    },
    images() {
      return this.data.images.data.map((img) => getImage({ data: img }));
    },
    items() {
      return this.data.items.map((item) => ({
        ...item,
        icon: getImage(item.icon),
      }));
    },
  },
  methods: {
    getImageClass(index, isEven) {
      return isEven ? `even-${index + 1}-image` : `odd-${index + 1}-image`;
    },
  },
};
</script>
<style>
.even-1-image {
  top: 120px;
  z-index: 10;
}

.even-2-image {
  right: 10px;
}

.even-3-image {
  bottom: 30px;
  right: 50px;
  z-index: 20;
}

.odd-1-image {
  top: 120px;
  right: 0px;
  z-index: 10;
}

.odd-2-image {
  right: 120px;
  bottom: 0;
  z-index: 10;
}

.odd-3-image {
  z-index: 0;
  top: 30px;
}
</style>
