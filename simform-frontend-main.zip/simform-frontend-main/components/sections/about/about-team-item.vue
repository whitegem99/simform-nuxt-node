<template>
  <div class="relative h-[300px]">
    <div
      class="w-full transition-all duration-300 h-[335px] absolute"
      :class="color"
    >
      &nbsp;
    </div>
    <div
      :class="`${color}-bg`"
      class="bg-blend-overlay w-full top-5 right-5 h-[335px] absolute group-hover:translate-x-1 group-hover:-translate-y-1 duration-500 transition-all"
    >
      <div class="grid grid-cols-3 h-[315px]">
        <div
          v-for="item in teamItems"
          :key="`about-team-item-${item.id}`"
        >
          <div class="flex flex-col items-center justify-between h-full">
            <div class="pt-10">
              <div class="text-lg font-semibold">{{ item.name }}</div>
              <div>— {{ item.designation }}</div>
            </div>
            <div>
              <img :src="item.image.src" :alt="item.image.alt" />
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { getImage } from "../../../helpers/imageHelper";

export default {
  props: {
    items: {
      type: Array,
      required: true,
    },
    index: {
      type: Number,
      required: true,
    },
  },
  computed: {
    teamItems() {
      return this.items.map((item) => ({
        ...item,
        image: getImage(item.image),
      }));
    },
    color() {
      return this.index % 2 === 0 ? "blue" : "purple";
    },
  },
};
</script>
<style scoped>
.blue-bg {
    background: rgba(199, 221, 243, 0.7);
}

.blue {
    background: rgb(182, 209, 236);
}

.purple-bg {
    background: rgba(232, 228, 244, 0.7);
}

.purple {
  background: rgb(214, 206, 237);
}
</style>
