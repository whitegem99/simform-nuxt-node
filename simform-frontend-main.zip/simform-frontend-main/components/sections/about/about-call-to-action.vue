<template>
  <simform-section white>
    <div class="max-w-6xl mx-auto">
      <div class="flex">
        <div class="basis-5/12 flex flex-col justify-center items-center">
          <div class="text-5xl font-semibold text-center py-5 mb-5">{{ text }}</div>
          <simform-button reverse url="/contact">
            <span class="font-medium">{{ buttonText }}</span>
          </simform-button>
        </div>
        <div class="basis-7/12">
          <img :src="image.src" :alt="image.alt" class="mx-auto py-5" />
        </div>
      </div>
    </div>
  </simform-section>
</template>
<script>
import { getImage } from "../../../helpers/imageHelper";
import SimformButton from "../../primary/button/simform-button.vue";
import simformSection from "../basic/simform-section.vue";
export default {
  components: { simformSection, SimformButton },
  props: {
    data: {
      type: Object,
      default: {},
    },
  },
  computed: {
    text() {
      return this.data.text;
    },
    buttonText() {
      return this.data.buttonText;
    },
    image() {
      return getImage(this.data.image);
    },
  },
};
</script>
