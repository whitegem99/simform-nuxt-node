<template>
  <simform-section white>
    <div class="max-w-6xl mx-auto">
      <title-underline :data="{ text: title, align: 'center' }" />
      <div v-html="description" class="text-2xl font-light text-center py-5"></div>
      <div class="flex flex-col gap-5 py-14">
        <dev-stack-item v-for="item in items" :key="`dev-stack-item-${item.id}`" :data="item" />
      </div>
    </div>
  </simform-section>
</template>
<script>
import DevStackItem from '../../feature-components/about/dev-stack-item.vue';
import titleUnderline from "../../primary/title/title-underline.vue";
import SimformSection from '../basic/simform-section.vue';
export default {
  components: { titleUnderline, SimformSection, DevStackItem },
  props: {
    data: {
      type: Object,
      default: {},
    },
  },
  computed: {
    title() {
      return this.data.title;
    },
    description() {
      return this.data.description;
    },
    items() {
      return this.data.items;
    },
  },
};
</script>
<style lang=""></style>
