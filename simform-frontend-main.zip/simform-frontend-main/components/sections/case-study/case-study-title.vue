<template>
  <simform-section only-top-padding>
    <div class="max-w-6xl mx-auto px-10 mt-10">
      <h3 class="leading-[1.3] text-secondary-800 text-5xl font-semibold" v-html="data.text"></h3>
    </div>
  </simform-section>
</template>
<script>
import SimformSection from "@/components/sections/basic/simform-section";
import TitleUnderline from "../../../components/primary/title/title-underline.vue";

export default {
  components: { SimformSection, TitleUnderline },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
};
</script>
<style lang=""></style>
