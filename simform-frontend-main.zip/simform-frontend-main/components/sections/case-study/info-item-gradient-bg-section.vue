<template>
  <simform-section>
    <div class="bg-gradient">
      <div class="container-area">
        <div class="text-3xl font-semibold mb-14">
          {{ data.title }}
        </div>
        <div class="max-w-4xl">
            <div class="grid grid-cols-2 gap-x-20 gap-y-10">
          <div v-for="item in items" :key="item.id" class="mb-10">
            <div class="mb-7">
                <img :src="item.image.src" :alt="item.image.alt" />
            </div>
            <div class="text-lg font-light" v-html="item.description">
            </div>
          </div>
        </div>
        </div>
      </div>
      <div class="img-blk">
        <img :src="image.src" :alt="image.alt" />
      </div>
    </div>
  </simform-section>
</template>
<script>
import SimformSection from "@/components/sections/basic/simform-section";
import { getImage } from "../../../helpers/imageHelper";
export default {
  components: { SimformSection },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    image() {
      return getImage(this.data.sideImage);
    },
    items() {
      return this.data.items.map((item) => {
        return {
          id: item.id,
          image: getImage(item.image),
          description: item.description,
        };
      });
    },
  },
};
</script>
<style scoped>
.bg-gradient {
  background: linear-gradient(
    rgb(234, 255, 228),
    rgb(248, 255, 246) 54%,
    rgb(234, 255, 228)
  );
  padding: 45px 0px 0px;
  position: relative;
}

.img-blk {
  position: absolute;
  right: 0px;
  top: 0px;
  width: 533px;
  margin: -17px 0px -19px;
}

.container-area {
  max-width: 1220px;
  margin: 0px auto;
  padding: 0px 40px;
}
</style>
