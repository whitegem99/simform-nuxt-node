<template>
  <simform-section>
    <div class="max-w-6xl mx-auto px-10">
      <div class="grid grid-cols-2">
        <div>
          <img
            :src="item.src"
            :alt="item.alt"
            v-for="item in leftSection"
            :key="item.id"
          />
        </div>
        <div class="pt-56">
          <img
            :src="item.src"
            :alt="item.alt"
            v-for="item in rightSection"
            :key="item.id"
          />
        </div>
      </div>
    </div>
  </simform-section>
</template>
<script>
import SimformSection from "@/components/sections/basic/simform-section";
import { getImage } from "../../../helpers/imageHelper";

export default {
  components: { SimformSection },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    leftSection() {
      return this.data.leftSection.map((item) => getImage(item));
    },
    rightSection() {
      return this.data.rightSection.map((item) => getImage(item));
    },
  },
};
</script>
