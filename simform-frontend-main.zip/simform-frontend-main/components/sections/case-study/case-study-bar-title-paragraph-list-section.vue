<template>
  <simform-section white>
    <div class="max-w-6xl mx-auto p-10">
      <div>
        <div v-for="item in items" class="group">
          <div v-if="item.image" class="group-last:mb-0 mb-24">
            <div
              class="text-[44px] leading-tight font-semibold"
              v-html="item.title"
            ></div>
            <div class="top-border mt-5 mb-10 w-[250px]"></div>
            <div class="grid grid-cols-2 gap-10 mt-5">
              <div
                class="text-2xl font-light group-even:order-last group-odd:order-first pr-5"
                v-html="item.paragraph"
              ></div>
              <div>
                <img
                  :src="item.image.src"
                  :alt="item.image.alt"
                  class="w-full"
                />
              </div>
            </div>
          </div>
          <div v-else class="group-last:mb-0 mb-24">
            <div class="grid grid-cols-2 gap-20 mt-5">
              <div>
                <div class="top-border mt-5 mb-10 w-full"></div>
                <div
                  class="text-[44px] leading-tight font-semibold pr-10"
                  v-html="item.title"
                ></div>
              </div>
              <div>
                <div class="top-border mt-5 mb-10 w-full"></div>
                <div
                  class="text-2xl font-light group-even:order-last group-odd:order-first pr-5"
                  v-html="item.paragraph"
                ></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </simform-section>
</template>
<script>
import SimformSection from "@/components/sections/basic/simform-section";
import { getImage } from "../../../helpers/imageHelper";

export default {
  components: { SimformSection },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    items() {
      return this.data.items.map((item) => {
        return {
          title: item.title,
          paragraph: item.paragraph,
          image: item.image ? getImage(item.image) : null,
        };
      });
    },
  },
};
</script>
<style>
.top-border {
  border-top: 3px solid rgb(61, 61, 61);
}
</style>
