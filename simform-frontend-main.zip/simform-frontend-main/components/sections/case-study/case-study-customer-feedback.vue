<template>
  <simform-section class="max-w-6xl mx-auto p-10" extraPadding>
    <div class="flex gap-10">
      <div class="iconquote"></div>
      <div class="flex-1 border-t-secondary-300 border-t mt-8 pt-16 px-6">
        <div class="font-merriweather text-4xl leading-relaxed italic">
          <span class="text-[#29ded5]">“{{ first + `${second ? '' : '”'}` }}</span>
          <span v-if="second">{{ second + '”' }}</span>
        </div>

        <div class="mt-8 flex gap-5 items-center">
          <img
            v-if="image"
            :src="image.src"
            :alt="image.alt"
            class="w-12 h-12 rounded-full"
          />
          <div class="text-lg font-semibold mt-2">
            <span>{{ name }}</span>
            <span class="font-normal" v-if="position"><span class="px-2">|</span> {{ position }}</span>
          </div>
        </div>
      </div>
    </div>
  </simform-section>
</template>
<script>
import SimformSection from "@/components/sections/basic/simform-section";
import { getImage } from "../../../helpers/imageHelper";

export default {
  components: { SimformSection },
  props: {
    content: {
      type: Object,
      required: true,
    },
  },
  computed: {
    first() {
      return this.content.firstTextLine;
    },
    second() {
      return this.content.secondTextLine;
    },
    image() {
      return this.content.customerAvatar ? getImage(this.content.customerAvatar) : null;
    },
    name() {
      return this.content.customerName;
    },
    position() {
      return this.content.customerTitle;
    },
  },
};
</script>
<style scoped>
.iconquote {
  width: 83px;
  height: 59px;
  left: 0px;
  top: 0px;
  background-repeat: no-repeat;
  background: url("data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI4MyIgaGVpZ2h0PSI1OSIgdmlld0JveD0iMCAwIDgzIDU5Ij4KICAgIDxwYXRoIGZpbGw9IiMyOURFRDUiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTc3IDBINTlMNDcgMjMuNlY1OWgzNlYyMy42SDY1TDc3IDB6TTMwIDBIMTJMMCAyMy42VjU5aDM2VjIzLjZIMThMMzAgMHoiLz4KPC9zdmc+Cg==");
}
</style>
