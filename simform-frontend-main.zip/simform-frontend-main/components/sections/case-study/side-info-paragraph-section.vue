<template>
  <simform-section extraPadding>
    <div class="max-w-6xl mx-auto px-10">
      <div class="flex gap-10">
        <div class="flex  flex-col justify-between">
          <div>
            <div
              class="w-[200px] text-5xl font-semibold"
              v-html="data.title"
            ></div>
          </div>
          <div class="w-[200px] flex items-end">
            <div class="bottom-content relative pt-7">
              <div
                class="uppercase text-base font-bold mb-1"
                v-html="data.subTitle"
              ></div>
              <div
                class="font-normal text-sm"
                v-html="data.subDescription"
              ></div>
            </div>
          </div>
        </div>
        <div class="flex-1 text-[22px]">
          <div v-html="data.paragraph" class="mb-5"></div>
          <image-section v-if="hasImage" :data="data" />

          <div v-if="imageGrid" class="grid grid-cols-3 mt-7">
            <img v-for="image in imageGrid" :key="image.id" :src="image.src" :alt="image.alt" />
          </div>

          <div v-if="data.secondParagraph" v-html="data.secondParagraph"></div>
        </div>
      </div>
      <div v-if="bottomImage" class="pl-[250px]">
        <image-section v-if="bottomImage" :data="{ image: data.bottomImage }" />
      </div>
    </div>
  </simform-section>
</template>
<script>
import SimformSection from "@/components/sections/basic/simform-section";
import { getImage } from "../../../helpers/imageHelper";
import ImageSection from "../common/image-section.vue";

export default {
  components: { SimformSection, ImageSection },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    hasImage() {
      return !!this.data.image;
    },
    imageGrid() {

      if(!this.data.imageGrid) return null

      return this.data.imageGrid.map((image) => {
        return getImage(image);
      })
    },
    bottomImage() {
      return getImage(this.data.bottomImage);
    },
  },
};
</script>
<style scoped>
.bottom-content::before {
  content: "";
  position: absolute;
  width: 55px;
  height: 3px;
  background: rgb(61, 61, 61);
  top: 0px;
  left: 0px;
}
</style>
