<template>
  <simform-section>
    <div class="max-w-6xl mx-auto px-10">
      <text-paragraph :data="data" />
    </div>
  </simform-section>
</template>
<script>
import SimformSection from "@/components/sections/basic/simform-section";
import TextParagraph from "../../primary/paragraph/text-paragraph.vue";

export default {
  components: { SimformSection, TextParagraph },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
};
</script>