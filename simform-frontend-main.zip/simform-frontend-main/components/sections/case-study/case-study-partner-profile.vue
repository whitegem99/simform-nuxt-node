<template>
  <section class="max-w-6xl mx-auto px-10">
    <div class="mb-10">
      <div class="py-4 uppercase font-semibold">Partner Profile</div>
      <div class="flex pb-8 gap-10 justify-between">
        <div class="text-5xl font-semibold text-[#01d472]">
          {{ title }}
        </div>
        <div class="flex-grow flex gap-10 justify-center">
          <img
            :src="image.src"
            :alt="image.alt"
            v-for="image in images"
            :key="image.id"
            class="h-7"
          />
        </div>
      </div>
      <div class="grid grid-cols-4 gap-20">
        <partner-profile-item
          v-for="item in items"
          :key="item.id"
          :content="item"
        />
      </div>
    </div>
  </section>
</template>
<script>
import { getImage } from "../../../helpers/imageHelper";
import PartnerProfileItem from "./partner-profile-item.vue";

export default {
  props: {
    content: {
      type: Object,
      required: true,
    },
  },
  computed: {
    items() {
      return this.content.partnerItems;
    },
    images() {
      return this.content.images.map((image) => {
        return getImage(image);
      });
    },
    title() {
      return this.content.companyName;
    },
  },
  components: { PartnerProfileItem },
};
</script>
