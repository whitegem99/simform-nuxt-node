<template>
  <simform-section class="mx-auto" extraPadding>
    <div :class="colorClass" class="shadow-md py-20">
      <div class="relative">
        <div class="flex justify-start">
          <div class="max-w-4xl mx-auto">
            <div class="w-[60%]">
                <div v-html="title" class="text-5xl font-semibold mb-10"></div>
            <div
              v-html="description"
              class="text-xl tracking-wide font-medium"
            ></div>
            </div>
          </div>
        </div>
        <div class="image-block">
          <img :src="img.src" :alt="img.alt" class="-right-20 relative"/>
        </div>
      </div>
    </div>
  </simform-section>
</template>
<script>
import SimformSection from "@/components/sections/basic/simform-section";
import { getImage } from "../../../helpers/imageHelper";

export default {
  components: { SimformSection },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    title() {
      return this.data.title;
    },
    description() {
      return this.data.description;
    },
    color() {
      return this.data.color;
    },
    img() {
      return getImage(this.data.image);
    },
    colorClass() {
      let colorClass = "";

      if (this.color === "sky") {
        colorClass = "sky";
      }

      return colorClass;
    },
  },
};
</script>
<style scoped>
.sky {
  background-color: #cce7ff;
  border: 1px solid #99cfff;
}

.image-block {
  position: absolute;
  bottom: -130px;
  right: -1px;
  width: 741px;
  overflow: hidden;
}
</style>
