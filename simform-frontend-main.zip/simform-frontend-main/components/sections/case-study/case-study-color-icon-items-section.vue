<template>
  <simform-section white>
    <div class="max-w-6xl mx-auto py-10">
      <div class="grid grid-cols-3 gap-14">
        <div>
          <h2 class="text-5xl font-bold pb-10 text-gray-800">{{ title }}</h2>
          <div v-html="paragraph" class="text-2xl font-light"></div>
        </div>
        <div class="col-span-2 grid grid-cols-2 gap-x-14 gap-y-5">
          <div v-for="item in items" :key="item.id" class="mb-5">
            <div>
              <img :src="item.icon.src" :alt="item.icon.alt" />
            </div>
            <div class="text-2xl font-semibold pt-10 pb-5 min-h-[130px]">
              {{ item.title }}
            </div>
            <div v-html="item.text" class="text-2xl font-light"></div>
          </div>
        </div>
      </div>
    </div>
  </simform-section>
</template>
<script>
import SimformSection from "@/components/sections/basic/simform-section";
import { getImage } from "../../../helpers/imageHelper";

export default {
  components: { SimformSection },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    title() {
      return this.data.title;
    },
    paragraph() {
      return this.data.paragraph;
    },
    items() {
      return this.data.items.map((item) => {
        return {
          title: item.title,
          text: item.text,
          icon: getImage(item.icon),
        };
      });
    },
  },
};
</script>
