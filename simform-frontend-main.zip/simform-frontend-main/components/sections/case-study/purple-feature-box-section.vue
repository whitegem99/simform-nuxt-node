<template>
  <simform-section white extraPadding>
    <div class="max-w-6xl mx-auto px-10 text-2xl">
      <h2 class="text-5xl font-bold pb-10 text-gray-800">{{ title }}</h2>
      <div class="flex gap-20">
        <div class="flex-1" v-for="item in items" :key="item.id">
          <purple-feature-box :data="item" />
        </div>
      </div>
    </div>
  </simform-section>
</template>
<script>
import SimformSection from "@/components/sections/basic/simform-section";
import { getImage } from "../../../helpers/imageHelper";
import PurpleFeatureBox from "./purple-feature-box.vue";
export default {
  components: { SimformSection, PurpleFeatureBox },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    title() {
      return this.data.title;
    },
    items() {
      return this.data.items.map((item) => {
        return {
          title: item.title,
          description: item.description,
          image: getImage(item.image),
        };
      });
    },
  },
};
</script>
