<template>
  <section class="max-w-6xl mx-auto p-10 my-10">
    <div>
      <h2 class="text-5xl font-bold pb-10 text-gray-800">{{ title }}</h2>
      <div v-html="description" class="text-2xl font-light"></div>
    </div>
  </section>
</template>
<script>
export default {
  props: {
    content: {
      type: Object,
      required: true,
    },
  },
  computed: {
    title() {
      return this.content.title;
    },
    description() {
      return this.content.description;
    },
  },
};
</script>
