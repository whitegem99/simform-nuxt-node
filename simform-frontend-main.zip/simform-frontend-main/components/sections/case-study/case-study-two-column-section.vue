<template>
  <simform-section>
    <div class="max-w-6xl mx-auto px-10 text-2xl">
      <h2 class="text-5xl font-bold pb-10 text-gray-800">{{ title }}</h2>
      <div class="flex gap-20">
        <div :class="firstColumnCssClass">
          <div :class="firstColumnContentCssClass" v-html="firstColumnText"></div>
          <img :src="leftImage.src" :alt="leftImage.alt" class="my-10 w-[90%]"/>
        </div>
        <div
          class="flex-1 text-[22px] font-light tracking-wide two-col-text"
          v-html="secondColumnText"
        ></div>
      </div>
    </div>
  </simform-section>
</template>
<script>
import SimformSection from "@/components/sections/basic/simform-section";
import { getImage } from "../../../helpers/imageHelper";

export default {
  components: { SimformSection },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    title() {
      return this.data.title;
    },
    firstColumnText() {
      return this.data.firstColumnText;
    },
    secondColumnText() {
      return this.data.secondColumnText;
    },
    italicFirstColumn() {
      return this.data.italicFirstColumn;
    },
    equalColumnWidth() {
      return this.data.equalColumns;
    },
    leftImage() {
      return getImage(this.data.leftImage);
    },
    firstColumnCssClass() {
      let classVal = "";

      if (!this.equalColumnWidth) {
        classVal = "w-[250px]";
      } else {
        classVal = "flex-1";
      }

      return classVal;
    },
    firstColumnContentCssClass() {
      let classVal = "leading-normal font-light text-[22px] tracking-wide";

      if (this.italicFirstColumn) {
        classVal = "text-4xl font-merriweather italic font-normal leading-snug";
      }

      return classVal;
    }
  },
};
</script>
