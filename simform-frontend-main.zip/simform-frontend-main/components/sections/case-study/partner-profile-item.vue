<template>
  <div class="text-center w-full top-border py-10 px-5 pb-4">
    <div class="text-[48px] font-light">{{ data }}</div>
    <div class="text-sm font-bold uppercase py-3">{{ description }}</div>
  </div>
</template>
<script>
export default {
  props: {
    content: {
      type: Object,
      required: true,
    },
  },
  computed: {
    description() {
      return this.content.description;
    },
    data() {
      return this.content.data;
    },
  },
};
</script>
<style scoped>
.top-border {
  border-top: 3px solid rgb(61, 61, 61);
}
</style>
