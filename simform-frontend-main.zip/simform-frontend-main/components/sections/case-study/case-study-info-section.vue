<template>
  <simform-section>
    <div class="max-w-6xl mx-auto py-10">
      <div class="benefits-section-container">
        <div class="benefits-section-bg"></div>
        <div class="benefits-section gap-10">
          <div class="w-60">
            <img :src="image.src" :alt="image.alt" />
          </div>
          <div class="flex-1">
            <div class="text-[38px] font-semibold mb-5">{{ title }}</div>
            <div>
              <div
                v-for="item in items"
                key="item.id"
                class="flex gap-5 mb-5 items-start"
              >
                <img
                  src="~/assets/images/check-line-icons.png"
                  alt=""
                  class="mt-1"
                />
                <div class="text-2xl font-semibold">
                  {{ item.text }}
                </div>
              </div>
            </div>
            <div class="mt-10">
              <simform-button
                class="justify-self-end flex align-middle"
                url="/contact"
              >
                <span
                  class="flex justify-center items-center uppercase tracking-wide font-semibold mt-[4px] px-4"
                  >{{ buttonText }}</span
                >
              </simform-button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </simform-section>
</template>
<script>
import SimformSection from "@/components/sections/basic/simform-section";
import { getImage } from "../../../helpers/imageHelper";
import SimformButton from "../../primary/button/simform-button.vue";

export default {
  components: { SimformSection, SimformButton },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    title() {
      return this.data.title;
    },
    items() {
      return this.data.items.map((item) => {
        return {
          title: item.title,
          text: item.text,
          icon: getImage(item.icon),
        };
      });
    },
    image() {
      return getImage(this.data.image);
    },
    buttonText() {
      return this.data.buttonText;
    },
  },
};
</script>
<style scoped>
.benefits-section-container {
  width: 100%;
  margin-top: 20px;
  position: relative;
  padding: 20px 0px;
}

.benefits-section-bg {
  width: calc(100% - 40px);
  height: 100%;
  left: 20px;
  top: 0px;
  position: absolute;
  opacity: 0.3;
  background: url("~/assets/images/benefitssec-bg.png");
}

.benefits-section {
  box-shadow: rgb(0 0 0 / 6%) 0px 1px 18px 0px,
    rgb(0 0 0 / 10%) 0px 3px 5px -1px;
  border: 1px solid rgb(227, 195, 105);
  background-color: rgb(254, 220, 122);
  width: 100%;
  display: flex;
  padding: 40px 60px 37px 35px;
  z-index: 1;
  position: inherit;
  align-items: flex-start;
}
</style>
