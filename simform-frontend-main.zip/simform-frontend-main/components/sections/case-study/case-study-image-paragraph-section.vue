<template>
  <simform-section>
    <div class="max-w-6xl mx-auto py-10">
      <div class="mb-10">
        <h3
          class="leading-[1.3] text-5xl text-secondary-800 font-semibold"
          v-html="title"
        ></h3>
      </div>
      <div
        v-for="item in items"
        :key="item.id"
        class="group grid grid-cols-2 gap-16 mb-10"
      >
        <div class="flex flex-col justify-center">
          <h2
            class="pb-10 font-semibold text-gray-800 leading-snug"
            :class="[item.hasSmallTitle ? 'text-[32px]' : 'text-[44px]']"
            v-if="item.title"
          >
            {{ item.title }}
          </h2>
          <div v-html="item.description" class="text-2xl font-light"></div>
        </div>
        <div
          class="group-odd:order-first group-even:order-last flex items-center"
        >
          <div>
            <img :src="item.image.src" :alt="item.image.alt" />
            <div class="text-center text-secondary-400 pt-10">
              {{ item.image.caption }}
            </div>
          </div>
        </div>
      </div>
    </div>
  </simform-section>
</template>
<script>
import SimformSection from "@/components/sections/basic/simform-section";
import { getImage } from "../../../helpers/imageHelper";

export default {
  components: { SimformSection },
  props: {
    content: {
      type: Object,
      required: true,
    },
  },
  computed: {
    title() {
      return this.content.title;
    },
    items() {
      return this.content.items.map((item) => {
        return {
          title: item.title,
          description: item.description,
          image: getImage(item.image),
          hasSmallTitle: item.hasSmallTitle,
        };
      });
    },
  },
};
</script>
