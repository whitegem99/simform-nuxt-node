<template>
  <section class="max-w-6xl mx-auto px-10 py-20">
    <div class="grid grid-cols-2 gap-10">
      <div class="flex flex-col justify-center pr-10">
        <h1 class="text-6xl font-semibold text-gray-800 pt-11 mb-6 relative">
          {{ title }}
        </h1>
        <p class="text-gray-600 text-[28px] font-semibold">
          {{ description }}
        </p>
      </div>
      <div class="flex justify-center">
        <div class="banner-img">
          <div class="banner-bg" :class="colorClass"></div>
          <div class="image">
            <img :src="img.src" :alt="img.alt" />
          </div>
        </div>
      </div>
    </div>
  </section>
</template>
<script>

import { getImage } from "../../../helpers/imageHelper";

export default {
  props: {
    content: {
      type: Object,
      required: true,
    },
  },
  computed: {
    title() {
      return this.content.title;
    },
    description() {
      return this.content.description;
    },
    color() {
      return this.content.color;
    },
    img() {
      return getImage(this.content.image);
    },
    colorClass() {
      let colorClass = "";

      if (this.color === "green") {
        colorClass = "green";
      } else if (this.color === "gray") {
        colorClass = "gray";
      } else if (this.color === "red") {
        colorClass = "red";
      } else if (this.color === "dark green") {
        colorClass = "dark-green";
      } else if (this.color === "lime") {
        colorClass = "lime";
      } else if (this.color === "dark gray") {
        colorClass = "dark-gray";
      }

      return colorClass;
    },
  },
};
</script>
<style scoped>
h1::before {
  content: "";
  width: 55px;
  height: 4px;
  background: rgb(61, 61, 61);
  position: absolute;
  top: 0px;
  left: 0px;
}

.banner-img {
  width: calc(100% - 30px);
  position: relative;
  margin-right: 30px;
  margin-bottom: 20px;
}

.banner-bg {
  position: absolute;
  width: 100%;
  height: 100%;
  right: -30px;
  top: 30px;
}

.green {
  background-color: rgb(74, 249, 167);
}

.gray {
  background-color: rgb(217, 217, 217);
}

.dark-green {
  background-color: rgb(28, 64, 0);
}

.lime {
  background-color: rgb(140, 201, 91);;
}

.dark-gray {
  background-color: rgb(88, 87, 100);
}

.image {
  position: relative;
  overflow: hidden;
  max-width: 570px;
  margin: 0 auto;
}
</style>
