<template>
  <simform-section white>
    <div class="max-w-6xl mx-auto p-10">
      <div class="grid grid-cols-2 gap-16 relative">
        <div class="flex gap-5">
          <div class="uppercase font-bold">{{ shortText }}</div>
          <div class="flex-1 mt-2">
            <div class="pr-20 leading-snug text-5xl font-semibold down-bar-block top-border py-16">
                {{ title }}
            </div>
            <div v-if="withBottomBarForTitle" class="top-border w-40"></div>
          </div>
        </div>
        <div class="top-border mt-2">
          <div class="text-2xl font-light py-16" v-html="paragraph"></div>
        </div>
      </div>
      <div class="my-10">
        <img :src="image.src" alt="image.alt" />
      </div>
    </div>
  </simform-section>
</template>
<script>
import SimformSection from "@/components/sections/basic/simform-section";
import { getImage } from "../../../helpers/imageHelper";

export default {
  components: { SimformSection },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    shortText() {
      return this.data.shortText;
    },
    title() {
      return this.data.title;
    },
    paragraph() {
      return this.data.paragraph;
    },
    withBottomBarForTitle () {
      return this.data.withBottomBarForTitle;
    },
    image() {
      return getImage(this.data.image);
    },
  },
};
</script>
<style>
.top-border {
  border-top: 3px solid rgb(61, 61, 61);
}
</style>
