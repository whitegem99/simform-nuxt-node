<template>
  <simform-section v-if="caseStudies.length > 0">
    <div class="max-w-7xl mx-auto px-10">
      <div class="leading-snug text-5xl font-semibold py-16">
        Related Case Studies
      </div>
      <div class="flex gap-24">
        <case-study-mini
          v-for="caseStudy in caseStudies"
          :key="caseStudy.id"
          :case-study="caseStudy"
        />
      </div>
    </div>
  </simform-section>
</template>
<script>
import SimformSection from "@/components/sections/basic/simform-section";
import CaseStudyMini from "../../feature-components/case-study/case-study-mini.vue";
export default {
  components: { SimformSection, CaseStudyMini },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    title() {
      return this.data.title;
    },
    caseStudies() {
      return this.data.case_studies.slice(0, 2).map((c) => ({
        title: c.miniTitle,
        color: c.color,
        description: c.description,
        slug: c.slug,
      }));
    },
  },
};
</script>
<style lang=""></style>
