<template>
  <simform-section gradient>
    <div class="max-w-6xl mx-auto px-10">
      <h2 class="text-5xl font-bold pb-10 text-gray-800">{{ title }}</h2>
      <div class="grid grid-cols-2 gap-14">
        <div>
          <div class="my-3 text-2xl font-light" v-html="paragraph"></div>
          <div class="my-10">
            <color-box-item v-for="item in items" :key="item.id" :item="item" />
          </div>
        </div>
        <div>
          <img :src="image.src" alt="image.alt" />
        </div>
      </div>
    </div>
  </simform-section>
</template>
<script>
import SimformSection from "@/components/sections/basic/simform-section";
import { getImage } from "../../../helpers/imageHelper";
import ColorBoxItem from "../../feature-components/development-approach/color-box-item.vue";

export default {
  components: { SimformSection, ColorBoxItem },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    title() {
      return this.data.title;
    },
    paragraph() {
      return this.data.paragraph;
    },
    image() {
      return getImage(this.data.image);
    },
    items() {
      return this.data.items.map((item) => {
        return {
          title: item.title,
          text: item.text,
          color: item.color,
          paragraph: item.paragraph,
          icon: item.icon,
        };
      });
    },
  },
};
</script>
