<template>
  <div>
    <div class="img-blk">
      <img :src="image.src" :alt="image.alt" />
    </div>
    <div class="mt-20">
      <div class="text-3xl font-bold mb-5">{{ title }}</div>
      <div class="text-[22px] font-light">{{ description }}</div>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    image() {
      return this.data.image;
    },
    title() {
      return this.data.title;
    },
    description() {
      return this.data.description;
    },
  },
};
</script>
<style scoped>
.img-blk {
  margin: 20px;
  position: relative;
  background: rgb(255, 220, 249);
  width: 254px;
  height: 254px;
  display: flex;
  -webkit-box-align: center;
  align-items: center;
  -webkit-box-pack: center;
  justify-content: center;
}

.img-blk::before {
  content: "";
  position: absolute;
  width: 100%;
  height: 100%;
  top: -20px;
  right: -20px;
  background: rgb(255, 220, 249);
  opacity: 0.3;
}

.img-blk::after {
  content: "";
  position: absolute;
  width: 100%;
  height: 100%;
  bottom: -20px;
  left: -20px;
  background: rgb(255, 220, 249);
  opacity: 0.2;
}

.img-blk img {
  max-width: 100%;
  height: auto;
  z-index: 10;
}
</style>
