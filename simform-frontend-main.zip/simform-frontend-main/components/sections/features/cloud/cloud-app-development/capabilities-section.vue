<template>
  <simform-section white extra-padding>
    <div class="max-w-6xl mx-auto">
      <title-underline text="Simform's <u>capabilities</u>" single-line />
      <p class="my-10 text-xl text-center">
        Unlock the
        <highlighted-text
          text="development velocity and improve application security"
        />
        with Simform’s cloud-native development services! We enable you to adopt
        state-of-the-art technologies like DevOps, microservices, and
        containerization into your workflow to transform your development model.
      </p>

      <!-- <div>
        <benefits-of-working-item
          title="Custom software for your evolving business needs"
          :image="
            require('assets/images/services/benefits_of_working/ill-tailored@2x.webp')
          "
          :enable-connector="false"
        >
          <div class="text-xl">
            <p class="mb-5">
              Reimagine and rebuild your applications by migrating to the
              <highlighted-text text="accelerated and efficient cloud-native architecture."/>
            </p>
            <p class="mb-5">
              We work with you to prepare an actionable migration strategy and implement it based on your specific
              business needs.
            </p>
            <p>
              Our expert teams enable you to move to modern infrastructure, refactor your applications, and bring an
              agile approach to your development processes.
            </p>
          </div>
        </benefits-of-working-item>
        <benefits-of-working-item
          paragraph="From an in-depth analysis of your business to <strong>developing custom software</strong> and from user training to maintaining applications, we advise on what technologies to invest in, what technical architecture to choose, as well as consult on how to achieve the required level of data protection."
          :image="
            require('assets/images/services/benefits_of_working/ill-dataprotection@2x.webp')
          "
          reverse-layout
          :enable-connector="false"
        />
        <benefits-of-working-item
          title="Understanding your business goals"
          paragraph="Let’s discuss your short and <strong>long-term vision</strong> in-depth. When we know your goals and understand existing software, we are able to ensure the success of the project."
          :image="
            require('assets/images/services/benefits_of_working/ill-businessgoal@2x.webp')
          "
          :enable-connector="false"
        />
        <benefits-of-working-item
          title="Well-architectured solution for scale"
          paragraph="We take a <strong>pragmatic approach</strong> to software architecture and design. Choosing important areas worth investing upfront, and prioritize others afterward. We also provide data protection consultation."
          :image="
            require('assets/images/services/benefits_of_working/ill-architectured@2x.webp')
          "
          reverse-layout
          :enable-connector="false"
        />
        <benefits-of-working-item
          title="Goal driven user experience (UX) design"
          paragraph="Good software design helps <strong>drive user satisfaction</strong>. We perform UX research to align overall experience with your goals and users’ needs and let you make well-informed decisions."
          :image="
            require('assets/images/services/benefits_of_working/ill-businessgoal@2x.webp')
          "
          :enable-connector="false"
        />
      </div> -->
    </div>
  </simform-section>
</template>
<script>
import SimformSection from "@/components/sections/basic/simform-section";
// import BenefitsOfWorkingItem from "@/components/feature-components/benefits-of-working/benefits-of-working-item";
import TitleUnderline from "@/components/primary/title/title-underline.vue";
import HighlightedText from "@/components/primary/highlight-text/highlight-text";

export default {
  components: {
    HighlightedText,
    TitleUnderline,
    // BenefitsOfWorkingItem,
    SimformSection,
  },
};
</script>
<style lang=""></style>
