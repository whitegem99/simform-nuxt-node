<template>
  <from-experts-section :white="false">
    <template v-slot:main>
      <from-experts />
    </template>
  </from-experts-section>
</template>
<script>
import FromExpertsSection from "../../../common/from-experts-section.vue";
import FromExperts from "./from-experts.vue";

export default {
  components: { FromExpertsSection, FromExperts },
};
</script>
