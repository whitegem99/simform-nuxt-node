<template>
  <simform-section white extra-padding>
    <div class="max-w-6xl mx-auto">
      <title-underline text="Simform's <u>capabilities</u>" single-line />
      <p class="my-10 text-xl text-center">
        Our customized DevOps consulting services enable you to
        <highlighted-text text="maximize efficiency" /> and
        <highlighted-text text="optimize your business value" />. Our expert
        solutions help you automate tasks, collaborate better, and ship product
        updates rapidly.
      </p>
    </div>
  </simform-section>
</template>
<script>
import SimformSection from "@/components/sections/basic/simform-section";
import TitleUnderline from "@/components/primary/title/title-underline.vue";
import HighlightedText from "@/components/primary/highlight-text/highlight-text";

export default {
  components: {
    HighlightedText,
    TitleUnderline,
    SimformSection,
  },
};
</script>
<style lang=""></style>
