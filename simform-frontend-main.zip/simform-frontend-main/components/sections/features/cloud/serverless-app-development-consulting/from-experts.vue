<template>
  <div class="grid grid-cols-4 gap-8">
    <div class="col-span-1">
      <figure class="drop-shadow-md">
        <a href="#" target="_blank">
          <img src="~/assets/images/from-experts/FIH-case-study.png" />
        </a>
      </figure>
    </div>
    <div class="col-span-1">
      <figure class="drop-shadow-md">
        <a href="#" target="_blank">
          <img src="~/assets/images/from-experts/Foodtruck-spaces.png" />
        </a>
      </figure>
    </div>
    <div class="col-span-2">
      <figure class="drop-shadow-md">
        <a href="#" target="_blank">
          <img src="~/assets/images/from-experts/Building-high-performing-web-apps-eBook.png" />
        </a>
      </figure>
    </div>
    <div class="col-span-2">
      <figure class="drop-shadow-md">
        <a href="#" target="_blank">
          <img src="~/assets/images/from-experts/DevOps-consulting-services-1.png" />
        </a>
      </figure>
    </div>
    <div class="col-span-1">
      <figure class="drop-shadow-md">
        <a href="#" target="_blank">
          <img src="~/assets/images/from-experts/eCommerce-strategies.png" />
        </a>
      </figure>
    </div>
    <div class="col-span-1">
      <figure class="drop-shadow-md">
        <a href="#" target="_blank">
          <img src="~/assets/images/from-experts/QA-Managers-guide.png" />
        </a>
      </figure>
    </div>
  </div>
</template>
<script>
export default {};
</script>
