<template>
  <simform-section>
    <div class="max-w-4xl mx-auto">
      <div class="my-10">
        <title-underline
          text="Serverless is hard. <u>Simform</u> makes it simple!"
          fontSize="4xl"
          single-line
        />
      </div>
      <div>
        <h5 class="font-light text-2xl mb-10 text-center">
          Delivering the power of Simform’s Serverless app development
          capabilities and experience to help customers
          <highlight-text text="scale their cloud infrastructure" />. Improve
          your application agility by extending your team with Serverless
          developers.
        </h5>
      </div>
      <div>
        <vue-plyr>
          <div class="plyr__video-embed">
            <iframe
              :src="videoUrl"
              allowfullscreen
              allowtransparency
              allow="autoplay"
            ></iframe>
          </div>
        </vue-plyr>
      </div>
    </div>
  </simform-section>
</template>
<script>
import TitleUnderline from "../../../../primary/title/title-underline.vue";
import HighlightText from "../../../../primary/highlight-text/highlight-text.vue";
import SimformSection from "@/components/sections/basic/simform-section";

export default {
  components: {
    SimformSection,
    TitleUnderline,
    HighlightText,
  },
  data() {
    return {
      videoUrl: "https://www.youtube.com/watch?v=54BSxnpeSls",
    };
  },
};
</script>
