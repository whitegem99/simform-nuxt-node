<template>
  <simform-section white>
    <div class="max-w-6xl mx-auto">
      <image-paragraph
        title="iOS App Development Services"
        :image="
          require('assets/images/services/custom_software_types/offerings-enterprise-application@2x.webp')
        "
        :bullet-points="enterpriseSoftware"
      >
        <template v-slot:paragraph>
          <p>
            We customize enterprise-grade software to help businesses like you
            thrive in their business processes. This custom-designed software is
            targeted to your specific set of users and serves their unique
            requirements. Our in-house development teams customize, modernize
            and manage applications that accelerate your workflows.
          </p>
          <p>
            products are easy-to-operate solutions that optimize and automate
            your business processes and give 100% satisfaction to the users. Our
            enterprise-based custom software application development services
            include numerous apps.
          </p>
        </template>
      </image-paragraph>

      <image-paragraph
        title="Industrial software"
        :image="
          require('assets/images/services/custom_software_types/offerings-industrial-software@2x.webp')
        "
        :bullet-points="industrialSoftware"
        reversed-layout
      >
        <template v-slot:paragraph>
          <p>
            We build software products with unique functionalities to serve the
            commercial market, such as managing inventories, operational
            management, financial management, etc. These products have advanced
            functionalities different from existing ready-made solutions.
          </p>
          <p>
            Discover how our set of software but not limited to can help you
            lead the competition, automate your business processes and improve
            productivity.
          </p>
        </template>
      </image-paragraph>

      <image-paragraph
        title="Specialized services software solutions  "
        :image="
          require('assets/images/services/custom_software_types/offerings-specialized-services@2x.webp')
        "
        :bullet-points="enterpriseSoftware"
      >
        <template v-slot:paragraph>
          <p>
            We develop this set of software specifically to serve
            business-specific functions that your business needs. In addition,
            we strive to offer you exclusive solutions that are difficult to
            meet by the market's existing software solutions.
          </p>
          <p>
            Our customized solutions come with additional features aligned with
            your business's core services and are built using cost-effective
            techniques that suit your budget.
          </p>
        </template>
      </image-paragraph>

      <image-paragraph
        title="Customer-centric apps"
        :image="
          require('assets/images/services/custom_software_types/offerings-customer-centric@2x.webp')
        "
        :bullet-points="enterpriseSoftware"
        reversed-layout
      >
        <template v-slot:paragraph>
          <p>
            We specialize in creating apps that stand out in providing
            personalized and interactive user experiences and represent a strong
            business identity among your target market. Embrace the flexibility
            of B2B and B2C customer applications that offer a wow-factor to your
            users with minimalistic design and quick responding features.
          </p>
          <p>
            In addition, you will get access to post-sales guidance, customer
            support, and streamlined services for technical support.
          </p>
        </template>
      </image-paragraph>
    </div>
  </simform-section>
</template>
<script>
import TitleUnderline from "../../../../primary/title/title-underline.vue";
import SimformSection from "@/components/sections/basic/simform-section";
import ImageParagraph from "@/components/feature-components/image-paragraph/image-paragraph";

export default {
  components: {ImageParagraph, SimformSection, TitleUnderline},
  data() {
    return {
      enterpriseSoftware: [
        "Enterprise Process Management (ERPs) tools",
        "Customer Relationship Management Software (CRMs)",
        "Human Resources Management Software(HRMS)",
        "Content Management Systems (CMS)",
        "Asset Management Software",
      ],
      industrialSoftware: [
        "Financial software",
        "Law firm KPI tools",
        "Legal department dashboards",
        "Business intelligence systems",
        "Logistics industry analytics tools",
        "Market research software",
      ],
      specialisedSoftware: [
        "Accounting software",
        "Payroll management",
        "Asset management software",
        "Database software",
        "Pharmaceutical inventory and billing systems",
      ],
      customerCentricApps: [
        "Social media apps",
        "eCommerce apps",
        "Mobile net banking apps",
        "Patient and healthcare apps",
      ],
    };
  },
};
</script>
<style lang=""></style>
