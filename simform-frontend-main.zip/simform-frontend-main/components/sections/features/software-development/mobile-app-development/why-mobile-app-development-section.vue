<template>
  <simform-section extra-padding>
    <title-underline
      text="Why Simform for <u>Mobile App Development?</u>"
      fontSize="4xl"
    />
    <div class="grid grid-cols-2 gap-5 max-w-7xl mx-auto my-10">
      <div class="text-xl">
        <p>
          Simform’s mobile app development services allow organizations to build innovative and user-friendly
          applications. Our team of expert software engineers and developers craft scalable and reliable mobile app
          solutions to improve your business capabilities. We have powered several B2B applications by integrating
          modern technologies like Artificial Intelligence, Machine Learning, AR/VR, and others.
        </p>
        <p class="mt-5">
          We ensure client success by creating robust and high-quality software products in sync with their
          organizational goals. Our mobile app services include tech stack consultations, application development,
          testing, deployments, and after-sales support.
        </p>
        <p class="mt-5">
          Simform also offers modernization of legacy applications with other services like system audits and
          enhancements to existing apps.
        </p>
      </div>
      <simform-list :list="list" with-check-mark />
    </div>
  </simform-section>
</template>

<script>
import SimformSection from "@/components/sections/basic/simform-section";
import TitleUnderline from "@/components/primary/title/title-underline.vue";
import SimformList from "@/components/feature-components/simform-list/simform-list";

export default {
  name: "why-mobile-app-development-section",
  components: {SimformList, TitleUnderline, SimformSection},
  data() {
    return {
      list: [
        "Complete product ownership",
        "Software quality guaranteed",
        "Flexibility to use your custom software",
        "Advanced tech stacks",
        "Transparent communication and reporting",
        "Guaranteed after-sales support",
        "Consistent delivery with the agile approach",
        "Proven track record in building successful MVP",
      ],
    };
  },
}
</script>

<style scoped>

</style>
