<template>
  <simform-section white>
    <div class="max-w-8xl mx-auto">
      <avatars-title title="How we develop <u>Engaging App Experiences</u>" />
      <activity-flow/>
    </div>
  </simform-section>
</template>
<script>
import TitleUnderline from "../../../../primary/title/title-underline.vue";
import SimformSection from "@/components/sections/basic/simform-section";
import AvatarsTitle from "@/components/feature-components/avatars-title/avatars-title.vue";
import ActivityFlow from "@/components/feature-components/activity-flow/activity-flow";

export default {
  components: {ActivityFlow, AvatarsTitle, SimformSection, TitleUnderline}, props: {
    title: {type: String, default: "How We Develop Custom<br> Software <u> Using Agile</u>"},
    singleLine: {type: Boolean, default: true}
  }
};
</script>
<style>
.user-image img {
  width: 7rem;
  height: 7rem;
}
</style>
