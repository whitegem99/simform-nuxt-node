<template>
  <simform-section white>
    <div class="max-w-8xl mx-auto">
      <avatars-title title="Our <u>API development process</u>" single-line/>
      <activity-flow/>
    </div>
  </simform-section>
</template>
<script>
import TitleUnderline from "../../../../primary/title/title-underline.vue";
import SimformSection from "@/components/sections/basic/simform-section";
import AvatarsTitle from "@/components/feature-components/avatars-title/avatars-title";
import ActivityFlow from "@/components/feature-components/activity-flow/activity-flow";

export default {
  components: {ActivityFlow, AvatarsTitle, SimformSection, TitleUnderline},
};
</script>
<style>
.user-image img {
  width: 7rem;
  height: 7rem;
}
</style>
