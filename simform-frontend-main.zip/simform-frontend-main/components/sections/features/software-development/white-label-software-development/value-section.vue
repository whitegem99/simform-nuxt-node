<template>
  <simform-section white>
    <div class="max-w-6xl mx-auto">
      <title-underline
        fontSize="4xl"
        text="Preserve and increase brand value with our <u>proven quality and expertise</u>"
      />

      <!-- <div class="my-10">
        <benefits-of-working-item
          :image="
            require('assets/images/services/benefits_of_working/ill-tailored@2x.webp')
          "
          :enable-connector="false"
        >
          <p class="text-lg mb-5">
            <highlight-text bold text="eCommerce:"/>
            eCommerce white label
            solution that packs in state of the art features to help cater a
            user experience that maximizes sales. Our seasoned developers use
            the most advanced technologies and sound development strategies to
            help you capitalize on the profitable eCommerce ecosystem.
          </p>
          <p class="text-lg">
            <highlight-text bold text="Transportation:"/>
            From operation and
            management of fleet & logistics to white label solutions for
            travelers, transportation software is becoming the key to
            profit-making businesses. With the experience of diverse digital
            transportation solutions under our belt, we help you cash in on the
            potential with our white label product.
          </p>
        </benefits-of-working-item>
        <benefits-of-working-item
          :image="
            require('assets/images/services/benefits_of_working/ill-dataprotection@2x.webp')
          "
          reverse-layout
          :enable-connector="false"
        >
          <p class="text-lg mb-5">
            <highlight-text bold text="eCommerce:"/>
            eCommerce white label
            solution that packs in state of the art features to help cater a
            user experience that maximizes sales. Our seasoned developers use
            the most advanced technologies and sound development strategies to
            help you capitalize on the profitable eCommerce ecosystem.
          </p>
          <p class="text-lg">
            <highlight-text bold text="Transportation:"/>
            From operation and
            management of fleet & logistics to white label solutions for
            travelers, transportation software is becoming the key to
            profit-making businesses. With the experience of diverse digital
            transportation solutions under our belt, we help you cash in on the
            potential with our white label product.
          </p>
        </benefits-of-working-item>
        <benefits-of-working-item
          :image="
            require('assets/images/services/benefits_of_working/ill-businessgoal@2x.webp')
          "
          :enable-connector="false"
        >
          <p class="text-lg mb-5">
            <highlight-text bold text="eCommerce:"/>
            eCommerce white label
            solution that packs in state of the art features to help cater a
            user experience that maximizes sales. Our seasoned developers use
            the most advanced technologies and sound development strategies to
            help you capitalize on the profitable eCommerce ecosystem.
          </p>
          <p class="text-lg">
            <highlight-text bold text="Transportation:"/>
            From operation and
            management of fleet & logistics to white label solutions for
            travelers, transportation software is becoming the key to
            profit-making businesses. With the experience of diverse digital
            transportation solutions under our belt, we help you cash in on the
            potential with our white label product.
          </p>
        </benefits-of-working-item>
        <benefits-of-working-item
          :image="
            require('assets/images/services/benefits_of_working/ill-architectured@2x.webp')
          "
          reverse-layout
          :enable-connector="false"
        >
          <p class="text-lg mb-5">
            <highlight-text bold text="eCommerce:"/>
            eCommerce white label
            solution that packs in state of the art features to help cater a
            user experience that maximizes sales. Our seasoned developers use
            the most advanced technologies and sound development strategies to
            help you capitalize on the profitable eCommerce ecosystem.
          </p>
          <p class="text-lg">
            <highlight-text bold text="Transportation:"/>
            From operation and
            management of fleet & logistics to white label solutions for
            travelers, transportation software is becoming the key to
            profit-making businesses. With the experience of diverse digital
            transportation solutions under our belt, we help you cash in on the
            potential with our white label product.
          </p>
        </benefits-of-working-item>
        <benefits-of-working-item
          :image="
            require('assets/images/services/benefits_of_working/ill-businessgoal@2x.webp')
          "
          :enable-connector="false"
        >
          <p class="text-lg mb-5">
            <highlight-text bold text="eCommerce:"/>
            eCommerce white label
            solution that packs in state of the art features to help cater a
            user experience that maximizes sales. Our seasoned developers use
            the most advanced technologies and sound development strategies to
            help you capitalize on the profitable eCommerce ecosystem.
          </p>
          <p class="text-lg">
            <highlight-text bold text="Transportation:"/>
            From operation and
            management of fleet & logistics to white label solutions for
            travelers, transportation software is becoming the key to
            profit-making businesses. With the experience of diverse digital
            transportation solutions under our belt, we help you cash in on the
            potential with our white label product.
          </p>
        </benefits-of-working-item>
      </div> -->
    </div>
  </simform-section>
</template>
<script>
import TitleUnderline from "../../../../primary/title/title-underline.vue";
// import BenefitsOfWorkingItem from "../../../../feature-components/benefits-of-working/benefits-of-working-item.vue";
import HighlightText from "../../../../primary/highlight-text/highlight-text.vue";
import SimformSection from "@/components/sections/basic/simform-section";

export default {
  components: {
    SimformSection,
    TitleUnderline,
    // BenefitsOfWorkingItem,
    HighlightText,
  },
};
</script>
