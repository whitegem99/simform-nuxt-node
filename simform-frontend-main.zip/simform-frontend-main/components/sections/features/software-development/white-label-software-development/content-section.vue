<template>
  <simform-section white>
    <div
      class="max-w-5xl mx-auto product-banner-gradient text-center px-10 py-8"
    >
      <up-down-bar-title text="Encash your business expertise and reputations with white label software" />
      <p class="text-xl text-left mb-5">
        You’ve gained invaluable business acumen over the years and built up a
        <highlight-text text="solid reputation for your brand"/>
        in the
        process. So much so, that if you were to roll out a software solution to
        augment your business offerings, clients will scramble to associate with
        it.
      </p>
      <p class="text-xl text-left mb-5">
        However, that’d require some quality technological competence,
        <highlight-text
          text="a
        reliable and scalable team, experienced managers"
        />
        , and so on. Not to mention, the high cost of setting up a development
        infrastructure including the cost of hiring and other managerial costs.
      </p>
      <p class="text-xl text-left mb-5">
        As a
        <highlight-text
          text="white label software development partner, Simform"
        />
        brings you all the necessary tech expertise while saving you a lot of
        resources and time. With our development capabilities and your business
        reputation, the white label software is set for success already.
      </p>
      <p class="text-xl text-left mb-5">
        Wondering how all of this would work for you? Well, there are two
        revenue models at your disposal for the white label software solution.
      </p>
      <p class="text-xl text-left mb-5">
        <highlight-text text="Offer subscriptions:"/>
        Here the partners will
        have access to both the backend and frontend share via the cloud through
        a single infrastructure. The different pricing levels will allow them to
        pick functionalities and add branding, as applicable.
      </p>
      <p class="text-xl text-left mb-5">
        <highlight-text text="Sell licenses:"/>
        In this case, you share only
        the technological expertise by providing access to just the application
        backend. The partner can develop the desired frontend on their own and
        you’ll have one less thing to manage. The arrangement offers higher
        flexibility for partners and fewer liabilities for you.
      </p>
    </div>
  </simform-section>
</template>
<script>
import TitleUnderline from "../../../../primary/title/title-underline.vue";
import HighlightText from "../../../../primary/highlight-text/highlight-text.vue";
import SimformSection from "@/components/sections/basic/simform-section";
import UpDownBarTitle from "../../../../feature-components/up-down-bar-title/up-down-bar-title.vue";

export default {
  components: { SimformSection, TitleUnderline, HighlightText, UpDownBarTitle },
};
</script>
<style scoped>
.gray-bar {
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  width: 124px;
  height: 2px;
  background: #d8d8d8;
}

.text {
  position: relative;
  padding: 14px 0 16px;
  text-align: center;
  margin: 70px 0 50px;
}

.product-banner-gradient {
  background-color: #fff;
  background-image: linear-gradient(
    236deg,
    rgba(255, 255, 255, 0.3),
    rgba(216, 251, 248, 0.3)
  );
}
</style>
