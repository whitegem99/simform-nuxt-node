<template>
  <simform-section>
    <div class="max-w-2xl mx-auto">
      <title-underline
        text="Not your white label provider, but your <u>white label partner</u>"
        fontSize="4xl"
        singleLine
        textAlign="center"
      />
      <p class="text-xl my-10">
        Be it the assistance to keep up with the demands or the tech acumen to
        build a futuristic digital product from scratch, our
        <highlight-text
          text="seasoned experts,
      efficient team, and reliable policies"
        />
        are the perfect recipe for your white label solution.
      </p>
    </div>
    <div class="max-w-4xl mx-auto">
      <vue-plyr>
        <div class="plyr__video-embed">
          <iframe
            src="https://www.youtube.com/watch?v=54BSxnpeSls"
            allowfullscreen
            allowtransparency
            allow="autoplay"
          ></iframe>
        </div>
      </vue-plyr>
    </div>
  </simform-section>
</template>
<script>
import TitleUnderline from "../../../../primary/title/title-underline.vue";
import HighlightText from "../../../../primary/highlight-text/highlight-text.vue";
import SimformSection from "@/components/sections/basic/simform-section";
export default {
  components: {
    SimformSection,
    TitleUnderline,
    HighlightText,
  },
};
</script>
