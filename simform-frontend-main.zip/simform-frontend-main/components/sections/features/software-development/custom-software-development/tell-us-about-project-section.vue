<template>
  <simform-section>
    <div class="max-w-6xl mx-auto">
      <div class="pt-15">
        <title-underline :data="{ text: data.title }"/>
        <div class="grid grid-cols-2 mt-6">
          <div class="p-5">
            <div class="bg-white shadow-md p-6">
              <h5 class="text-secondary-400 text-lg w-full text-center font-semibold tracking-wide">
                Guaranteed response within one business day.
              </h5>
              <form action="" class="flex flex-col gap-5 p-5">
                <input
                  type="text"
                  name="name"
                  placeholder="Name"
                  id=""
                  class="rounded-md border border-secondary-300 bg-gray-50 placeholder:text-gray-400 p-4 ring-0 focus:ring-0 focus:border-primary-500 outline-none transition-all duration-300 font-sans font-light ring-transparent"
                />
                <input
                  type="email"
                  name="email"
                  placeholder="Email"
                  id=""
                  class="rounded-md border border-secondary-300 bg-gray-50 placeholder:text-gray-400 p-4 ring-0 focus:ring-0 focus:border-primary-500 outline-none transition-all duration-300 font-sans font-light ring-transparent"
                />
                <input
                  type="tel"
                  name="phone"
                  placeholder="Phone Number"
                  id=""
                  class="rounded-md border border-secondary-300 bg-gray-50 placeholder:text-gray-400 p-4 ring-0 focus:ring-0 focus:border-primary-500 outline-none transition-all duration-300 font-sans font-light ring-transparent"
                />
                <textarea
                  name="message"
                  placeholder="Message"
                  id=""
                  cols="30"
                  rows="10"
                  class="rounded-md border border-secondary-300 bg-gray-50 placeholder:text-gray-400 p-4 ring-0 focus:ring-0 focus:border-primary-500 outline-none focus:outline-none transition-all duration-300 font-sans font-light ring-transparent"
                ></textarea>
                <Button bold url="/contact">
                  <span
                    class="flex justify-center items-center tracking-wide font-semibold mt-[4px]"
                  >LET'S GET STARTED</span
                  >
                </Button>
              </form>
            </div>
          </div>
          <div class="flex flex-col gap-5 justify-center pl-10">
            <div class="text-3xl font-merriweather italic" v-html="data.subSectionTitle"></div>
            <div class="text-xl pl-8">
              <ol class="list-decimal	list-outside text-secondary-500 font-medium">
                <li v-for="item in data.detailsList">
                  <div v-html="item.text" class="text-[24px]"></div>
                </li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div>
  </simform-section>
</template>
<script>
import TitleUnderline from "../../../../primary/title/title-underline.vue";
import Button from "../../../../primary/button/simform-button.vue";
import SimformSection from "@/components/sections/basic/simform-section";

export default {
  components: {SimformSection, TitleUnderline, Button},
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
};
</script>
<style scoped>
section {
  background-image: linear-gradient(rgba(252, 253, 255, 0), rgb(248, 249, 255));
}

li {
  margin-top: 2rem;
}
</style>
