<template>
  <simform-section>
    <div class="mt-10 max-w-6xl mx-auto">
      <title-underline
        text="Why Simform for <u>Custom Software Development Services?</u>"
        fontSize="4xl"
      />

      <div class="grid grid-col grid-cols-1 lg:grid-cols-2 gap-10 mt-10 px-10">
        <div class="text-xl">
          <p>
            We are a custom software development company delivering quality
            customized software solutions for the web and mobile. Our in-house
            development teams' design, develop, deploy and maintain software and
            aim at a predefined set of requirements.
          </p>
          <p class="mt-5">
            Our software development cycle passes through several steps, including
            requirements gathering, ideation, architecting systems that support
            iterative releases, constructing clean and testable code, as well as
            quality testing process.
          </p>
          <p class="mt-5">
            What differentiates our custom software development services from
            others is our scalable, robust software products built using quality
            engineering, approaches used to modernize apps, and adherence to agile
            and CI/CD principles throughout the product development life cycle.
          </p>
        </div>
        <div class="ml-20 lg:ml-0">
          <simform-list with-check-mark :list="list" />
        </div>
      </div>
    </div>
  </simform-section>
</template>
<script>
import TitleUnderline from "../../../../primary/title/title-underline.vue";
import CheckMark from "../../../../primary/checkmark/check-mark.vue";
import SimformSection from "@/components/sections/basic/simform-section";
import SimformList from "@/components/feature-components/simform-list/simform-list";

export default {
  components: {SimformList, SimformSection, TitleUnderline, CheckMark}, data() {
    return {
      list: [
        "Complete product ownership",
        "Software quality guaranteed",
        "Flexibility to use your custom software",
        "Advanced tech stacks",
        "Transparent communication and reporting",
        "Guaranteed after-sales support",
        "Consistent delivery with the agile approach",
        "Proven track record in building successful MVP",
      ]
    }
  }
};
</script>
<style>
.checkmark-list > li {
  margin-top: 15px;
  margin-bottom: 15px;
}
</style>
