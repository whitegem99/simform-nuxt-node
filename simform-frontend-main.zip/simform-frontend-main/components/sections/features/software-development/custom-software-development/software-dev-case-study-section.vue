<template>
  <simform-section white>
    <div class="w-full mx-auto">
      <title-underline :text="title" :single-line="singleLine" />
      <div>
        <div class="relative px-32 top-[250px] z-50">
          <button
            class="slick-arrow slick-prev inline-block bg-white shadow-md p-6 rounded-full"
            @click="previous"
          >
            <svg width="32" height="25" viewBox="0 0 32 25">
              <path
                fill="#3D3D3D"
                fill-rule="evenodd"
                d="M0 12a1.22 1.22 0 0 1 0-.13v-.11a1.25 1.25 0 0 1 0-.13l.05-.1.07-.12.07-.09.08-.1L11 .39a1.3 1.3 0 0 1 1.82 0 1.25 1.25 0 0 1 0 1.79l-8.43 8.56h26.32a1.3 1.3 0 0 1 0 2.59H4.29l8.55 8.55a1.25 1.25 0 0 1 0 1.79 1.3 1.3 0 0 1-1.82 0L.37 13l-.08-.09-.08-.09-.06-.11-.06-.11a1.18 1.18 0 0 1 0-.12 1.22 1.22 0 0 1 0-.12 1.16 1.16 0 0 1 0-.12 1.2 1.2 0 0 1 0-.13L0 12z"
              ></path>
            </svg>
          </button>
          <button
            class="slick-arrow slick-next inline-block float-right bg-white shadow-md p-6 rounded-full"
            @click="next"
          >
            <svg width="32" height="25" viewBox="0 0 32 25">
              <path
                fill="#3D3D3D"
                fill-rule="evenodd"
                d="M32 12a1.22 1.22 0 0 0 0-.13v-.11a1.25 1.25 0 0 0 0-.13l-.05-.1-.07-.12-.07-.09-.08-.1L21 .39a1.3 1.3 0 0 0-1.82 0 1.25 1.25 0 0 0 0 1.79l8.43 8.56H1.29a1.3 1.3 0 0 0 0 2.59h26.42l-8.55 8.55a1.25 1.25 0 0 0 0 1.79 1.3 1.3 0 0 0 1.82 0L31.63 13l.08-.09.08-.09.06-.11.06-.11a1.18 1.18 0 0 0 0-.12 1.22 1.22 0 0 0 0-.12 1.16 1.16 0 0 0 0-.12 1.2 1.2 0 0 0 0-.13L32 12z"
              ></path>
            </svg>
          </button>
        </div>
        <VueSlickCarousel v-bind="slickOptions" ref="carousel">
          <div class="px-16">
            <div class="relative">
              <CaseStudy
                description="…clean and quiet on-site power to substitute or supplement the use
              of diesel generators for a variety of remote power needs…"
                title="Building EV charging platform to revolutionize the way we power"
                color="#c1f4f0"
                bgColor="#e7fffd"
                imgUrl="https://web.archive.org/web/20211224191030oe_/https://www.simform.com/static/0305ea8/4fa82/case-onlymob%402x.webp"
              />
            </div>
          </div>

          <div class="px-16">
            <div class="relative">
              <CaseStudy
                description="…clean and quiet on-site power to substitute or supplement the use
                of diesel generators for a variety of remote power needs…"
                title="Building EV charging platform to revolutionize the way we power"
                color="#c1f4f0"
                bgColor="#e7fffd"
                imgUrl="https://web.archive.org/web/20211224191030oe_/https://www.simform.com/static/0305ea8/4fa82/case-onlymob%402x.webp"
              />
            </div>
          </div>

          <div class="px-16">
            <div class="relative">
              <CaseStudy
                description="…clean and quiet on-site power to substitute or supplement the use
                of diesel generators for a variety of remote power needs…"
                title="Building EV charging platform to revolutionize the way we power"
                color="#ffe1c2"
                bgColor="#fff4e6"
                imgUrl="https://web.archive.org/web/20220624114612oe_/https://www.simform.com/static/51fd8f7/cab18/case-safari%402x.webp"
              />
            </div>
          </div>
          <div class="px-16">
            <div class="relative">
              <CaseStudy
                description="…clean and quiet on-site power to substitute or supplement the use
                of diesel generators for a variety of remote power needs…"
                title="Building EV charging platform to revolutionize the way we power"
                color="#bae597"
                bgColor="#e7fcd6"
                imgUrl="https://web.archive.org/web/20211224191030oe_/https://www.simform.com/static/0305ea8/4fa82/case-onlymob%402x.webp"
              />
            </div>
          </div>
        </VueSlickCarousel>
      </div>
    </div>
  </simform-section>
</template>
<script>
import TitleUnderline from "../../../../primary/title/title-underline.vue";
import CaseStudy from "../../../../feature-components/case-study/case-study.vue";
import SimformSection from "@/components/sections/basic/simform-section";

export default {
  components: {SimformSection, TitleUnderline, CaseStudy},
  props: {
    title: {
      type: String,
      default: "<u>Custom Software</u> <br/>Development Case Studies",
    },
    singleLine: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      slickOptions: {
        slidesToShow: 1,
        arrows: false,
        autoplay: false,
        initialSlide: 0,
        centerMode: true,
        centerPadding: "300px",
        dots: true,
      },
      selectedIndex: 0,
    };
  },
  methods: {
    previous() {
      this.$refs.carousel.prev();
    },
    next() {
      this.$refs.carousel.next();
    },
  },
};
</script>
<style scoped>
:deep(.slick-slide) {
  transition-property: opacity;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
  transition-duration: 1000ms;
}

:deep(.slick-track > :not(.slick-active)) {
  opacity: 0.4;
}

:deep(.slick-dots) {
  display: flex !important;
  flex-direction: row;
  margin: 0 auto;
  width: 100%;
  justify-content: center;
  margin-top: 1rem;
}

:deep(.slick-dots > li) {
  transition-property: color, background-color, border-color,
  text-decoration-color, fill, stroke;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
  transition-duration: 500ms;
  background-color: #fddee1;
  width: 25px;
  height: 5px;
  margin-left: 0.3rem;
  margin-right: 0.3rem;
  border-radius: 3px;
  cursor: pointer;
}

:deep(.slick-dots > li.slick-active) {
  background-color: #f05367;
}

:deep(.slick-dots > li > button) {
  display: none;
}
</style>
