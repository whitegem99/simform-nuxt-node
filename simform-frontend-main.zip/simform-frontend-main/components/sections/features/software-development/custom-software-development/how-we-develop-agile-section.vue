<template>
  <simform-section white>
    <div class="max-w-8xl mx-auto">
      <avatars-title
        title="How We Develop Custom<br> Software <u> Using Agile</u>"
      />
      <activity-flow />
    </div>
  </simform-section>
</template>
<script>
import SimformSection from "@/components/sections/basic/simform-section";
import AvatarsTitle from "@/components/feature-components/avatars-title/avatars-title";
import ActivityFlow from "@/components/feature-components/activity-flow/activity-flow";

export default {
  components: { ActivityFlow, AvatarsTitle, SimformSection },
};
</script>
