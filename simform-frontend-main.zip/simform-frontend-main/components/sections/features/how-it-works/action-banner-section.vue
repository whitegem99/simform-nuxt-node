<template>
  <simform-section>
    <div class="max-w-6xl mx-auto px-4">
      <action-banner
        title="Speak to our experts to unlock the value Mobility, IoT, and Data Insights!"
        actionText="contact us"
        url="/contact"
      />
    </div>
  </simform-section>
</template>

<script>
import ActionBanner from "../../../feature-components/action-banner/action-banner.vue";
import SimformSection from "@/components/sections/basic/simform-section";

export default {
  components: {SimformSection, ActionBanner},
};
</script>
