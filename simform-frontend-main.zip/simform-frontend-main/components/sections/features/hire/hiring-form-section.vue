<template>
  <simform-section>
    <div
      class="grid grid-cols-2 gap-5 max-w-6xl mx-auto bg-gradient-to-b from-white via-[#f7fffa] to-[#f7fffa] rounded p-16"
    >
      <div>
        <div v-html="data.title" class="hero-title mb-16 text-4xl font-semibold pt-1"></div>
        <div class="mt-5 text-xl font-light" v-html="data.description"></div>
        <div class="mt-10">
            <img :src="image.src" :alt="image.alt" />
        </div>
      </div>
      <div>
        <hiring-form :button-text="data.formButtonText"/>
      </div>
    </div>
  </simform-section>
</template>
<script>
import SimformSection from "@/components/sections/basic/simform-section";
import HiringForm from "@/components/feature-components/hiring-form/hiring-form.vue";
import { getImage } from "../../../../helpers/imageHelper";

export default {
  components: {
    SimformSection,
    HiringForm,
  },
  props: {
    data: {
      type: Object,
      required: true,
    }
  },
  computed: {
    image() {
      return getImage(this.data.image);
    },
  },
};
</script>
