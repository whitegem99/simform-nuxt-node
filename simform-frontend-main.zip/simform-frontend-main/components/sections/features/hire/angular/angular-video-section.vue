<template>
  <simform-section>
    <div class="max-w-4xl mx-auto">
      <div class="my-10">
        <title-underline text="We are <u>your Angular Army!</u>" fontSize="4xl" single-line />
      </div>
      <div>
        <h5 class="font-light text-2xl mb-10 text-center">
          Finding the right talent is not easy. Simform helps you find the top
          10% engineers so that you can focus on what’s important. Your
          business. Our developers have a
          <highlight-text text="proven track record of delivering software" />
          for high growth startups and Fortune companies.
        </h5>
      </div>
      <div>
        <vue-plyr>
          <div class="plyr__video-embed">
            <iframe
              :src="videoUrl"
              allowfullscreen
              allowtransparency
              allow="autoplay"
            ></iframe>
          </div>
        </vue-plyr>
      </div>
    </div>
  </simform-section>
</template>
<script>
import TitleUnderline from "../../../../primary/title/title-underline.vue";
import HighlightText from "../../../../primary/highlight-text/highlight-text.vue";
import SimformSection from "@/components/sections/basic/simform-section";

export default {
  components: {
    SimformSection,
    TitleUnderline,
    HighlightText,
  },
  data() {
    return {
      videoUrl: "https://www.youtube.com/watch?v=54BSxnpeSls",
    };
  },
};
</script>
