<template>
  <simform-section white>
    <div class="max-w-7xl mx-auto pb-10">
      <div class="pb-5">
        <title-underline single-line text="Why <u>Simform?</u>" />
      </div>
      <div>
        <div :class="['grid mt-10', grid]">
          <grid-item
            v-for="item in items"
            :key="item.title"
            :item="item"
            :title="item.title"
            :description="item.description"
            :icon="item.icon"
            :color="item.color"
          />
        </div>
      </div>
    </div>
  </simform-section>
</template>
<script>
import TitleUnderline from "@/components/primary/title/title-underline.vue";
import GridItem from "@/components/feature-components/grid-item/grid-item.vue";
import SimformSection from "@/components/sections/basic/simform-section";

export default {
  components: { SimformSection, TitleUnderline, GridItem },
  computed: {
    grid() {
      return `grid-cols-${this.items.length / 2}`;
    },
  },
  data() {
    return {
      items: [
        {
          title: "Intrinsically agile",
          description:
            "Improve the speed and quality of microservices development with DevOps QA strategies built around your specific business requirements. Our certified and seasoned QA experts dissect microservice functionalities and simulate every possible user interaction to elevate end-user experiences.Optimal business performance through custom software <b>tailored to complement</b> your goals and needs.",
          icon: require("assets/images/services/icons/ServiceEnterpriseAaplication.svg"),
        },
        {
          title: "System Integration Services",
          description:
            "Through our tech partnerships with modern platforms, we provide <strong>software customization</strong> and integration services.",
          icon: require("assets/images/services/icons/system-integration.svg"),
          color: "#eaf1ff",
        },
        {
          title: "Dashboards, ETL, and BI Services",
          description:
            "Get systems <strong>“talking to each other”</strong> to make business more efficient by putting the right information in the right hands.",
          icon: require("assets/images/services/icons/dashboard.svg"),
          color: "#e3fffd",
        },
        {
          title: "Legacy Modernization & Application Migration",
          description:
            "We provide <strong>cloud migration</strong> services, technical architecture reviews, and complete application refinement to bring your IT up to date.",
          icon: require("assets/images/services/icons/legacy.svg"),
          color: "#fff5dc",
        },
      ],
    };
  },
};
</script>
