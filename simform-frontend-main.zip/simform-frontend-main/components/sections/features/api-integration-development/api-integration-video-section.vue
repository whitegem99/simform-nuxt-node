<template>
  <simform-section>
    <div class="max-w-4xl mx-auto">
      <div class="my-10">
        <title-underline text="What is 3rd party <u>API integration?</u>" />
      </div>
      <div>
        <h5 class="font-light text-2xl mb-10 text-center">
          Third party APIs are provided by external parties — such as Twilio,
          Twitter, or Google — to allow developers to
          <highlight-text text="access their functionality" />. API
          (Application Programming Interface) gives programmers the ability to
          connect their custom applications with external systems either in
          network or cloud. This helps speed up development time and cut costs.
        </h5>
      </div>
      <div>
        <vue-plyr>
          <div class="plyr__video-embed">
            <iframe
              :src="videoUrl"
              allowfullscreen
              allowtransparency
              allow="autoplay"
            ></iframe>
          </div>
        </vue-plyr>
      </div>
    </div>
  </simform-section>
</template>
<script>
import TitleUnderline from "../../../primary/title/title-underline.vue";
import HighlightText from "../../../primary/highlight-text/highlight-text.vue";
import SimformSection from "@/components/sections/basic/simform-section";

export default {
  components: {
    SimformSection,
    TitleUnderline,
    HighlightText,
  },
  data() {
    return {
      videoUrl: "https://www.youtube.com/watch?v=54BSxnpeSls",
    };
  },
};
</script>
