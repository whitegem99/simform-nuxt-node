<template>
  <simform-section white>
    <div class="max-w-6xl py-20 mx-auto">
      <div>
        <title-underline text="Our <u>API Solutions</u>" singleLine/>
      </div>

      <div class="py-10">
        <p class="text-xl text-center">Integrate & Develop bespoke API with Simform Solutions</p>
      </div>
      <div class="grid grid-cols-4 mt-10">
        <grid-item
          :icon="
              require('assets/images/services/icons/ServiceEnterpriseAaplication.svg')
            "
        >
          <template #main>
            <div class="pl-4">
              <p class="text-lg mb-5 font-bold">Payment Gateways</p>
              <ul class="list-disc ml-3">
                <li>Paypal</li>
                <li>Stripe</li>
                <li>Authorize.net</li>
                <li>PayU</li>
                <li>Paytm</li>
                <li>PayUmoney</li>
              </ul>
            </div>
          </template>
        </grid-item>

        <grid-item
          :icon="
              require('assets/images/services/icons/system-integration.svg')
            "
          color="#eaf1ff"
        >
          <template #main>
            <div class="pl-4">
              <p class="text-lg mb-5 font-bold">Payment Gateways</p>
              <ul class="list-disc ml-3">
                <li>Facebook</li>
                <li>Instagram</li>
                <li>Twitter</li>
                <li>YouTube</li>
                <li>Pinterest</li>
                <li>Snapchat</li>
                <li>Tumblr</li>
                <li>Viber</li>
              </ul>
            </div>
          </template>
        </grid-item>

        <grid-item
          :icon="require('assets/images/services/icons/dashboard.svg')"
          color="#e3fffd"
        >
          <template #main>
            <div class="pl-4">
              <p class="text-lg mb-5 font-bold">Payment Gateways</p>
              <ul class="list-disc ml-3">
                <li>Paypal</li>
                <li>Stripe</li>
                <li>Authorize.net</li>
                <li>PayU</li>
                <li>Paytm</li>
                <li>PayUmoney</li>
              </ul>
            </div>
          </template>
        </grid-item>

        <grid-item
          :icon="require('assets/images/services/icons/legacy.svg')"
          color="#fff5dc"
        >
          <template #main>
            <div class="pl-4">
              <p class="text-lg mb-5 font-bold">Payment Gateways</p>
              <ul class="list-disc ml-3">
                <li>Paypal</li>
                <li>Stripe</li>
                <li>Authorize.net</li>
                <li>PayU</li>
                <li>Paytm</li>
                <li>PayUmoney</li>
              </ul>
            </div>
          </template>
        </grid-item>
      </div>
    </div>
  </simform-section>
</template>

<script>
import TitleUnderline from "@/components/primary/title/title-underline.vue";
import GridItem
  from "@/components/feature-components/grid-item/grid-item";
import SimformSection from "@/components/sections/basic/simform-section";

export default {
  name: "OurApiSolutions.vue",
  components: {SimformSection, GridItem, TitleUnderline}
}
</script>

<style scoped>

</style>
