<template>
  <section :class="[bgColor, padding, className, topPadding, bottomPadding]">
    <slot></slot>
  </section>
</template>

<script>
export default {
  name: "SimformSection",
  props: {
    white: {
      type: Boolean,
      default: false,
    },
    gradient: {
      type: Boolean,
      default: false,
    },
    extraPadding: {
      type: Boolean,
      default: false,
    },
    className: {
      type: String,
      default: "",
    },
    onlyTopPadding: {
      type: Boolean,
      default: false,
    },
    onlyBottomPadding: {
      type: Boolean,
      default: false,
    },
  },
  computed: {
    bgColor() {
      return this.white ? "bg-white" : this.gradient ? "grad" : "bg-slate-50";
    },
    padding() {
      return this.extraPadding ? "py-20" : "py-10";
    },
    topPadding() {
      return this.onlyTopPadding ? "pb-0" : "";
    },
    bottomPadding() {
      return this.onlyBottomPadding ? "pt-0" : "";
    },
  },
};
</script>
<style scoped>
.grad {
  background: linear-gradient(rgba(252, 253, 255, 0), rgb(245, 245, 245));
  background-color: white;
}
</style>
