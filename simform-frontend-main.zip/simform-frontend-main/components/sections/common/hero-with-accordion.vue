<template>
  <section class="grad-background">
    <div class="max-w-6xl mx-auto">
      <div class="container mx-auto pt-8 text-center mb-20">
        <div class="mx-auto max-w-4xl'">
          <div
            class="text-5xl font-semibold text-center mx-auto leading-tight hero-title pt-1"
            v-html="data.title"
          ></div>
        </div>
        <div
          v-if="data.description"
          class="text-2xl text-secondary-800 font-normal my-6 tracking-wide mx-auto text-center px-5 max-w-3xl"
          v-html="data.description"
        ></div>
      </div>
      <accordion-content v-for="item in items" :data="item" :key="item.id" />
    </div>
  </section>
</template>
<script>
import AccordionContent from "../../feature-components/accordion-content/accordion-content.vue";

export default {
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    items() {
      return this.data.items;
    },
  },
  components: { AccordionContent },
};
</script>
<style scoped>
.grad-background {
  background: linear-gradient(to top, rgb(238, 242, 255), rgb(255, 255, 255));
}
</style>
