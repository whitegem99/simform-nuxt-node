<template>
  <simform-section only-top-padding>
    <areas-we-serve/>
    <simform-footer :with-talk-footer="withTalkFooter" :talk-footer-data="talkFooterData"/>
  </simform-section>
</template>
<script>

import SimformFooter from "../../primary/footer/footer.vue";
import AreasWeServe from "../../primary/footer/areas-we-serve.vue";
import SimformSection from "@/components/sections/basic/simform-section";

export default {
  components: {
    SimformSection,
    SimformFooter,
    AreasWeServe
  },
  props: {
    withTalkFooter: {
      type: Boolean,
      default: false,
    },
    talkFooterData: {
      type: Object,
    }
  }
}
</script>
