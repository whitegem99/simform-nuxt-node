<template>
  <section>
    <div class="container mx-auto pt-8 text-center">
      <div class="mx-auto" :class="data.wideTitle ? 'max-w-5xl' : 'max-w-lg'">
        <div
          class="px-3 sm:px-0 text-4xl sm:text-5xl font-semibold text-center mx-auto leading-tight pt-1 hero-title"
          v-html="data.title"
        ></div>
      </div>
      <div
        v-if="data.description"
        class="text-2xl text-secondary-800 font-normal my-6 tracking-wide mx-auto text-center px-5 max-w-3xl"
        v-html="data.description"
      ></div>
      <div
        class="flex justify-center my-10"
        v-if="data.button && data.button.text && data.button.link"
      >
        <Button :url="data.button.link">
          <span
            class="flex justify-center items-center tracking-wide font-medium text-lg"
          >
            {{ data.button?.text }}</span
          >
        </Button>
      </div>
      <div class="max-w-6xl mx-auto px-10">
        <img
          v-if="image"
          :src="image.src"
          :alt="image.alt"
          class="mx-auto my-10 lg:my-20"
        />
      </div>
    </div>
  </section>
</template>

<script>
import { getImage } from "../../../helpers/imageHelper";
import Button from "../../primary/button/simform-button.vue";

export default {
  name: "Hero",
  components: { Button },
  computed: {
    image() {
      if (!this.data.image) return null;

      return getImage(this.data.image);
    },
  },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
};
</script>
