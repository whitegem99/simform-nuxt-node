<template>
  <simform-section white>
    <div class="max-w-7xl mx-auto p-10">
      <div class="mb-10">
        <title-underline :data="{ text: data.title, align: 'center' }" />
      </div>
      <div class="mb-10 font-light text-xl text-center" v-html="data.paragraph"></div>
      <div class="my-10">
        <img :src="image.src" :alt="image.alt" />
      </div>
      <div class="grid grid-cols-5">
        <div v-for="item in data.columnListItems">
          <div class="font-semibold text-xl mb-5">{{ item.title }}</div>
          <div v-for="subItem in item.checkMarkListItems" class="mb-10">
            <check-mark-item>
              <div
                v-html="subItem.text"
                class="font-light font-merriweather italic text-base"
              ></div>
            </check-mark-item>
          </div>
        </div>
      </div>
    </div>
  </simform-section>
</template>
<script>
import { getImage } from "../../../helpers/imageHelper";
import CheckMarkItem from "../../feature-components/check-mark-list/check-mark-item.vue";
import TitleUnderline from "../../primary/title/title-underline.vue";

export default {
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    image() {
      return getImage(this.data.image);
    },
  },
  components: { CheckMarkItem, TitleUnderline },
};
</script>
