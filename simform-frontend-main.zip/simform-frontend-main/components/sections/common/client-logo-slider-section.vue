<template>
  <simform-section :white="isWhite" only-top-padding>
    <div
      class="font-medium text-3xl font-merriweather italic max-w-xl leading-relaxed mx-auto text-center px-5"
      v-html="data.title"
    ></div>
    <client-logo-slider :clientSliderItems="clientSliderItems" />
    <div class="relative float-right top-[-110px] hidden lg:block">
      <div
        class="font-semibold text-2xl text-center w-[100px] bg-primary-600 rounded-l px-4 py-2 text-white"
      >
        {{ data.sideBoxNumber }}
        <div class="text-xs text-center mt-1">
          <span>{{ data.sideBoxText }}</span>
        </div>
      </div>
    </div>
  </simform-section>
</template>

<script>
import HighlightText from "../../primary/highlight-text/highlight-text.vue";
import ClientLogoSlider from "../../feature-components/client-logo-slider/client-logo-slider.vue";
import SimformSection from "@/components/sections/basic/simform-section";
import { getImage } from "../../../helpers/imageHelper";

export default {
  name: "ClientSliderSection",
  components: { SimformSection, HighlightText, ClientLogoSlider },
  props: {
    isWhite: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      data: {},
    };
  },
  computed: {
    clientSliderItems() {
      return (
        this.data.clientLogos?.map((item) => {
          return {
            colorImage: getImage(item.colorImage),
            grayImage: getImage(item.grayImage),
          };
        }) || []
      );
    },
  },
  mounted() {
    this.fetch();
  },
  methods: {
    async fetch() {
      console.log("async fetch");
      try {
        const data = await fetch(
          `${this.$config.baseURL}/api/trusted-clients?populate=deep`
        );
        const items = await data.json();
        this.data = items.data.attributes;
      } catch (error) {
        console.log(error);
      }
    },
  },
};
</script>
