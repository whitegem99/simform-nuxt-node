<template>
  <simform-section :white="isWhite">
    <div class="max-w-[1200px] mx-auto">
      <div class="pb-10">
        <title-underline
          :data="{ text: data.title, align: 'center' }"
          v-if="data.title"
        />
      </div>
      <customer-say-item-slider :items="data.testimonialVideoItems" />
    </div>
  </simform-section>
</template>
<script>
import CustomerSayItemSlider from "../../feature-components/customer-say/customer-say-item-slider/customer-say-item-slider.vue";
import TitleUnderline from "../../primary/title/title-underline.vue";
import SimformSection from "@/components/sections/basic/simform-section";
export default {
  components: { SimformSection, CustomerSayItemSlider, TitleUnderline },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    isWhite() {
      return this.data.backgroundColor === "white";
    },
  },
};
</script>
