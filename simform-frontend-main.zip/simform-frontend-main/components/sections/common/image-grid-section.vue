<template>
  <simform-section white>
    <div class="max-w-7xl mx-auto p-10">
      <div class="mb-5">
        <up-down-bar-title :text="data.title" />
      </div>
      <image-grid :items="data.imageGridItems" />
    </div>
  </simform-section>
</template>
<script>
import SimformSection from "@/components/sections/basic/simform-section";
import ImageGrid from "../../feature-components/image-grid/image-grid.vue";
import ListParagraph from "../../feature-components/list-paragraph/list-paragraph.vue";
import UpDownBarTitle from "../../feature-components/up-down-bar-title/up-down-bar-title.vue";

export default {
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  components: {
    ListParagraph,
    UpDownBarTitle,
    ImageGrid,
  },
};
</script>
