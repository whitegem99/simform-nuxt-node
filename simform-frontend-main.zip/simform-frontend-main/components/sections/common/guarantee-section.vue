<template>
  <simform-section white>
    <div class="max-w-6xl mx-auto">
      <title-underline :data="{ text: data.title, align: 'center' }" />
      <guarantee :data="data" />
    </div>
  </simform-section>
</template>

<script>
import Guarantee from "../../feature-components/guarantee/guarantee.vue";
import TitleUnderline from "../../primary/title/title-underline.vue";
import SimformSection from "@/components/sections/basic/simform-section";
export default {
  components: { SimformSection, Guarantee, TitleUnderline },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
};
</script>
