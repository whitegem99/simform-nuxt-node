<template>
  <div class="max-w-7xl mx-auto">
    <div :class="['grid mt-10 px-10', grid]">
      <grid-item
        v-for="(item,index) in items"
        :key="index"
        :item="item"
      />
    </div>
  </div>
</template>
<script>
import GridItem from "../../feature-components/grid-item/grid-item.vue";

export default {
  components: {
    GridItem,
  },
  props: {
    items: {
      type: Array,
      required: true,
    },
  },
  computed: {
    grid() {
      // const num = this.items.length / 2
      // return `grid-cols-1 lg:grid-cols-${num.toFixed()}`;
      return `grid-cols-1 lg:grid-cols-3`;
    },
  },
};
</script>
