<template>
  <simform-section white>
    <div class="max-w-7xl mx-auto p-10">
      <div class="mb-10">
        <title-underline :data="{ text: data.title, align: 'center' }" />
      </div>
      <list-paragraph :list="data.list" :paragraph="data.paragraph" />
    </div>
  </simform-section>
</template>
<script>

import SimformSection from "@/components/sections/basic/simform-section";
import ListParagraph from "../../feature-components/list-paragraph/list-paragraph.vue";
import TitleUnderline from "../../primary/title/title-underline.vue";

export default {
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  components: { TitleUnderline, ListParagraph },
};
</script>
