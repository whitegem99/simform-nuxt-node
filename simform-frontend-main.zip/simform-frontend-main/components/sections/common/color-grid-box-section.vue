<template>
  <section class="grad-background pt-32 pb-10">
    <div class="max-w-6xl mx-auto">
      <title-underline :data="{ text: data.title, align: 'center' }" :spaced="false" />
      <color-box-item-grid :items="items" :with-image="false" threeColumns allowDynamicHeight />
    </div>
  </section>
</template>
<script>
import ColorBoxItemGrid from "../../feature-components/development-approach/color-box-item-grid.vue";
import TitleUnderline from "../../primary/title/title-underline.vue";
import SimformSection from "../basic/simform-section.vue";

export default {
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    items() {
      return this.data.colorGridItems;
    },
    allowDynamicHeight() {
      return this.data.allowDynamicHeight;
    },
  },
  components: { ColorBoxItemGrid, SimformSection, TitleUnderline },
};
</script>
<style scoped>
.grad-background {
  background: linear-gradient(to top, rgb(238, 242, 255), rgb(255, 255, 255));
}
</style>
