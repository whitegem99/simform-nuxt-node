<template>
  <simform-section white>
    <div class="max-w-6xl mx-auto">
      <title-underline :data="{ text: title }" />
      <!-- TODO Check for draggable tabs -->
      <div class="w-full mx-auto bg-white shadow-md p-4 my-16">
        <vue-tabs>
          <v-tab
            :title="industriesWeServeItem.title"
            v-for="industriesWeServeItem in industriesWeServeItems"
            :key="industriesWeServeItem.title"
          >
            <industries-we-serve-item
              :title="industriesWeServeItem.title"
              :description="industriesWeServeItem.item.description"
              :images="industriesWeServeItem.item.images"
            />
          </v-tab>
        </vue-tabs>
      </div>
    </div>
  </simform-section>
</template>
<script>
import TitleUnderline from "../../primary/title/title-underline.vue";
import IndustriesWeServeItem from "../../feature-components/industries-we-serve-item/industries-we-serve-item.vue";
import SimformSection from "@/components/sections/basic/simform-section";
import { getImage } from "../../../helpers/imageHelper";

export default {
  components: { SimformSection, TitleUnderline, IndustriesWeServeItem },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    title() {
      return this.data.title;
    },
    industriesWeServeItems() {
      return this.data.industryItems.map((item) => {
        return {
          title: item.tabTitle,
          item: {
            title: item.title,
            description: item.description,
            images: item.images.map((image) => {
              return getImage(image);
            }),
          },
        };
      });
    },
  },
  data() {
    return {
      slickOptionsNav: {
        slidesToShow: 5,
        slidesToScroll: 1,
        dots: false,
        arrows: false,
        centerMode: false,
        infinite: true,
        focusOnSelect: true,
        swipeToSlide: true,
      },
      slickOptions: {
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,
        fade: true,
      },
      startX: 0,
      scrollLeft: 0,
      mouseDown: false,
    };
  },
  mounted() {
    let dragslide = this.$el.querySelector(".nav-tabs");
    if (!dragslide) return;

    dragslide.addEventListener("mousedown", (e) => {
      this.mouseDown = true;
      this.startX = e.pageX;
    });

    dragslide.addEventListener("mouseleave", () => {
      this.mouseDown = false;
      this.startX = 0;
    });

    dragslide.addEventListener("mouseup", () => {
      this.mouseDown = false;
      this.startX = 0;
    });

    dragslide.addEventListener("mousemove", (e) => {
      if (!this.mouseDown) return;
      e.preventDefault();

      const x = (e.pageX - this.startX) * 0.5;
      dragslide.scrollLeft = dragslide.scrollLeft - x;
    });
  },
};
</script>
<style scoped>
:deep(.vue-tabs .nav-tabs) {
  border-bottom: none;
  overflow: hidden;
}

:deep(.tab) {
  text-decoration: none;
  text-align: left;
  cursor: pointer;
  width: 180px;
  margin-right: 30px;
  padding: 23px 20px 28px;
  border: 1px solid rgb(209, 237, 235);
  background-color: rgb(242, 255, 254);
  transition: all 300ms ease 0s;
  color: black;
  font-size: 20px;
}

:deep(.vue-tabs .nav > li > a) {
  color: black;
}

:deep(.tab.active) {
  background-color: rgb(41, 222, 213);
  color: #fff;
}

:deep(.nav .active a) {
  color: #fff !important;
}

:deep(.vue-tabs .nav > li > a) {
  padding: 0;
  color: #000;
}

:deep(.nav-tabs) {
  display: flex;
}

:deep(.slick-slide > div) {
  padding: 0 0.5rem;
}
</style>
