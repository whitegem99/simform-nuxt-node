<template>
  <simform-section>
    <div class="max-w-6xl mx-auto" :class="[withXPadding ? 'px-10' : '']">
      <div class="flex flex-col items-center">
        <img :src="image.src" :alt="image.alt" />
        <div class="text-center text-[16px] text-secondary-400 pt-10">
          {{ image.caption }}
        </div>
      </div>
    </div>
  </simform-section>
</template>
<script>
import SimformSection from "@/components/sections/basic/simform-section";
import { getImage } from "../../../helpers/imageHelper";

export default {
  components: { SimformSection },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    image() {
      return getImage(this.data.image);
    },
    withXPadding() {
      return !!this.data?.withXPadding;
    },
  },
};
</script>
