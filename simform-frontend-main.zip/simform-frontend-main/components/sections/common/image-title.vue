<template>
  <div class="grid grid-cols-3">
    <div
      class="flex relative place-content-end user-image -space-x-4 overflow-hidden"
    >
      <img alt="" :src="image" v-for="image in firstImageBlock" />
    </div>
    <title-underline :data="{ text: title }" />
    <div
      class="flex relative place-content-start user-image -space-x-4 overflow-hidden"
    >
      <img alt="" :src="image" v-for="image in secondImageBlock" />
    </div>
  </div>
</template>

<script>
import TitleUnderline from "../../primary/title/title-underline.vue";
export default {
  components: { TitleUnderline },
  props: {
    title: {
      type: String,
      required: true,
    },
  },
  data() {
    return {
      firstImageBlock: [
        require("~/assets/images/services/custom_agile/service-user-1@2x.png"),
        require("~/assets/images/services/custom_agile/service-user-2@2x.png"),
        require("~/assets/images/services/custom_agile/service-user-3@2x.png"),
      ],
      secondImageBlock: [
        require("~/assets/images/services/custom_agile/service-user-4@2x.png"),
        require("~/assets/images/services/custom_agile/service-user-5@2x.png"),
        require("~/assets/images/services/custom_agile/service-user-6@2x.png"),
      ],
    };
  },
};
</script>
