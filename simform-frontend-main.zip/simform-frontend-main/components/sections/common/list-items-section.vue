<template>
  <simform-section white extra-padding>
    <div class="bg-secondary-50 max-w-6xl mx-auto p-20">
      <div v-if="title" class="mb-10">
        <title-underline :text="title" />
      </div>
      <check-mark-list :items="items" />
    </div>
  </simform-section>
</template>

<script>
import SimformSection from "@/components/sections/basic/simform-section";
import TitleUnderline from "@/components/primary/title/title-underline.vue";
import CheckMark from "@/components/primary/checkmark/check-mark";
import CheckMarkList from "@/components/feature-components/check-mark-list/check-mark-list";
export default {
  name: "list-items-section",
  components: {CheckMarkList, CheckMark, TitleUnderline, SimformSection},
  props: {
    items: {
      type: Array,
      required: true,
    },
    title: {
      type: String
    }
  },
}
</script>

