<template>
  <simform-section :class-name="sectionClass" :white="white">
    <div class="max-w-6xl mx-auto py-10 pb-20">
      <div class="relative">
        <div class="rounded bg-[#edefff] p-10 h-[400px]"></div>
        <div
          class="bg-[#f4f5ff] rounded h-[400px] absolute top-[-20px] left-[-20px] w-full"
        >
          <div class="grid grid-cols-3 p-[40px]">
            <div class="col-span-2">
              <h3 class="text-3xl font-semibold text-primary-600 mb-5">
                Let's Talk
              </h3>
              <form ref="contactForm">
                <input
                  type="text"
                  placeholder="Your Name"
                  class="my-3 outline-none w-full bg-[#f4f5ff] hover:outline-none focus:outline-none border-none focus:ring-0 focus:shadow-none bottom focus:border-primary-600 border-gray-400 placeholder:text-gray-400 placeholder:text-lg"
                />
                <div class="grid gap-3 grid-cols-2">
                  <div>
                    <input
                      type="email"
                      placeholder="email@domain.com"
                      class="my-3 outline-none w-full bg-[#f4f5ff] hover:outline-none focus:outline-none border-none focus:ring-0 focus:shadow-none bottom focus:border-primary-600 border-gray-400 placeholder:text-gray-400 placeholder:text-lg"
                    />
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder="XXX-XX-XXX"
                      class="my-3 outline-none w-full bg-[#f4f5ff] hover:outline-none focus:outline-none border-none focus:ring-0 focus:shadow-none bottom focus:border-primary-600 border-gray-400 placeholder:text-gray-400 placeholder:text-lg"
                    />
                  </div>
                </div>
                <div class="flex">
                  <div class="flex-grow mr-10">
                    <textarea
                      rows="4"
                      cols="50"
                      class="border-none bg-[#f4f5ff] bottom w-full placeholder:text-gray-400 placeholder:text-lg focus:border-primary-600 focus:ring-0 focus:shadow-none hover:outline-none"
                      style="resize: none"
                      placeholder="Your Message"
                    >
                    </textarea>
                  </div>
                  <div class="w-[100px]">
                    <simform-button
                      class="block relative top-[64px] h-[50px]"
                      :on-click="submitForm"
                    >
                      <span
                        class="flex justify-center items-center tracking-wide font-medium text-lg"
                      >
                        SEND
                      </span>
                    </simform-button>
                  </div>
                </div>
              </form>
            </div>
            <div class="text-center flex flex-col items-center">
              <img
                :src="user.photo.src"
                alt="user.photo.alt"
                class="w-[120px] rounded-full"
              />
              <div class="font-bold tracking-wide text-[20px] py-3">
                {{ user.name }}
              </div>
              <p class="font-semibold text-gray-500 px-10 text-[18px]">
                {{ user.text }}
              </p>
              <div class="text-primary-600 font-bold text-md py-3">
                <a :href="phoneLink" class="flex items-center">
                  <img
                    src="~/assets/images/call.svg"
                    alt="Call"
                    class="w-10 text-primary-600"
                  />
                  <span class="uppercase px-5">{{ data.ctaText }}</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </simform-section>
</template>
<script>
import SimformButton from "../../primary/button/simform-button.vue";
import SimformSection from "@/components/sections/basic/simform-section";
import { getImage } from "../../../helpers/imageHelper";

export default {
  name: "LetsTalkSection",
  components: { SimformSection, SimformButton },
  props: {
    separate: {
      type: Boolean,
      default: false,
    },
    data: {
      type: Object,
      required: true,
    },
    white: {
      type: Boolean,
      default: false,
    },
  },
  computed: {
    sectionClass() {
      return this.separate ? "mt-[-200px] bg-transparent" : "bg-white";
    },
    user() {
      return {
        name: this.data.linkedUser.fullName,
        photo: getImage(this.data.linkedUser.avatar),
        text: this.data.linkedUser.contactText,
      };
    },
    phoneLink() {
      return `tel:${this.data.phoneNumber}`;
    },
  },
  methods: {
    async submitForm() {
      console.log("form submitted");
      event.preventDefault();
      if (this.$refs["contactForm"]) {
        const form = this.$refs["contactForm"];

        let data = {};
        const formData = new FormData();

        form.elements.forEach(({ name, type, value, files, ...element }) => {
          if (!["submit", "file"].includes(type)) {
            data[name] = value;
          } else if (type === "file") {
            files.forEach((file) => {
              formData.append(`files.${name}`, file, file.name);
            });
          }
        });

        const token = await this.$recaptcha.execute("login");
        data = { ...data, token };
        new FormData(this.$refs["contactForm"])
          .getAll("services")
          .forEach((item) => {
            data[item] = true;
          });

        formData.append("data", JSON.stringify(data));

        await fetch(`${process.env.STRAPI_HOST}/api/contact-forms`, {
          method: "post",
          body: formData,
        });
      }
    },
  },
};
</script>

<style scoped>
.bottom {
  border-bottom: 2px solid #a9aebb;
}

input {
  padding-top: 0.5rem;
  padding-right: 0.75rem;
  padding-bottom: 0.5rem;
  padding-left: 0.75rem;
}
</style>
