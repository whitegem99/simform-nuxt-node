<template>
  <simform-section white>
    <div class="max-w-5xl mx-auto my-10" v-if="blogs && blogs.length > 0">
      <title-underline :data="{ text: 'Related <u>posts</u>', align: 'left' }" />
      <div class="grid grid-cols-3 gap-4">
        <single-blog-item v-for="blog in blogs" :key="`articles-blog-${blog.id}`" :blog="blog" />
      </div>
    </div>
  </simform-section>
</template>

<script>
import SimformSection from "@/components/sections/basic/simform-section";
import TitleUnderline from "../../primary/title/title-underline.vue";
import SingleBlogItem from '../../feature-components/blog-item/single-blog-item.vue';

export default {
  name: "BlogSection",
  components: { SimformSection, TitleUnderline, SingleBlogItem },
  data() {
    return {
      blogs: []
    };
  },
  props: {
    categorySlug: {
      type: String,
      required: true,
    },
    postId: {
      type: String || Number,
      required: true,
    },
  },
  async fetch() {
    try {
      const data = await fetch(`${process.env.BASE_URL}/api/articles/find-recent/${this.categorySlug}?postId=${this.postId}`);
      const blogs = await data.json();

      this.blogs = blogs;
    } catch (error) {
      console.log(error);
    }
  }
};
</script>
