<template>
  <simform-section white>
    <div class="max-w-5xl mx-auto my-10">
      <title-underline :data="{ text: 'Featured Resources', align: 'center' }" />
      <div class="grid grid-cols-3 gap-4">
        <blog-item v-for="blog in blogs" :key="`home-blog-${blog.id}`" :blog="blog" />
      </div>
    </div>
  </simform-section>
</template>

<script>
import BlogItem from "../../feature-components/blog-item/blog-item.vue";
import SimformSection from "@/components/sections/basic/simform-section";
import TitleUnderline from "../../primary/title/title-underline.vue";

export default {
  name: "BlogSection",
  components: { SimformSection, BlogItem, TitleUnderline },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  data() {
    return {
      blogs: []
    };
  },
  async fetch() {
    try {
      const data = await fetch(`${process.env.BASE_URL}/api/featured-resource?populate=deep`);
      const blogs = await data.json();

      this.blogs = blogs.data.attributes.articles.data;
    } catch (error) {
      console.log(error);
    }
  }
};
</script>
