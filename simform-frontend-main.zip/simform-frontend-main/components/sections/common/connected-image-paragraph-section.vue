<template>
  <simform-section white>
    <div class="max-w-6xl mx-auto">
      <title-underline :data="{ text: data.title, align: 'center' }" />
      <div v-html="data.description" class="font-light text-[22px] max-w-4xl text-center mx-auto px-10 py-10"></div>

      <div>
        <connected-image-paragraph-item
          v-for="(item, index) in data.connectedImageParagraphItems"
          :key="index"
          :data="item"
        />
      </div>
    </div>
  </simform-section>
</template>
<script>
import TitleUnderline from "../../primary/title/title-underline.vue";
import ConnectedImageParagraphItem from "../../feature-components/connected-image-paragraph-item/connected-image-paragraph-item.vue";
import SimformSection from "@/components/sections/basic/simform-section";

export default {
  components: { SimformSection, TitleUnderline, ConnectedImageParagraphItem },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
};
</script>
<style scoped>
ol {
  @apply list-decimal list-inside;
}

ul {
  @apply list-disc list-inside;
}
</style>
