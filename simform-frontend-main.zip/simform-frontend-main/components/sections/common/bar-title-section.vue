<template>
  <simform-section>
    <div :class="['mx-auto max-w-7xl rounded px-36 pb-20 mt-10', white ? 'bg-white' : 'bg-transparent', data.barTitleCheckMarkItems.length == 0 ? 'product-banner-gradient' : '']">
      <up-down-bar-title :text="data.title" />
      <check-mark-list :data="{ checkMarkItems: data.barTitleCheckMarkItems }" v-if="data.barTitleCheckMarkItems.length > 0"/>
      <div v-html="data.paragraph" class="text-xl font-light"></div>
    </div>
  </simform-section>
</template>
<script>
import SimformSection from "@/components/sections/basic/simform-section";
import UpDownBarTitle from "../../feature-components/up-down-bar-title/up-down-bar-title.vue";
import CheckMarkList from "@/components/feature-components/check-mark-list/check-mark-list";
import TitleUnderline from "../../primary/title/title-underline.vue";

export default {
  components: {
    SimformSection,
    UpDownBarTitle,
    CheckMarkList,
    TitleUnderline,
  },

  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    white() {
      return this.data.backgroundColor === 'white';
    },
  },
};
</script>
<style scoped>
.product-banner-gradient {
  background-color: #fff;
  background-image: linear-gradient(
    236deg,
    rgba(255, 255, 255, 0.3),
    rgba(216, 251, 248, 0.3)
  );
}
</style>