<template>
  <simform-section white>
    <div class="max-w-6xl mx-auto">
      <title-underline :data="{ text: data.title, align: 'center' }" />
      <div
        class="text-xl mt-10 mb-16 text-center font-light"
        v-html="data.description"
      ></div>
      <div class="space-y-[90px]">
        <image-paragraph
          :title="item.title"
          :paragraph="item.paragraph"
          :list="item.advancedListItems"
          :image="getImageData(item.image)"
          v-for="(item, index) in data.imageParagraphItems"
          :key="index"
        />
      </div>
    </div>
  </simform-section>
</template>
<script>
import SimformSection from "@/components/sections/basic/simform-section";
import TitleUnderline from "@/components/primary/title/title-underline.vue";
import HighlightedText from "@/components/primary/highlight-text/highlight-text";
import ImageParagraph from "../../feature-components/image-paragraph/image-paragraph.vue";
import { getImage } from "../../../helpers/imageHelper";

export default {
  components: {
    HighlightedText,
    TitleUnderline,
    SimformSection,
    ImageParagraph,
  },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  methods: {
    getImageData(image) {
      return getImage(image);
    },
  },
};
</script>
