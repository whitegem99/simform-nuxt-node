<template>
  <simform-section white>
    <div class="container-m mx-auto py-10 block">
      <div class="mb-16">
        <title-underline :data="{ text: data.title, align: 'center' }" />
      </div>
      <tech-stack :tabs="tabs" />
    </div>
  </simform-section>
</template>

<script>
import TechStack from "../../feature-components/tech-stack/tech-stack.vue";
import SimformSection from "@/components/sections/basic/simform-section";
import TitleUnderline from "../../primary/title/title-underline.vue";
import { getImage } from "../../../helpers/imageHelper";
export default {
  components: {
    SimformSection,
    TechStack,
    TitleUnderline,
  },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    tabs() {
      return this.data.techStackTabs.map((item) => ({
        name: item.title,
        key: item.title,
        items: item.logos.data.map((img) => getImage({ data: img })),
      }));
    },
  },
};
</script>
