<template>
  <simform-section extra-padding white>
    <div class="max-w-[1200px] mx-auto" :class="classNames">
      <div class="pb-10">
        <title-underline text="What our <u>customers say</u>" singleLine/>
      </div>
      <div>
        <customer-say-item-slider/>
      </div>
    </div>
  </simform-section>
</template>

<script>
import CustomerSayItemSlider
  from "../../feature-components/customer-say/customer-say-item-slider/customer-say-item-slider.vue";
import TitleUnderline from "../../primary/title/title-underline.vue";
import SimformSection from "@/components/sections/basic/simform-section";

export default {
  components: {SimformSection, CustomerSayItemSlider, TitleUnderline},
  props: {
    classNames: {
      type: String,
      default: '',
    },
  },
};
</script>
