<template>
  <simform-section extra-padding>
    <div class="max-w-6xl mx-auto px-10">
      <client-only v-if="autoplay">
        <video autoplay muted loop class="rounded">
          <source :src="data.item.url" type="video/mp4" />
        </video>
      </client-only>

      <div v-else>
        <client-only>
          <vue-plyr :options="playerOptions">
            <div class="plyr__video-embed">
              <iframe
                :src="data.item.url"
                allowfullscreen
                allowtransparency
                allow="autoplay"
              ></iframe>
            </div>
          </vue-plyr>
        </client-only>
      </div>
    </div>
  </simform-section>
</template>
<script>
import SimformSection from "@/components/sections/basic/simform-section";

export default {
  components: { SimformSection },
  props: {
    data: {
      type: Object,
      required: true,
    },
    autoplay: {
      type: Boolean,
      default: true,
    },
  },
  data() {
    return {
      playerOptions: {
        controls: ["play-large"],
      },
    };
  },
};
</script>
