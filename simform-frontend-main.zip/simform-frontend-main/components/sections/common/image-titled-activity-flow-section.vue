<template>
  <simform-section white>
    <div class="max-w-8xl mx-auto py-14">
      <avatars-title :title="title" />
      <activity-flow :items="items"/>
    </div>
  </simform-section>
</template>
<script>
import TitleUnderline from "../../primary/title/title-underline.vue";
import SimformSection from "@/components/sections/basic/simform-section";
import AvatarsTitle from "@/components/feature-components/avatars-title/avatars-title";
import ActivityFlow from "@/components/feature-components/activity-flow/activity-flow";
import { getImage } from "../../../helpers/imageHelper";

export default {
  components: { ActivityFlow, AvatarsTitle, SimformSection, TitleUnderline },
  props: {
    singleLine: { type: Boolean, default: true },
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    title() {
      return this.data.title.title;
    },
    items() {
      const colorBoxItems = this.data.colorBoxItems;
      return colorBoxItems.map((item) => {
        return {
          title: item.title,
          description: item.description,
          color: item.color,
          image: getImage(item.image),
        };
      });
    },
  },
};
</script>
