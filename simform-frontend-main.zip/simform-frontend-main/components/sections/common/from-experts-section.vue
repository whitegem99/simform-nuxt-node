<template>
  <simform-section>
    <div class="max-w-6xl mx-auto">
      <div class="mb-10">
        <title-underline :data="{ text: data.title, align: 'center' }" />
      </div>
      <from-experts :items="items" />
      <div class="w-full flex justify-center pt-10">
        <simform-button url="/blog">
          <span
            class="flex justify-center items-center tracking-wide font-medium text-lg mt-1"
          >
            LEARN MORE</span
          >
        </simform-button>
      </div>
    </div>
  </simform-section>
</template>
<script>
import TitleUnderline from "../../primary/title/title-underline.vue";
import FromExperts from "../../feature-components/from-experts/from-experts.vue";
import SimformSection from "@/components/sections/basic/simform-section";
import SimformButton from "../../primary/button/simform-button.vue";
import { getImage } from "../../../helpers/imageHelper";

export default {
  components: {
    TitleUnderline,
    FromExperts,
    SimformSection,
    SimformButton,
  },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    items() {
      return this.data.blogGridItems.map((item) => {
        return {
          link: item.link,
          isLarge: item.isLarge,
          image: getImage(item.image),
        };
      });
    },
  },
};
</script>
