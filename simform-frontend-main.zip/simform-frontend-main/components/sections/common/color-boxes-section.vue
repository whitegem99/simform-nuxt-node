<template>
  <simform-section :white="data.type === 'grid'">
    <div>
      <title-underline :data="{ text: data.title, align: 'center' }" />
      <div class="my-5 max-w-5xl mx-auto text-center text-xl font-light" v-html="data.paragraph"></div>
      <div class="mt-5">
        <hover-bidirectional-slider v-if="data.type === 'slider'">
          <slider-item
            v-for="(item, index) in items"
            :key="index"
            :title="item.title"
            :description="item.description"
            :icon="item.icon"
            :color="item.color"
          />
        </hover-bidirectional-slider>
        <grid-item-section v-else-if="data.type === 'grid'" :items="items" />
        <service-slider-section
          v-else-if="data.type === 'waveSlider'"
          :items="items"
        />
      </div>
    </div>
  </simform-section>
</template>
<script>
import SimformSection from "@/components/sections/basic/simform-section";
import { getImage } from "../../../helpers/imageHelper";
import HoverBidirectionalSlider from "../../feature-components/hover-slider/hover-bidirectional-slider.vue";
import SliderItem from "../../feature-components/scalable-slider-item/scalable-slider-item.vue";
import TitleUnderline from "../../primary/title/title-underline.vue";
import ServiceSliderSection from "../home/service-slider-section.vue";
import GridItemSection from "./grid-item-section.vue";

export default {
  name: "ColorBoxesSection",
  components: {
    HoverBidirectionalSlider,
    SliderItem,
    TitleUnderline,
    SimformSection,
    GridItemSection,
    ServiceSliderSection,
  },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    items() {
      return this.data.colorBoxItems.map((item) => ({
        title: item.title,
        description: item.description,
        icon: getImage(item.image),
        color: this.getColor(item.color),
      }));
    },
  },
  methods: {
    getColor(color) {
      switch (color) {
        case "blue":
          return {
            bg: "#eaf1ff",
            text: "#698ede",
            border: "#c4d1ea",
            tw: {
              bg: "hover:bg-[#eaf1ff]",
              text: "group-hover:text-[#698ede]",
              border: "border-[#c4d1ea]",
            },
          };
        case "green":
          return {
            bg: "#e5ffe9",
            text: "#5db86b",
            border: "#b6e7bd",
            tw: {
              bg: "hover:bg-[#e5ffe9]",
              text: "group-hover:text-[#5db86b]",
              border: "border-[#b6e7bd]",
            },
          };
        case "yellow":
          return {
            bg: "#fff4dc",
            text: "#edb441",
            border: "#ead8b2",
            tw: {
              bg: "hover:bg-[#fff4dc]",
              text: "group-hover:text-[#edb441]",
              border: "border-[#ead8b2]",
            },
          };
        case "purple":
          return {
            bg: "#f5e8ff",
            text: "#9a64c3",
            border: "#dfcbee",
            tw: {
              bg: "hover:bg-[#f5e8ff]",
              text: "group-hover:text-[#9a64c3]",
              border: "border-[#dfcbee]",
            },
          };
        case "orange":
          return {
            bg: "#fff0e5",
            text: "#f78761",
            border: "#fcd9c3",
            tw: {
              bg: "hover:bg-[#fff0e5]",
              text: "group-hover:text-[#f78761]",
              border: "border-[#fcd9c3]",
            },
          };
        case "sky":
          return {
            bg: "#ddf0ff",
            text: "#65a1d2",
            border: "#b8dffd",
            tw: {
              bg: "hover:bg-[#ddf0ff]",
              text: "group-hover:text-[#65a1d2]",
              border: "border-[#b8dffd]",
            },
          };
        case "gray":
          return {
            bg: "#f1f1f1",
            text: "#888888",
            border: "#dcdcdc",
            tw: {
              bg: "hover:bg-[#f1f1f1]",
              text: "group-hover:text-[#888888]",
              border: "border-[#dcdcdc]",
            },
          };
        case "teal":
          return {
            bg: "#e3fffd",
            text: "#3ebcb6",
            border: "#b5ebe7",
            tw: {
              bg: "hover:bg-[#e3fffd]",
              text: "group-hover:text-[#3ebcb6]",
              border: "border-[#b5ebe7]",
            },
          };
        case "red":
          return {
            bg: "#ffefef",
            text: "#d28585",
            border: "#f3cccc",
            tw: {
              bg: "hover:bg-[#ffefef]",
              text: "group-hover:text-[#d28585]",
              border: "border-[#f3cccc]",
            },
          };
        case "olive":
          return {
            bg: "#fffde6",
            text: "#a5a271",
            border: "#e7e4bb",
            tw: {
              bg: "hover:bg-[#fffde6]",
              text: "group-hover:text-[#a5a271]",
              border: "border-[#e7e4bb]",
            },
          };
        default:
          return {
            bg: "#eaf1ff",
            text: "#698ede",
            border: "#c4d1ea",
            tw: {
              bg: "hover:bg-[#eaf1ff]",
              text: "group-hover:text-[#698ede]",
              border: "border-[#c4d1ea]",
            },
          };
      }
    },
  },
};
</script>
