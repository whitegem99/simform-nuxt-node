<template>
  <simform-section>
    <div class="max-w-3xl lg:max-w-7xl mx-auto">
      <div class="my-10">
        <div class="mb-10" v-if="data.title">
          <title-underline :data="{ text: data.title, align: 'center' }" />
        </div>
        <div class="flex gap-20" v-if="data.paragraphListItems && data.paragraphListItems.length > 0">
          <div
            class="px-5 hidden lg:block text-center text-[22px] font-light flex-1 v-para"
            v-if="data.description"
            v-html="data.description"
            :class="data.paragraphListItems.length > 0 ? 'text-left' : ''"
          ></div>
          <div class="flex-1">
            <check-mark-list
              :data="{ checkMarkItems: data.paragraphListItems }"
              large
            />
          </div>
        </div>
        <div
          class="px-5 hidden lg:block text-center text-[22px] font-light max-w-4xl mx-auto"
          v-html="data.description"
          v-else
        ></div>
      </div>
      <div class="px-5 max-w-3xl mx-auto">
        <client-only>
          <vue-plyr>
            <div class="plyr__video-embed" style="border-radius: 10px">
              <iframe
                :src="data.videoLink"
                allowfullscreen
                allowtransparency
                allow="autoplay"
              ></iframe>
            </div>
          </vue-plyr>
        </client-only>
      </div>
    </div>
  </simform-section>
</template>

<script>
import TitleUnderline from "../../primary/title/title-underline.vue";
import SimformSection from "@/components/sections/basic/simform-section";
import CheckMarkList from "../../feature-components/check-mark-list/check-mark-list.vue";

export default {
  name: "VideoParagraphSection",
  components: { SimformSection, TitleUnderline, CheckMarkList },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
};
</script>
<style>
.v-para p {
  text-align: left;
}
</style>
