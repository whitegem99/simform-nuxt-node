<template>
  <simform-section>
    <div class="mx-auto py-8">
      <title-underline
        :data="{ text: 'Awards & Recognitions', align: 'center' }"
      />
      <hover-bidirectional-slider>
        <award-item
          v-for="(item, index) in sliderItems"
          :key="index"
          :image="item"
        />
      </hover-bidirectional-slider>
    </div>
  </simform-section>
</template>
<script>
import HoverBidirectionalSlider from "../../feature-components/hover-slider/hover-bidirectional-slider.vue";
import AwardItem from "../../feature-components/award-items/award-item.vue";
import SimformSection from "@/components/sections/basic/simform-section";
import TitleUnderline from "../../primary/title/title-underline.vue";
import { getImage } from "../../../helpers/imageHelper";

export default {
  components: {
    SimformSection,
    HoverBidirectionalSlider,
    AwardItem,
    TitleUnderline,
  },
  data() {
    return {
      data: {},
    };
  },
  methods: {
    async getData() {
      try {
        const res = await fetch(
          `${this.$config.baseURL}/api/award?populate=deep`
        );
        const { data:value } = await res.json();

        this.data = value.attributes;
      } catch (error) {
        console.log(error);
      }
    },
  },
  mounted() {
    this.getData();
  },
  computed: {
    sliderItems() {
      return this.data.logos?.map((item) => getImage(item.image)) || [];
    },
  },
};
</script>
