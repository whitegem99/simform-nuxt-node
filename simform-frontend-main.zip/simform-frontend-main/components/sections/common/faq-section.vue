<template>
  <simform-section white>
    <div class="max-w-5xl mx-auto">
      <title-underline :data="{ text: this.data.title, align: 'center' }" />
      <div class="grid" :class="grid">
        <div :class="faqItem" class="h-[600px] scrollbar-hide overflow-auto relative">
          <faqs :faqItems="faqItems"/>
          <div class="wrapper-shadow sticky"></div>
        </div>
        <div v-if="withSidebar">
          <service-banner :data="this.data.faqSidebar"/>
        </div>
      </div>
    </div>
  </simform-section>
</template>
<script>
import Faqs from "../../feature-components/faq/faqs.vue";
import TitleUnderline from "../../primary/title/title-underline.vue";
import ServiceBanner from "../../feature-components/faq/service-banner.vue";
import SimformSection from "@/components/sections/basic/simform-section";

export default {
  components: { SimformSection, Faqs, TitleUnderline, ServiceBanner },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    grid() {
      return this.withSidebar ? "grid-cols-3" : "grid-cols-8";
    },
    faqItem() {
      return this.withSidebar ? "col-span-2" : "col-start-2 col-span-6";
    },
    withSidebar() {
      return this.data.faqSidebar && Object.keys(this.data.faqSidebar).length > 0;
    },
    faqItems() {
      return this.data.faqItems;
    },
  },
};
</script>
<style scoped>
.scrollbar-hide::-webkit-scrollbar {
  display: none;
}

/* For IE, Edge and Firefox */
.scrollbar-hide {
  -ms-overflow-style: none; /* IE and Edge */
  scrollbar-width: none; /* Firefox */
}

.wrapper-shadow {
  left: 0px;
  right: 0px;
  bottom: -10px;
  width: 100%;
  height: 65px;
  background-image: linear-gradient(rgba(255, 255, 255, 0), rgb(255, 255, 255));
}
</style>
