<template>
  <div class="my-8 max-w-6xl mx-auto">
    <img :src="image.src" :alt="image.alt" class="w-full rounded" />
  </div>
</template>
<script>
import { getImage } from '../../../helpers/imageHelper';

export default {
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  computed: {
    image() {
      return getImage(this.data.image);
    },
  },
};
</script>
