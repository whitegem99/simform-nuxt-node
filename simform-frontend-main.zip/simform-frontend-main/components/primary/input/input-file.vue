<template>
  <div
    class="p-10 border-black rounded border-solid border px-5 pt-4 pb-10 w-full mt-5 items-center align-middle"
    style="border: 1px solid rgba(0, 0, 0, 0.2)"
  >
    <div>
      <label
        for="file"
        class="flex items-center justify-between flex-col sm:flex-row"
      >
        <div class="flex items-center gap-3">
          <img
            src="~/assets/images/icon-upload.svg"
            alt=""
            srcset=""
            width="32"
            class="hidden sm:block"
          />
          <span class="mt-1.5">
            {{ fileName || "Drag or Browse your project brief" }}
          </span>
        </div>
        <div>
          <span
            @click="clearFile"
            class="z-10 relative cursor-pointer"
            v-if="fileName"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke-width="1.5"
              stroke="currentColor"
              class="w-6 h-6"
            >
              <path
                stroke-linecap="round"
                stroke-linejoin="round"
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </span>
        </div>
        <div class="">
          <div
            class="inline-flex items-center px-6 py-3 border border-transparent text-base rounded-md shadow-sm text-white bg-sky-400 hover:bg-sky-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-sky-400 uppercase font-bold tracking-wide align-middle pt-4"
          >
            <span class="align-middle"> Upload </span>
          </div>
        </div>
      </label>
      <input
        type="file"
        name="files"
        id="file"
        class="hidden"
        title="Drag or Browse your project brief"
        @change="updateFileName"
        ref="fileFieldUpload"
      />
    </div>
  </div>
</template>
<script>
export default {
  name: "InputFile",
  data() {
    return {
      fileName: null,
    };
  },
  methods: {
    updateFileName(event) {
      if (event.target.files[0]) {
        this.fileName = event.target.files[0].name;
      }
    },
    clearFile() {
      if (!this.$refs["fileFieldUpload"]) return;

      this.$refs["fileFieldUpload"].values = null;
    },
  },
};
</script>
<style scoped>
.button {
  background-color: rgba(109, 216, 255, 1);
  box-shadow: rgb(0 0 0 / 10%) 0px 0px 7px -2px;
}
</style>
