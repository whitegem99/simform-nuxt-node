<template>
  <div class="form-item relative" :class="inputWidthClass">
    <textarea
      type="text"
      class="input appearance-none bg-transparent border-black rounded border-solid border h-32 text-base leading-5 mb-0 max-w-full py-4 px-5 tracking-normal w-full transition-all duration-300 ease-in-out outline-none"
      :name="name"
      required
      ref="input"
    >
    </textarea>

    <label
      class="label pointer-events-none focus:ring-0 cursor-text font-normal text-base leading-5 mb-0 absolute capitalize tracking-normal truncate max-w-[90%] transition-all duration-300 ease-in-out left-[22px] top-[15px]"
      for=""
    >
      {{ label }} {{ required ? `*` : `` }}
    </label>
  </div>
</template>
<script>
export default {
  name: "InputTextArea",
  props: {
    label: String,
    required: Boolean,
    name: String,
    inputWidth: {
      type: String,
      default: "100%",
    },
  },

  computed: {
    inputWidthClass: function () {
      return `w-[${this.inputWidth}]`;
    },
  },

  mounted() {
    this.$refs.input.addEventListener("blur", this.onBlur);
  },

  methods: {
    onBlur() {
      if (!this.$refs.input) return;

      if (this.$refs.input.value) {
        this.$refs.input.classList.add("filled");
      } else {
        this.$refs.input.classList.remove("filled");
      }
    },
  },
};
</script>
<style scoped>
.input {
  border: 1px solid rgba(0, 0, 0, 0.2);
}
.input:focus {
  border-color: rgb(119, 218, 254);
}
.label {
  color: rgba(80, 79, 79, 1);
}

.input:focus + .label {
  top: -6px;
  font-size: 11px;
  line-height: 12px;
  padding: 0px 2px;
  background: rgb(231, 248, 255);
  z-index: 9;
}

.input.filled + .label {
  top: -6px;
  font-size: 11px;
  line-height: 12px;
  padding: 0px 2px;
  background: rgb(231, 248, 255);
  z-index: 9;
}
</style>
