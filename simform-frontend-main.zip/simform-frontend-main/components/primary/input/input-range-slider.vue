<template>
  <div
    class="p-10 border-black rounded border-solid border px-5 pt-4 pb-10 w-full"
    style="border: 1px solid rgba(0, 0, 0, 0.2)"
  >
    <span style="color: rgba(80, 79, 79, 1)"> What’s your budget? </span>

    <div
      class="track-container w-[80%] relative transition-all duration-75 ease-in-out mx-auto mb-10 mt-16"
    >
      <span class="range-value min" ref="mintrack">${{ minValue }} </span>
      <span class="range-value max" ref="maxtrack">${{ maxValue }}</span>
      <div class="track" ref="_vpcTrack"></div>
      <div class="track-highlight" ref="trackHighlight"></div>
      <button class="track-btn track1" ref="track1"></button>
      <button class="track-btn track2" ref="track2"></button>
    </div>
  </div>
</template>

<script>
export default {
  name: "InputRangeSlider",

  props: {
    trackHeight: {
      type: Number,
      deafult: 1,
    },
  },

  data() {
    return {
      min: 5000,
      max: 500000,
      minValue: 5000,
      maxValue: 500000,
      step: 1,
      totalSteps: 0,
      percentPerStep: 1,
      trackWidth: 10,
      isDragging: false,
      pos: {
        curTrack: null,
      },
    };
  },

  methods: {
    moveTrack(track, ev) {
      let percentInPx = this.getPercentInPx();

      let trackX = Math.round(
        this.$refs._vpcTrack.getBoundingClientRect().left
      );
      let clientX = ev.clientX;
      let moveDiff = clientX - trackX;

      let moveInPct = moveDiff / percentInPx;
      // console.log(moveInPct)

      if (moveInPct < 1 || moveInPct > 100) return;
      let value =
        Math.round(moveInPct / this.percentPerStep) * this.step + this.min;
      if (track === "track1") {
        if (value >= this.maxValue - this.step) return;
        this.minValue = value;
        this.$refs["mintrack"].style.left = moveInPct - 2 + "%";
      }

      if (track === "track2") {
        if (value <= this.minValue + this.step) return;
        this.maxValue = value;
        this.$refs["maxtrack"].style.left = moveInPct - 2 + "%";
      }

      this.$refs[track].style.left = moveInPct + "%";
      this.setTrackHightlight();
    },
    mousedown(ev, track) {
      if (this.isDragging) return;
      this.isDragging = true;
      this.pos.curTrack = track;
    },

    touchstart(ev, track) {
      this.mousedown(ev, track);
    },

    mouseup(ev, track) {
      if (!this.isDragging) return;
      this.isDragging = false;
    },

    touchend(ev, track) {
      this.mouseup(ev, track);
    },

    mousemove(ev, track) {
      if (!this.isDragging) return;
      this.moveTrack(track, ev);
    },

    touchmove(ev, track) {
      this.mousemove(ev.changedTouches[0], track);
    },

    valueToPercent(value) {
      return ((value - this.min) / this.step) * this.percentPerStep;
    },

    setTrackHightlight() {
      this.$refs.trackHighlight.style.left =
        this.valueToPercent(this.minValue) + "%";
      this.$refs.trackHighlight.style.width =
        this.valueToPercent(this.maxValue) -
        this.valueToPercent(this.minValue) +
        "%";
    },

    getPercentInPx() {
      let trackWidth = this.$refs._vpcTrack.offsetWidth;
      let oneStepInPx = trackWidth / this.totalSteps;
      // 1 percent in px
      let percentInPx = oneStepInPx / this.percentPerStep;

      return percentInPx;
    },

    setClickMove(ev) {
      let track1Left = this.$refs.track1.getBoundingClientRect().left;
      let track2Left = this.$refs.track2.getBoundingClientRect().left;
      // console.log('track1Left', track1Left)
      if (ev.clientX < track1Left) {
        this.moveTrack("track1", ev);
      } else if (ev.clientX - track1Left < track2Left - ev.clientX) {
        this.moveTrack("track1", ev);
      } else {
        this.moveTrack("track2", ev);
      }
    },
  },

  mounted() {
    // calc per step value
    this.totalSteps = (this.max - this.min) / this.step;

    // percent the track button to be moved on each step
    this.percentPerStep = 100 / this.totalSteps;
    // console.log('percentPerStep', this.percentPerStep)

    // set track1 initilal
    document.querySelector(".track1").style.left =
      this.valueToPercent(this.minValue) + "%";
    // track2 initial position
    document.querySelector(".track2").style.left =
      this.valueToPercent(this.maxValue) + "%";
    // set initila track highlight
    this.setTrackHightlight();

    var self = this;

    ["mouseup", "mousemove"].forEach((type) => {
      document.body.addEventListener(type, (ev) => {
        // ev.preventDefault();
        if (self.isDragging && self.pos.curTrack) {
          self[type](ev, self.pos.curTrack);
        }
      });
    });

    [
      "mousedown",
      "mouseup",
      "mousemove",
      "touchstart",
      "touchmove",
      "touchend",
    ].forEach((type) => {
      document.querySelector(".track1").addEventListener(type, (ev) => {
        ev.stopPropagation();
        self[type](ev, "track1");
      });

      document.querySelector(".track2").addEventListener(type, (ev) => {
        ev.stopPropagation();
        self[type](ev, "track2");
      });
    });

    // on track clik
    // determine direction based on click proximity
    // determine percent to move based on track.clientX - click.clientX
    document.querySelector(".track").addEventListener("click", function (ev) {
      ev.stopPropagation();
      self.setClickMove(ev);
    });

    document
      .querySelector(".track-highlight")
      .addEventListener("click", function (ev) {
        ev.stopPropagation();
        self.setClickMove(ev);
      });
  },
};
</script>

<style>
.range-value {
  background: rgb(255, 255, 255);
  padding: 6px 7px;
  border-radius: 3px;
  box-shadow: rgb(109 216 255 / 49%) 0px 3px 4px 0px;
  font-size: 11px;
  letter-spacing: -0.12px;
  line-height: 15px;
  position: absolute;
  top: -42px;
  left: 50%;
  transform: translateX(-50%);
  margin-bottom: 16px;
  display: block;
}

.range-value::after {
  content: "";
  position: absolute;
  width: 0px;
  height: 0px;
  margin-left: -7px;
  bottom: -8px;
  left: 50%;
  box-sizing: border-box;
  border-width: 5px;
  border-style: solid;
  border-image: initial;
  border-color: transparent transparent rgb(255, 255, 255) rgb(255, 255, 255);
  transform-origin: 0px 0px;
  transform: rotate(-45deg);
  box-shadow: rgb(109 216 255 / 40%) -3px 3px 3px 0px;
}
.range-value.min {
  left: 0;
}

.range-value.max {
  left: 100%;
}

.track,
.track-highlight {
  display: block;
  position: absolute;
  width: 100%;
  height: 0.2rem;
}

.track {
  background-color: rgba(145, 225, 255, 0.4);
  border-radius: 5px;
}

.track-highlight {
  background: rgba(145, 225, 255, 0.2);
  border-radius: 5px;
  z-index: 2;
}

.track-btn {
  -webkit-appearance: none;
  -moz-appearance: none;
  appearance: none;
  outline: none;
  cursor: pointer;
  display: block;
  position: absolute;
  z-index: 2;
  width: 1.5rem;
  height: 1.5rem;
  top: -0.5rem;
  margin-left: -1rem;
  border: none;
  background: rgb(255, 255, 255);
  border: 5px solid rgb(109, 216, 255);
  border-radius: 50%;
  -ms-touch-action: pan-x;
  touch-action: pan-x;
  transition: box-shadow 0.3s ease-out, background-color 0.3s ease,
    -webkit-transform 0.3s ease-out;
  transition: transform 0.3s ease-out, box-shadow 0.3s ease-out,
    background-color 0.3s ease;
  transition: transform 0.3s ease-out, box-shadow 0.3s ease-out,
    background-color 0.3s ease, -webkit-transform 0.3s ease-out;
}
</style>
