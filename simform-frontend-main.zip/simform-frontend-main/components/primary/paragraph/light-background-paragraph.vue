<template>
  <div
    :class="[
      'px-8 py-6 rounded-md border-[#f0f0f0] border bg-blend-lighten my-5 max-w-6xl mx-auto',
      bgColor,
    ]"
  >
    <title-underline
      :data="{ text: data.title, align: 'left' }"
      v-if="data.title"
      single-line
      text-align="left"
      font-size="6xl"
      :spaced="false"
    />
    <text-paragraph :data="{ text: data.text }" />
  </div>
</template>
<script>
import TitleUnderline from "../title/title-underline.vue";
import TextParagraph from "./text-paragraph.vue";

export default {
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  components: { TextParagraph, TitleUnderline },
  computed: {
    bgColor() {
      switch (this.data.color) {
        case "yellow":
          return "bg-[#f7f7f7]";
        case "orange":
          return "bg-[#fbeaea]";
        default:
          return "bg-[#f7f7f7]";
      }
    },
  },
};
</script>
