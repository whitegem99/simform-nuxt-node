<template>
  <div v-html="data.text" class="paragraph my-5 text-2xl max-w-6xl mx-auto leading-relaxed paragraph"></div>
</template>
<script>
export default {
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
};
</script>
