<template>
  <div class="w-full pt-20 footer-map">
    <div class="sm:px-0 px-3">
      <div class="relative top-52">
        <div class="max-w-7xl mx-auto flex justify-between">
          <button class="slick-arrow slick-prev inline-block" @click="previous">
            <svg width="32" height="25" viewBox="0 0 32 25">
              <path
                fill="#3D3D3D"
                fill-rule="evenodd"
                d="M0 12a1.22 1.22 0 0 1 0-.13v-.11a1.25 1.25 0 0 1 0-.13l.05-.1.07-.12.07-.09.08-.1L11 .39a1.3 1.3 0 0 1 1.82 0 1.25 1.25 0 0 1 0 1.79l-8.43 8.56h26.32a1.3 1.3 0 0 1 0 2.59H4.29l8.55 8.55a1.25 1.25 0 0 1 0 1.79 1.3 1.3 0 0 1-1.82 0L.37 13l-.08-.09-.08-.09-.06-.11-.06-.11a1.18 1.18 0 0 1 0-.12 1.22 1.22 0 0 1 0-.12 1.16 1.16 0 0 1 0-.12 1.2 1.2 0 0 1 0-.13L0 12z"
              ></path>
            </svg>
          </button>
          <button
            class="slick-arrow slick-next inline-block float-right"
            @click="next"
          >
            <svg width="32" height="25" viewBox="0 0 32 25">
              <path
                fill="#3D3D3D"
                fill-rule="evenodd"
                d="M32 12a1.22 1.22 0 0 0 0-.13v-.11a1.25 1.25 0 0 0 0-.13l-.05-.1-.07-.12-.07-.09-.08-.1L21 .39a1.3 1.3 0 0 0-1.82 0 1.25 1.25 0 0 0 0 1.79l8.43 8.56H1.29a1.3 1.3 0 0 0 0 2.59h26.42l-8.55 8.55a1.25 1.25 0 0 0 0 1.79 1.3 1.3 0 0 0 1.82 0L31.63 13l.08-.09.08-.09.06-.11.06-.11a1.18 1.18 0 0 0 0-.12 1.22 1.22 0 0 0 0-.12 1.16 1.16 0 0 0 0-.12 1.2 1.2 0 0 0 0-.13L32 12z"
              ></path>
            </svg>
          </button>
        </div>
      </div>
      <div class="max-w-6xl mx-auto">
        <div
          class="font-semibold w-full flex justify-start py-10 text-xl mb-10"
        >
          Areas We Serve
        </div>
        <div class="px-[50px]">
          <vue-slick-carousel
            v-bind="slickOptions"
            ref="carousel"
            v-if="areas && areas.length > 0"
          >
            <div v-for="area in areas" :key="`area-${area.id}`">
              <location
                :location="area.city"
                :address="area.address"
                :phone="area.phone"
              ></location>
            </div>
          </vue-slick-carousel>
        </div>
      </div>
    </div>
    <div class="h-44 grad"></div>
  </div>
</template>
<script>
import Location from "../../feature-components/areas-we-serve/location.vue";

export default {
  data() {
    return {
      slickOptions: {
        slidesToShow: 4,
        arrows: false,
        autoplay: false,
        initialSlide: 0,
        responsive: [
          {
            breakpoint: 1024,
            settings: {
              slidesToShow: 3,
              slidesToScroll: 5,
              infinite: true,
              dots: false,
            },
          },
          {
            breakpoint: 600,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1,
              initialSlide: 1,
            },
          },
          {
            breakpoint: 480,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1,
            },
          },
        ],
      },
      selectedIndex: 0,
      areas: [],
    };
  },
  methods: {
    previous() {
      this.$refs.carousel.prev();
    },
    next() {
      this.$refs.carousel.next();
    },
  },
  components: {
    Location,
  },
  async fetch() {
    try {
      const data = await fetch(
        `${process.env.BASE_URL}/api/areas-we-serve?populate=deep`
      );
      const areas = await data.json();

      this.areas = areas.data.attributes.items;
    } catch (error) {
      console.log(error);
    }
  },
};
</script>
<style>
.footer-map {
  background-image: url("~/assets/images/footer-map.svg");
  background-repeat: no-repeat;
  background-position-x: right;
}

.grad {
  background-image: linear-gradient(rgb(248 250 252), rgb(255 255 255));
}
</style>
