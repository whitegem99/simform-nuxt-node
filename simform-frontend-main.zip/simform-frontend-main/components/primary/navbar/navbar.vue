<template>
  <div class="hidden lg:block">
    <div
      class="flex item-center justify-center gap-5 text-xs font-semibold text-gray-600 bg-white py-1 tracking-wide"
    >
      <nuxt-link
        v-for="item in navigation"
        :to="item.href"
        :key="item.name"
        class="hover:text-primary-500"
        >{{ item.name }}</nuxt-link
      >
    </div>
  </div>
</template>

<script>
import Button from "../button/simform-button.vue";
export default {
  name: "MainNavigation",
  components: { Button },
  props: {
    navigation: {
      type: Array,
      required: true,
    },
  },
};
</script>
