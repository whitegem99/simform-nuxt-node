<template>
  <div @click="toggle" role="button" class="cursor-pointer py-2">
    <div class="flex justify-between items-center">
      <div
        :class="[
          'tracking-wide',
          isSubMenu ? 'text-sm font-bold' : 'text-lg font-bold',
          isExpanded ? 'text-primary-500' : 'text-slate-700',
        ]"
      >
        {{ title }}
      </div>
      <div class="text-primary-500" v-if="isExpanded">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          class="w-6 h-6"
        >
          <path
            fill="currentColor"
            d="M17,13.41,12.71,9.17a1,1,0,0,0-1.42,0L7.05,13.41a1,1,0,0,0,0,1.42,1,1,0,0,0,1.41,0L12,11.29l3.54,3.54a1,1,0,0,0,.7.29,1,1,0,0,0,.71-.29A1,1,0,0,0,17,13.41Z"
          />
        </svg>
      </div>
      <div class="text-slate-600" v-else>
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          class="w-6 h-6"
        >
          <path
            fill="currentColor"
            d="M17,9.17a1,1,0,0,0-1.41,0L12,12.71,8.46,9.17a1,1,0,0,0-1.41,0,1,1,0,0,0,0,1.42l4.24,4.24a1,1,0,0,0,1.42,0L17,10.59A1,1,0,0,0,17,9.17Z"
          />
        </svg>
      </div>
    </div>
    <div v-if="isExpanded">
      <ul class="ml-5 text-sm font-bold">
        <li class="py-3" v-for="item in items" :key="item.name">
          <div v-if="!!item.submenu">
            <side-nav-item
              :title="item.name"
              :items="item.submenu"
              :isExpanded="isSubMenuExpanded"
              :isSubMenu="true"
              @itemSelected="toggleSubMenu"
            />
          </div>
          <nuxt-link
            v-else
            :to="item.href"
            class="text-slate-700 hover:text-primary-600 duration-300 transition-colors"
            >{{ item.name }}</nuxt-link
          >
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
export default {
  name: "SideNavItem",
  data() {
    return {
      isSubMenuExpanded: false,
    };
  },
  methods: {
    toggle() {
      this.$emit("itemSelected", this.title);
    },
    toggleSubMenu() {
      this.isSubMenuExpanded = !this.isSubMenuExpanded;
    },
  },
  props: {
    title: {
      type: String,
      required: true,
    },
    items: {
      type: Array,
      required: true,
    },
    isExpanded: {
      type: Boolean,
      required: false,
    },
    isSubMenu: {
      type: Boolean,
      required: false,
    },
  },
};
</script>
