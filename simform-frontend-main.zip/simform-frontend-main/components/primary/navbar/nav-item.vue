<template>
  <div class="group z-50">
    <button
      class="text-gray-600 group-hover:text-primary-500 text-sm flex gap-2 group font-semibold tracking-wide h-12 items-center transition-all duration-500 ease-in-out"
    >
      {{ name }}

      <svg
        xmlns="http://www.w3.org/2000/svg"
        class="h-4 w-4 group-hover:scale-y-[-1] duration-300"
        viewBox="0 0 20 20"
        fill="currentColor"
      >
        <path
          fill-rule="evenodd"
          d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
          clip-rule="evenodd"
        />
      </svg>
    </button>

    <div
      class="opacity-0 invisible group-hover:visible flex translate-y-3 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-500 ease-in-out hover:flex w-[265px] flex-col bg-white drop-shadow-lg p-1 rounded absolute text-sm mt-0 pointer-events-none group-hover:pointer-events-auto"
    >
      <nuxt-link
        class="px-2 py-3 hover:bg-primary-200 rounded group-menusub flex justify-between w-full transition-all duration-500 ease-in-out"
        v-for="item in items"
        :key="item.name"
        :to="item.href"
      >
        <span>{{ item.name }}</span>

        <svg
          v-if="item.submenu"
          class="h-4 w-4 inline-block self-center"
          viewBox="0 0 20 20"
          fill="currentColor"
        >
          <path
            fill-rule="evenodd"
            d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
            clip-rule="evenodd"
          />
        </svg>
        <template v-if="item.submenu">
          <div
            class="right-[-100%] opacity-0 invisible ease-in-out group-menusub-hover:visible flex translate-y-3 group-menusub-hover:opacity-100 group-menusub-hover:translate-y-0 transition-all duration-500 hover:flex w-[265px] flex-col bg-white drop-shadow-lg p-1 rounded absolute text-sm -mt-8 pointer-events-none group-hover:pointer-events-auto"
          >
            <nuxt-link
              class="px-2 py-3 hover:bg-primary-200 rounded transition-colors duration-500 ease-in-out"
              :to="subitem.href"
              :key="subitem.name"
              v-for="subitem in item.submenu"
              >{{ subitem.name }}
            </nuxt-link>
          </div>
        </template>
      </nuxt-link>
    </div>
  </div>
</template>
<script>
export default {
  props: ["name", "items"],
};
</script>
