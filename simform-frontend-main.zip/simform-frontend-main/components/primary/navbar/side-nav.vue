<template>
  <div class="sidenav-container" id="side-nav">
    <div v-if="isSideNavOpen" class="backdrop"></div>
    <transition name="slide-side">
      <div v-if="isSideNavOpen" class="sidenav">
        <div class="flex justify-between mb-10">
          <nuxt-link to="/">
            <img
              src="~/assets/images/simform-logo.svg"
              alt=""
              class="inline w-40"
            />
          </nuxt-link>
          <span class="text-primary-500" @click="toggleSideNav">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              class="w-10 h-10"
            >
              <path
                fill="currentColor"
                d="M13.41,12l4.3-4.29a1,1,0,1,0-1.42-1.42L12,10.59,7.71,6.29A1,1,0,0,0,6.29,7.71L10.59,12l-4.3,4.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0L12,13.41l4.29,4.3a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42Z"
              />
            </svg>
          </span>
        </div>
        <div>
          <div class="border-b-2 border-slate-100 text-lg font-bold pb-1">
            Services
          </div>
          <div class="mt-8">
            <side-nav-item
              v-for="item in navigation"
              :key="item.title"
              :title="item.title"
              :items="item.items"
              @itemSelected="changeSelectedMenuItem"
              :isExpanded="isMenuItemSelected(item.title)"
            />
          </div>
        </div>
        <div class="mt-7">
          <div class="border-b-2 border-slate-100 text-lg font-bold pb-1">
            Company
          </div>
          <div class="flex flex-col gap-2 item-center tracking-wide mt-8">
            <nuxt-link
              v-for="item in companyNavigation"
              :to="item.href"
              :key="item.name"
              class="text-lg font-bold hover:text-primary-500 py-1"
              >{{ item.name }}</nuxt-link
            >
          </div>
        </div>
      </div>
    </transition>
  </div>
</template>

<script>
import SideNavItem from "./side-nav-item.vue";

export default {
  components: { SideNavItem },
  data() {
    return {
      selectedMenuItem: "",
    };
  },
  methods: {
    hideSidebar() {
      this.$store.dispatch("nav/toggleSidebar");
    },
    changeSelectedMenuItem(item) {
      this.selectedMenuItem = item;
    },
    isMenuItemSelected(name) {
      return this.selectedMenuItem === name;
    },
  },
  computed: {
    isSidebar() {
      // return this.$store.getters["nav/toggleSidebar"];
      return false;
    },
  },
  props: {
    navigation: {
      type: Array,
      required: true,
    },
    companyNavigation: {
      type: Array,
      required: true,
    },
    toggleSideNav: {
      type: Function,
      required: true,
    },
    isSideNavOpen: {
      type: Boolean,
      required: true,
    },
  },
};
</script>

<style scoped>
.sidenav-container {
  height: 100%;
  width: 100%;
}
.sidenav {
  height: 100%;
  width: 350px;
  background-color: white;
  z-index: 10000;
  position: fixed;
  top: 0;
  left: 0;
  box-sizing: border-box;
  padding: 30px;
}
.sidenav span {
  position: absolute;
  right: 20px;
  top: 20px;
}
.backdrop {
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.4);
  z-index: 1000;
  position: fixed;
  top: 0;
  left: 0;
}
.slide-side-enter-active,
.slide-side-leave-active {
  transition: all 0.3s ease-out;
}
.slide-side-enter,
.slide-side-leave-to {
  transform: translateX(-100%);
}
</style>
Footer
