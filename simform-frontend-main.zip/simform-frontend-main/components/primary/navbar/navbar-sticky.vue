<template>
  <client-only>
    <div class="nav-bg w-full min-h-12 sticky-top backdrop-blur-lg px-10">
      <div class="hidden lg:block w-full m-auto self-center">
        <div class="grid grid-cols-12 space-between">
          <div class="px-5 self-center col-span-2">
            <nuxt-link to="/">
              <img :src="image.src" :alt="image.alt" class="inline w-40" />
            </nuxt-link>
          </div>
          <div class="hidden lg:flex flex-col justify-center col-span-8">
            <div class="h-12 justify-center flex gap-3">
              <nav-item
                v-for="item in navigation"
                :key="item.title"
                :name="item.title"
                :items="item.items"
              />
            </div>
          </div>

          <div class="grid items-center justify-items-end col-span-2">
            <Button
              size="small"
              class="justify-self-end flex align-middle w-[100px]"
              url="/contact"
            >
              <span
                class="flex justify-center items-center tracking-wide font-semibold mt-[4px] px-2"
                >Contact Us</span
              >
            </Button>
          </div>
        </div>
      </div>
      <div class="block lg:hidden mb-5">
        <div class="flex justify-between py-5 px-3">
          <nuxt-link to="/">
            <img :src="image.src" :alt="image.alt" class="inline w-40" />
          </nuxt-link>
          <button @click="toggleSideNav">
            <span
              class="flex gap-2 text-primary-600 text-lg font-body items-center"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                class="w-8 h-8"
              >
                <path
                  fill="currentColor"
                  d="M3,8H21a1,1,0,0,0,0-2H3A1,1,0,0,0,3,8Zm18,8H3a1,1,0,0,0,0,2H21a1,1,0,0,0,0-2Zm0-5H3a1,1,0,0,0,0,2H21a1,1,0,0,0,0-2Z"
                />
              </svg>
              Menu
            </span>
          </button>
        </div>
      </div>
    </div>
  </client-only>
</template>
<script>
import { getImage } from "../../../helpers/imageHelper";
import Button from "../button/simform-button.vue";
import NavItem from "./nav-item.vue";

export default {
  components: { Button, NavItem },
  props: {
    navigation: {
      type: Array,
      required: true,
    },
    toggleSideNav: {
      type: Function,
      required: true,
    },
    logo: {
      type: Object,
      required: true,
    },
  },
  computed: {
    image() {
      return getImage(this.logo);
    },
  },
};
</script>
<style>
.nav-bg {
  background-color: rgba(252, 251, 254, 0.65);
}
</style>
