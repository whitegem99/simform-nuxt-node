<template>
  <div class="max-w-6xl mx-auto text-xl font-light">
    <ul class="leading-relaxed" :class="[ data.ordered ? 'list-decimal' : 'list-none' ]">
      <li v-for="(item, index) in data.listItems" :key="index" class="mb-4">
        <div v-html="item.text"></div>
      </li>
    </ul>
  </div>
</template>
<script>
export default {
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
};
</script>
