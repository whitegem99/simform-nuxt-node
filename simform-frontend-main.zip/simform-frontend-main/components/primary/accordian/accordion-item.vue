<template>
  <dl class="space-y-6 divide-y divide-gray-200 bg-white">
    <div class="bg-white accordion p-4" :class="[changeBg, spacedPadding]">
      <dt class="text-lg">
        <button
          type="button"
          class="text-left w-full flex justify-between items-start"
          aria-controls="faq-0"
          aria-expanded="false"
          v-on:click="toggle"
        >
          <div v-html="title" class="text-gray-900 font-semibold">
          </div>
          <span class="ml-6 h-7 flex items-center">
            <svg
              class="rotate-0 h-6 w-6 transform transition-all duration-300"
              :class="rotateChervron"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              aria-hidden="true"
            >
              <path
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="M19 9l-7 7-7-7"
              />
            </svg>
          </span>
        </button>
      </dt>
      <transition name="slide">
        <dd class="mt-2" id="faq-0" v-show="isOpen">
          <div class="text-base" v-show="isOpen">
            <transition name="slide">
              <slot></slot>
            </transition>
          </div>
        </dd>
      </transition>
    </div>
    <div class="bg-blue-50 hidden"></div>
  </dl>
</template>
<script>
export default {
  props: {
    title: {
      type: String,
      required: true,
    },
    spaced: {
      type: Boolean,
      default: false,
    },
    onMyEvent: Function,
  },
  mounted() {
    this.onMyEvent(this.closeItem);
  },
  computed: {
    rotateChervron() {
      return this.isOpen ? "rotate-180" : "rotate-0";
    },
    changeBg() {
      return this.isOpen ? "mint-cream" : "bg-white";
    },
    spacedPadding() {
      return this.spaced ? "mb-5" : "";
    },
  },
  data() {
    return {
      isOpen: false,
    };
  },
  methods: {
    toggle() {
      this.$emit("toggle-item", this._uid);
      this.isOpen = !this.isOpen;
    },
    closeItem(id) {
      if (this._uid !== id) {
        this.isOpen = false;
      }
    },
  },
  transition: {
    name: "slide",
    mode: "",
  },
};
</script>
<style scoped>
.mint-cream {
  background-color: #f9ffff;
}
.accordion {
  padding: 21px 36px 25px 30px;
  border-width: 1px 1px 0px;
  border-top-style: solid;
  border-right-style: solid;
  border-left-style: solid;
  border-top-color: rgb(209, 237, 235);
  border-right-color: rgb(209, 237, 235);
  border-left-color: rgb(209, 237, 235);
  border-image: initial;
  box-shadow: rgb(0 0 0 / 10%) 0px 3px 5px -1px;
  transition: all 0.1s;
  border-bottom-style: initial;
  border-bottom-color: initial;
}

.slide-enter-active {
  transition: all 0.1s ease;
}
.slide-leave-active {
  transition: all 0.1s ease;
}
.slide-enter-to,
.slide-leave {
  max-height: 140px;
}

.slide-enter,
.slide-leave-to {
  max-height: 0px;
}
</style>
