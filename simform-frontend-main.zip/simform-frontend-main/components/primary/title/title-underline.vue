<template>
  <div :class="[spaced ? 'mt-12 mb-6' : 'mb-6']">
    <h3
      class="leading-[1.3] text-secondary-800 max-w-3xl scroll-mt-32 text-[28px] px-3 sm:px-0"
      :class="[
        textAlign,
        small ? 'sm:text-[32px] font-semibold' : 'sm:text-[42px] font-bold',
      ]"
      v-html="htmlString"
      :id="hyperlink"
    ></h3>
  </div>
</template>

<script>
export default {
  name: "TitleUnderline",
  ssr: false,
  props: {
    data: {
      type: Object,
      required: true,
    },
    spaced: {
      type: Boolean,
      default: true,
    },
    small: {
      type: Boolean,
      default: false,
    },
  },
  computed: {
    htmlString: function () {
      let html = this.data.text;
      html = html
        .replace(/<u>/g, `<span class='color-underline'>`)
        .replace(/<\/u>/g, `</span>`);
      return html;
    },
    textAlign: function () {
      return `text-${this.data.align ?? "center"} ${
        !this.data.align || this.data.align === "center" ? "mx-auto" : ""
      }`;
    },
    hyperlink: function () {
      let link = this.data.text;
      link = link
        .trim()
        .replace(/<[^>]*>?/gm, "")
        .toLowerCase()
        .replace(/[^a-zA-Z0-9 ]/g, "")
        .replace(/\s/g, "-");
      return link;
    },
  },
};
</script>
