<template>
  <div class="mt-7 mb-5 max-w-6xl mx-auto">
    <div v-if="data.withCheckMark">
      <check-mark-item center>
        <h3 class="text-2xl font-semibold text-slate-700 font-merriweather">{{ data.text }}</h3>
      </check-mark-item>
    </div>
    <h3 v-else class="text-3xl font-semibold text-slate-700">{{ data.text }}</h3>
  </div>
</template>
<script>
import CheckMark from "@/components/primary/checkmark/check-mark";
import CheckMarkItem from "../../feature-components/check-mark-list/check-mark-item.vue";

export default {
  components: { CheckMark, CheckMarkItem },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
};
</script>
