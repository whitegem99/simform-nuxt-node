<template>
  <div class="w-4 h-4 rounded-full dot-div mr-2" :style="backgroundColor"></div>
</template>
<script>
export default {
  props: {
    color: {
      type: String,
      default: "#f09cb0",
    },
  },
  computed: {
    backgroundColor() {
      return `--bg-color: ${this.color}`;
    },
  },
};
</script>
<style>
.dot-div {
  background-color: var(--bg-color);
}
</style>
