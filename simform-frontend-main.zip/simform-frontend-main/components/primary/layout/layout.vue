<template>
  <div class="bg-slate-50 font-nexa">
    <side-nav :navigation="navigation" :company-navigation="topNavigation" :toggleSideNav="toggleSideNav" :isSideNavOpen="isSideNavOpen"/>
    <navbar :navigation="topNavigation" />
    <navbar-sticky :navigation="navigation" :toggleSideNav="toggleSideNav" :logo="app.logo" />
    <slot></slot>
    <footer-section
      :withTalkFooter="withTalkFooter"
      :talk-footer-data="talkFooterData"
    />
    <client-only>
      <cookie-button />
    </client-only>
  </div>
</template>
<script>
import Navbar from "../navbar/navbar.vue";
import NavbarSticky from "../navbar/navbar-sticky.vue";
import FooterSection from "@/components/sections/common/footer-section";
import CookieButton from "../banner/cookie-banner.vue";
import SideNav from "../navbar/side-nav.vue";

const navigation = [
  {
    title: "Software Development",
    items: [
      {
        name: "Custom Software Development",
        href: "/services/custom-software-development",
      },
      {
        name: "Application Development",
        href: "#",
        submenu: [
          { name: "Frontend Development", href: "#" },
          { name: "Ecommerce Development", href: "#" },
          { name: "SaaS Application Development", href: "#" },
          { name: "Web Application Development", href: "#" },
          { name: "Progressive Web Application Development", href: "#" },
          { name: "Enterprise Application Development", href: "#" },
          {
            name: "Mobile Application Development",
            href: "/services/mobile-app-development",
          },
        ],
      },
      {
        name: "White Label Software Development",
        href: "/services/white-label-software-development",
      },
      {
        name: "Software Product Development Services",
        href: "/services/software-product-development",
      },
      {
        name: "AI/ML Development",
        href: "/services/artificial-intelligence-development",
      },
      {
        name: "API Integration",
        href: "/services/api-integration-development",
      },
    ],
  },
  {
    title: "Cloud Development",
    items: [
      {
        name: "Cloud-native App Development",
        href: "/services/cloud-application-development",
      },
      { name: "Cloud Consulting", href: "/services/cloud-consulting" },
      {
        name: "Microservices Architecture",
        href: "/services/microservices-architecture-development",
      },
      { name: "Data and Analytics Consulting", href: "#" },
      {
        name: "Serverless",
        href: "/services/serverless-app-development-consulting",
      },
      { name: "Kubernetes Consulting", href: "#" },
      { name: "Cloud Migration Consulting", href: "/services/cloud-migration" },
      { name: "Cloud Architecture design and review", href: "#" },
      { name: "Cloud Assessment and Cost Optimization", href: "#" },
    ],
  },
  {
    title: "DevOps",
    items: [
      { name: "DevOps Consulting", href: "/services/devops-consulting" },
      { name: "CI/CD Implementation and Management", href: "#" },
      { name: "Containerization and Orchestration", href: "#" },
      { name: "Infrastructure Management and Monitoring", href: "#" },
      { name: "Infrastructure as a Code", href: "#" },
    ],
  },
  {
    title: "Software Testing",
    items: [
      { name: "Test Automation", href: "/services/test-automation" },
      { name: "API Testing", href: "#" },
      { name: "Microservice Testing", href: "/services/microservice-testing" },
      { name: "Performance Testing", href: "#" },
      { name: "Load Testing", href: "#" },
      { name: "Security Testing", href: "#" },
    ],
  },
  {
    title: "Hire",
    items: [
      { name: "Hire Angular Developers", href: "/hire/angular-developers" },
      { name: "Hire Nodejs  Developers", href: "#" },
      { name: "Hire ReactJs Developers", href: "#" },
      { name: "Hire Dedicated Developers", href: "#" },
      { name: "Hire Ruby on Rails Developers", href: "#" },
      { name: "Hire React Native Developers", href: "#" },
      { name: "Hire Mobile App Developers", href: "#" },
      { name: "Dedicated Software Development team", href: "#" },
      { name: "Hire Python Developers", href: "#" },
      { name: "Hire Asp.net Developers", href: "#" },
      { name: "Hire Flutter Developers", href: "#" },
      { name: "Hire PHP Developers", href: "#" },
    ],
  },
];

const topNavigation = [
  {
    name: "About us",
    href: "/about-us",
  },
  {
    name: "How it works",
    href: "/how-it-works",
  },
  {
    name: "Case studies",
    href: "/case-studies",
  },
  {
    name: "Blog",
    href: "/blog",
  },
  {
    name: "Technology comparison",
    href: "/blog/technology-comparison",
  },
];

export default {
  name: "Layout",
  components: { Navbar, NavbarSticky, FooterSection, CookieButton, SideNav },
  data() {
    return {
      navigation,
      topNavigation,
      isSideNavOpen: false,
      app: {},
    };
  },
  methods: {
    toggleSideNav() {
      this.isSideNavOpen = !this.isSideNavOpen;
    },
  },
  props: {
    withTalkFooter: {
      type: Boolean,
      default: false,
    },
    talkFooterData: {
      type: Object,
      default: () => ({
        name: "John Danny",
        description:
          "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
        photo: require("assets/images/user-lets-talk.png"),
        ctaText: "Call Now",
        phoneUrl: "tel:+1234567890",
      }),
    },
  },
  async fetch() {
    try {
      const data = await fetch(`${process.env.BASE_URL}/api/app?populate=deep`);
      const app = await data.json();

      this.app = app.data.attributes;
    } catch (error) {
      console.log(error);
    }
  }
};
</script>
