<template>
  <span class="bg-primary-50 text-primary-500" :class="boldClass">{{ text }}</span>
</template>

<script>
export default {
  name: "HighlightedText",
  props: {
    text: String,
    bold: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    boldClass: function () {
      return this.bold ? `font-semibold` : ""
    }
  }
}
</script>