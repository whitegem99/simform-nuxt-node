<template>
  <button v-if="url" :class="[btnClass, btnSize, btnBold, btnExpanded]" class="group">
    <nuxt-link class="rounded font-light w-full text" :to="url">
      <slot></slot>
    </nuxt-link>
  </button>
  <button
    v-else
    :class="[btnClass, btnSize, btnExpanded, btnBold]"
    class="group"
    @click="onClick"
  >
    <span class="rounded font-light w-full text flex justify-center">
      <slot></slot>
    </span>
  </button>
</template>

<script>
export default {
  name: "simform-button",
  props: {
    size: {
      type: String,
      default: "base",
    },
    reverse: {
      type: Boolean,
      default: false,
    },
    url: {
      type: String,
    },
    bold: {
      type: Boolean,
      default: false,
    },
    expanded: {
      type: Boolean,
      default: false,
    },
    onClick: {
      type: Function,
    },
    black: {
      type: Boolean,
      default: false,
    },
    classData: {
      type: String,
      default: "",
    }
  },
  computed: {
    btnClass: function () {
      let classValue = `${this.classData} button`;

      if (this.reverse) {
        classValue = " reverse-button";
      }

      if (this.reverse && this.black) {
        classValue = "reverse-black-button";
      }

      return classValue;
    },
    btnSize: function () {
      if (this.size === "small") {
        return "px-1 text-xs";
      } else if (this.size === "large") {
        return "px-6 py-4 text-lg";
      }

      return "px-5 py-3";
    },
    btnBold: function () {
      return this.bold ? "font-bold" : "font-light";
    },
    btnExpanded: function () {
      return this.expanded ? "w-full" : "w-auto";
    },
  },
};
</script>


<style scoped>
.text {
  position: relative;
  z-index: 10;
}

.reverse-button {
  cursor: pointer;
  color: rgb(28, 28, 28);
  font-size: 19px;
  line-height: 27px;
  letter-spacing: -0.16px;
  text-align: center;
  background: transparent;
  border: 1px solid rgb(239, 83, 102);
  border-radius: 4px;
  position: relative;
  overflow: hidden;
  display: inline-block;
  transition: color 0.2s ease-in-out 0s, background-color 0.1s ease 0.02s;
}

.reverse-button::before {
  content: "";
  position: absolute;
  height: 100%;
  width: 101%;
  right: 0px;
  top: 0px;
  left: 0px;
  transform: translate(0px);
  background: rgb(28, 28, 28);
}

.reverse-button::after,
.reverse-button::before {
  content: "";
  position: absolute;
  height: 100%;
  width: 101%;
  right: 0;
  top: 0;
  left: 0;
  transform: translate(0px);
  background: rgb(239, 83, 102);
}

.reverse-button::after {
  transform: translateY(100%);
  transition: transform 0.2s ease-in-out 0s;
}

.reverse-button::before {
  transform: translateY(-100%);
  transition: transform 15ms ease-in-out 0s;
}

.reverse-button:hover::before {
  transform: translateY(0px);
  transition: transform 0.2s ease-in-out 0s;
}

.reverse-button:hover {
  color: white;
  background-color: rgb(239, 83, 102);
  transition-delay: 0s, 0.15s;
}

.reverse-button:hover::after {
  transform: translateY(0px);
  transition: transform 0ms ease-in-out 0.2s;
}

/* reverse */
.button {
  cursor: pointer;
  color: white;
  line-height: 27px;
  letter-spacing: -0.16px;
  text-align: center;
  background: rgb(239, 83, 102);
  border: 1px solid rgb(239, 83, 102);
  border-radius: 4px;
  position: relative;
  overflow: hidden;
  display: inline-block;
  transition: color 0.2s ease-in-out 0s, background-color 0.1s ease 0.02s;
}

.button::before {
  content: "";
  position: absolute;
  height: 100%;
  width: 101%;
  right: 0px;
  top: 0px;
  left: 0px;
  transform: translate(0px);
  background: white;
}

.button::after,
.button::before {
  content: "";
  position: absolute;
  height: 100%;
  width: 101%;
  right: 0;
  top: 0;
  left: 0;
  transform: translate(0px);
  background: white;
}

.button::after {
  transform: translateY(100%);
  transition: transform 0.2s ease-in-out 0s;
}

.button::before {
  transform: translateY(-100%);
  transition: transform 15ms ease-in-out 0s;
}

.button:hover::before {
  transform: translateY(0px);
  transition: transform 0.2s ease-in-out 0s;
}

.button:hover {
  color: rgb(239, 83, 102);
  background-color: white;
  transition-delay: 0s, 0.15s;
}

.button:hover::after {
  transform: translateY(0px);
  transition: transform 0ms ease-in-out 0.2s;
}

.reverse-black-button {
  cursor: pointer;
  color: rgb(28, 28, 28);
  font-size: 19px;
  line-height: 27px;
  letter-spacing: -0.16px;
  text-align: center;
  background: transparent;
  border: 1px solid rgb(28, 28, 28);
  border-radius: 4px;
  position: relative;
  overflow: hidden;
  display: inline-block;
  transition: color 0.2s ease-in-out 0s, background-color 0.1s ease 0.02s;
}

.reverse-black-button::before {
  content: "";
  position: absolute;
  height: 100%;
  width: 101%;
  right: 0px;
  top: 0px;
  left: 0px;
  transform: translate(0px);
  background: rgb(28, 28, 28);
}

.reverse-black-button::after,
.reverse-black-button::before {
  content: "";
  position: absolute;
  height: 100%;
  width: 101%;
  right: 0;
  top: 0;
  left: 0;
  transform: translate(0px);
  background: rgb(28, 28, 28);
}

.reverse-black-button::after {
  transform: translateY(100%);
  transition: transform 0.2s ease-in-out 0s;
}

.reverse-black-button::before {
  transform: translateY(-100%);
  transition: transform 15ms ease-in-out 0s;
}

.reverse-black-button:hover::before {
  transform: translateY(0px);
  transition: transform 0.2s ease-in-out 0s;
}

.reverse-black-button:hover {
  color: white;
  background-color: rgb(28, 28, 28);
  transition-delay: 0s, 0.15s;
}

.reverse-black-button:hover::after {
  transform: translateY(0px);
  transition: transform 0ms ease-in-out 0.2s;
}
</style>
