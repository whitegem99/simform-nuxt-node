<template>
  <img :src="src" :alt="alt" class="w-16 h-16 rounded-full" />
</template>
<script>
export default {
  props: {
    src: {
      type: String,
      required: true,
    },
    alt: {
      type: String,
      required: true,
    },
  },
};
</script>
