<template>
  <div class="w-[390px] min-w-[390px] h-[190px] min-h-[190px] mx-5 even:mt-7">
    <div
      class="flex border gap-4 bg-slate-50 shadow-md hover:shadow-xl hover:shadow-gray-400/60 transition-all duration-300 ease-in hover:-translate-y-1 px-5 py-5 group hover:pt-3 hover:pb-8 h-full"
      :class="[backgroundColor, borderColor]"
    >
      <div class="w-14">
        <img :src="icon.src" :alt="icon.alt" class="w-[100px] group-hover:drop-shadow-lg transition-all duration-500" />
      </div>
      <div class="flex-1">
        <h4
          class="font-semibold mb-3 text-xl transition-colors duration-500"
          :class="textColor"
        >
          <!-- TODO handle links here -->
          <nuxt-link to="/services/custom-software-development/">{{
            title
          }}</nuxt-link>
        </h4>
        <div v-html="description" class="font-light text-[18px]"></div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "ServiceItem",
  props: {
    color: Object,
    icon: Object,
    title: String,
    description: String,
  },
  computed: {
    borderColor() {
      return this.color.tw.border;
    },
    backgroundColor() {
      return this.color.tw.bg;
    },
    textColor() {
      return this.color.tw.text;
    },
  },
};
</script>
