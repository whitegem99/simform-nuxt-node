<template>
  <div>
    <div>
      <div>
        <nav
          class="flex gap-2 w-full px-4 sm:px-16 mb-10 sm:flex-row flex-wrap"
          aria-label="Tabs"
        >
          <a
            v-for="tab in tabs"
            :key="tab.name"
            @click="selectTab(tab)"
            :class="[
              tab.key === current
                ? 'border-teal-400 text-teal-400'
                : 'border-transparent text-gray-800',
              'whitespace-nowrap py-2 px-1 border-b-[3px] font-normal cursor-pointer transition-all duration-300 flex-1 text-center text-base w-1/2 sm:w-full',
            ]"
          >
            {{ tab.name }}
          </a>
        </nav>
        <slot />
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: ["tabs", "defaultSelect"],
  emits: ["selectTab"],
  methods: {
    selectTab(item) {
      this.$emit("select-tab", item);
      this.current = item.key;
    },
  },
  data() {
    return {
      current: this.tabs[0].key,
    };
  },
};
</script>
