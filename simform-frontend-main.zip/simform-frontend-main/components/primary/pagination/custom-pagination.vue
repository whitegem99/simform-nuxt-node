<template>
  <div class="w-full justify-center flex">
    <div class="flex gap-3 my-10">
    <nuxt-link
      v-for="i in pageCount"
      :key="i"
      :to="{ query: { page: i } }"
      class="w-8 h-8 text-lg rounded bg-transparent flex justify-center items-end hover:bg-primary-500 hover:text-white duration-500"
      :class="{ 'bg-primary-500 text-white': i === page, 'text-gray-400 ': i !== page }"
    >
      {{ i }}
    </nuxt-link>
  </div>
  </div>
</template>
<script>
export default {
  props: {
    page: {
      type: Number,
      required: true,
    },
    pageCount: {
      type: Number,
      required: true,
    },
  },
};
</script>
