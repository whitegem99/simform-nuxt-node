<template>
  <h5 class="font-light text-2xl mb-10 text-center">
    We <highlight-text  text="add development capacity"/> to tech teams. Our value isn’t limited to building teams but is equally distributed across the project lifecycle.
    We are a custom software development company that guarantees the successful delivery of your project.
  </h5>
</template>

<script>
import HighlightText from '../highlight-text/highlight-text.vue';
export default {
    name: "HighlightParagraph",
    components: { HighlightText }
}
</script>
