<template>
  <div
    class="bottom-4 left-5 cookie-bg p-5 pr-0 sticky"
    v-if="showCookieBanner"
  >
    <p class="w-[75%] text-sm">
      We use cookies to improve your browsing experience. And
      <span class="italic font-bold font-merriweather">Pizzas</span> to boost
      morale on Fridays.
      <span class="font-merriweather font-bold italic"
        >Learn about our
        <nuxt-link to="/privacy-policy" class="underline"
          >Privacy policy</nuxt-link
        >
        here.</span
      >
    </p>
    <div class="hidden lg:block mt-3">
      <simform-button
        size="small"
        classData="hidden lg:flex justify-self-end align-middle w-[100px] mt-3"
        :onClick="onClick"
        reverse
        black
      >
        <span
          class="flex justify-center items-center tracking-wider mt-[4px] px-2 py-[2px] text-base font-normal"
          >OKAY</span
        >
      </simform-button>
    </div>
    <button
      @click="onClick"
      class="flex lg:hidden mt-3 rounded-md border border-slate-800 px-3 pt-2 pb-1"
    >
      OKAY
    </button>
  </div>
</template>
<script>
import Cookies from "js-cookie";
import SimformButton from "@/components/primary/button/simform-button";

export default {
  name: "CookieButton",
  components: { SimformButton },
  data() {
    return {
      showCookieBanner: true,
    };
  },
  methods: {
    onClick() {
      this.showCookieBanner = false;
      Cookies.set("hideCookieBanner", "true", { expires: 365 });
    },
  },
  mounted() {
    this.showCookieBanner = Cookies.get("hideCookieBanner") ? false : true;
  },
};
</script>
<style scoped>
.cookie-bg {
  background: url("~/assets/images/Cookie-bg.png") center center / 100% 100%
    no-repeat;
  width: 280px;
  height: 185px;
}
</style>
