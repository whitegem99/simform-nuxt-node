const colors = require("tailwindcss/colors");

module.exports = {
  mode: "jit",
  darkMode: "media", // or 'media' or 'class'
  theme: {
    extend: {
      colors: {
        primary: colors.rose,
        secondary: colors.gray,
        teal: colors.teal,
        peach: '#f2dbcb',
        grayblue: '#c2d2f5',
        emptygreen: '#a4eae4',
        dullyellow: '#f9da9b',
        lesspink: '#ecc2e5'
      },
      fontFamily: {
        nexa: ["Nexa", "sans-serif"],
        merriweather: ['"Merriweather"', "serif"],
      },
      fontWeight: {
        thin: 100,
        light: 300,
        normal: 400,
        medium: 500,
        semibold: 700,
        bold: 800,
      },
      keyframes: {
        swing: {
          "0%, 100%": { transform: "translateX(-10px)" },
          "50%": { transform: "translateX(0)" },
        },
      },
      animation: {
        swing: "swing 1s ease-in-out infinite",
      },
    },
  },
  variants: {
    extend: {},
  },
  plugins: [
    require("tw-elements/dist/plugin"),
    require("tailwindcss-labeled-groups")(["menusub"]),
    require("@tailwindcss/forms"),
  ],
  content: [
    `components/**/*.{vue,js}`,
    `layouts/**/*.vue`,
    `pages/**/*.vue`,
    `composables/**/*.{js,ts}`,
    `plugins/**/*.{js,ts}`,
    `App.{js,ts,vue}`,
    `app.{js,ts,vue}`,
    "./nuxt.config.{js,ts}",
    "./node_modules/tw-elements/dist/js/**/*.js",
  ],
  safelist: [
    "from-blue-200 to-blue-400",
    "from-purple-200 to-purple-400",
    "from-sky-200 to-sky-400",
    "from-yellow-200 to-yellow-400",
    "from-cyan-200 to-cyan-400",
  ]
};
