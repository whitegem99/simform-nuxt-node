export const getImage = (image) => {

  if (!image) {
    return {};
  }

  const img = image.data ? image.data.attributes : image;
  const id = image.data ? image.data.id : image.id;

  return {
    src: img.url,
    alt: img.alternativeText || "",
    caption: img.caption || "",
    id
  };
};
